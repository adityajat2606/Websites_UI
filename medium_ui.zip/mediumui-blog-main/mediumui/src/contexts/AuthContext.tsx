import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, saveRegisteredUser, updateUserInStorage, getUserById } from "@/data/users";

interface AuthContextType {
  currentUser: User | null;
  signIn: (email: string, password: string) => boolean;
  signUp: (name: string, email: string, password: string) => boolean;
  signOut: () => void;
  updateProfile: (updates: Partial<User>) => void;
  toggleFollow: (userId: string) => void;
  isFollowing: (userId: string) => boolean;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  signIn: () => false,
  signUp: () => false,
  signOut: () => {},
  updateProfile: () => {},
  toggleFollow: () => {},
  isFollowing: () => false,
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [followingList, setFollowingList] = useState<string[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("medium_user");
    if (saved) {
      try {
        const user: User = JSON.parse(saved);
        setCurrentUser(user);
        // load follow list for this user
        const stored = localStorage.getItem(`medium_following_${user.id}`) || "[]";
        try {
          setFollowingList(JSON.parse(stored));
        } catch {
          setFollowingList([]);
        }
      } catch {}
    }
  }, []);

  const signIn = (email: string, _password: string) => {
    // Look up in registered users
    const registered: User[] = JSON.parse(localStorage.getItem("medium_registered_users") || "[]");
    const username = email.split("@")[0].toLowerCase();
    const user = registered.find(
      (u) => u.username.toLowerCase() === username || u.name.toLowerCase().includes(username)
    );
    if (user) {
      setCurrentUser(user);
      localStorage.setItem("medium_user", JSON.stringify(user));
      // load follow list
      const stored = localStorage.getItem(`medium_following_${user.id}`) || "[]";
      try {
        setFollowingList(JSON.parse(stored));
      } catch {
        setFollowingList([]);
      }
      return true;
    }
    // No match found - create a new account on the fly for demo
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: username.charAt(0).toUpperCase() + username.slice(1),
      username,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=random&size=150`,
      bio: "New to Medium. Writing my first stories.",
      followers: 0,
      following: 0,
    };
    saveRegisteredUser(newUser);
    setCurrentUser(newUser);
    localStorage.setItem("medium_user", JSON.stringify(newUser));
    setFollowingList([]);
    return true;
  };

  const signUp = (name: string, email: string, _password: string) => {
    const newUser: User = {
      id: `user-${Date.now()}`,
      name,
      username: email.split("@")[0],
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&size=150`,
      bio: "New to Medium. Writing my first stories.",
      followers: 0,
      following: 0,
    };
    saveRegisteredUser(newUser);
    setCurrentUser(newUser);
    localStorage.setItem("medium_user", JSON.stringify(newUser));
    return true;
  };

  const signOut = () => {
    setCurrentUser(null);
    setFollowingList([]);
    localStorage.removeItem("medium_user");
  };

  const updateProfile = (updates: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...updates };
    setCurrentUser(updated);
    localStorage.setItem("medium_user", JSON.stringify(updated));
    updateUserInStorage(updated);
  };

  const toggleFollow = (userId: string) => {
    if (!currentUser) return;
    const key = `medium_following_${currentUser.id}`;
    let list: string[] = [];
    try {
      list = JSON.parse(localStorage.getItem(key) || "[]");
    } catch {}

    const isFollowing = list.includes(userId);
    const updatedList = isFollowing ? list.filter((id) => id !== userId) : [...list, userId];
    localStorage.setItem(key, JSON.stringify(updatedList));
    setFollowingList(updatedList);

    // adjust counts
    const currentVersion = { ...currentUser };
    if (isFollowing) {
      currentVersion.following = Math.max(0, currentVersion.following - 1);
    } else {
      currentVersion.following = currentVersion.following + 1;
    }
    setCurrentUser(currentVersion);
    localStorage.setItem("medium_user", JSON.stringify(currentVersion));
    updateUserInStorage(currentVersion);

    const target = getUserById(userId);
    if (target) {
      const updatedTarget = { ...target };
      if (isFollowing) {
        updatedTarget.followers = Math.max(0, updatedTarget.followers - 1);
      } else {
        updatedTarget.followers = updatedTarget.followers + 1;
      }
      updateUserInStorage(updatedTarget);
    }
  };

  const isFollowing = (userId: string) => followingList.includes(userId);

  return (
    <AuthContext.Provider value={{
      currentUser,
      signIn,
      signUp,
      signOut,
      updateProfile,
      toggleFollow,
      isFollowing,
    }}>
      {children}
    </AuthContext.Provider>
  );
};
