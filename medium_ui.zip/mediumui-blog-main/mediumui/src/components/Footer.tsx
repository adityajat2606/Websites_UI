import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="bg-black text-white mt-16">
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
        <Link to="/" className="font-display text-lg font-bold tracking-tight">Medium</Link>
        <div className="grid grid-cols-3 gap-x-6 gap-y-2 text-sm sm:justify-items-end sm:text-right">
          <Link to="/about" className="hover:text-gray-300 transition-colors">About</Link>
          <Link to="/help" className="hover:text-gray-300 transition-colors">Help</Link>
          <Link to="/status" className="hover:text-gray-300 transition-colors">Status</Link>
          <Link to="/careers" className="hover:text-gray-300 transition-colors">Careers</Link>
          <Link to="/terms" className="hover:text-gray-300 transition-colors">Terms</Link>
          <Link to="/privacy" className="hover:text-gray-300 transition-colors">Privacy</Link>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
