import { User } from "@/data/users";
import EditProfileDialog from "@/components/EditProfileDialog";
import { useAuth } from "@/contexts/AuthContext";
import ImageWithFallback from "@/components/ImageWithFallback";

interface ProfileHeaderProps {
  user: User;
  isOwnProfile?: boolean;
  isFollowing?: boolean;
  onToggleFollow?: () => void;
}

const ProfileHeader = ({ user, isOwnProfile, isFollowing, onToggleFollow }: ProfileHeaderProps) => {
  const { updateProfile } = useAuth();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          updateProfile({ avatar: reader.result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-5">
        <div className="relative">
          <ImageWithFallback
            src={user.avatar}
            alt={user.name}
            className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover"
          />
          {isOwnProfile && (
            <input
              type="file"
              accept="image/*"
              aria-label="Upload avatar on page"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer rounded-full"
              onChange={handleFileChange}
            />
          )}
        </div>
        <div className="flex-1">
          <h1 className="font-display text-2xl sm:text-3xl font-bold">{user.name}</h1>
          <p className="text-muted-foreground mt-1 text-sm sm:text-base leading-relaxed">
            {user.bio}
          </p>
          <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
            <span><strong className="text-foreground">{user.followers.toLocaleString()}</strong> Followers</span>
            <span><strong className="text-foreground">{user.following}</strong> Following</span>
          </div>
        </div>
      </div>
      <div className="flex gap-2">
        {isOwnProfile ? (
          <EditProfileDialog />
        ) : (
          <>
            <button
              onClick={onToggleFollow}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-opacity ${
                isFollowing ? "bg-secondary text-foreground" : "bg-primary text-primary-foreground hover:opacity-90"
              }`}
            >
              {isFollowing ? "Following" : "Follow"}
            </button>
            <button className="px-5 py-2 border rounded-full text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Subscribe
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default ProfileHeader;
