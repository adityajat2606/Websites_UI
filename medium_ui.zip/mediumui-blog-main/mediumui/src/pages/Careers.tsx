import { motion } from "framer-motion";

const Careers = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-[720px] mx-auto px-4 sm:px-6 py-12">
    <h1 className="font-display text-4xl font-bold mb-6">Careers</h1>
    <p className="text-muted-foreground">Currently no open roles. This page will list job opportunities in the future.</p>
  </motion.div>
);

export default Careers;
