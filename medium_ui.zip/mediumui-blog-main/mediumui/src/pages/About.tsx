import { motion } from "framer-motion";

const About = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-[720px] mx-auto px-4 sm:px-6 py-12">
    <h1 className="font-display text-4xl font-bold mb-6">About Medium</h1>
    <div className="prose max-w-none text-muted-foreground space-y-4">
      <p className="text-lg leading-relaxed">Medium is a place where ideas take shape, stories find their audience, and conversations spark change.</p>
      <p>Founded on the belief that what you read matters, Medium amplifies voices and surfaces the best thinking on any topic — from technology and culture to politics and personal development.</p>
      <p>Our platform brings together curious readers and thoughtful writers in a space designed for deep, meaningful content. No clickbait. No noise. Just ideas worth spreading.</p>
      <h2 className="font-display text-2xl font-bold text-foreground mt-8">Our Mission</h2>
      <p>To deepen people's understanding of the world and help them share ideas that matter.</p>
      <h2 className="font-display text-2xl font-bold text-foreground mt-8">How It Works</h2>
      <p>Anyone can write on Medium. The best stories are surfaced by a combination of human curation and algorithms that prioritize quality over engagement bait.</p>
    </div>
  </motion.div>
);

export default About;
