import { useParams, useNavigate } from "react-router-dom";
import { getUserById } from "@/data/users";
import { useArticles } from "@/contexts/ArticleContext";
import { useAuth } from "@/contexts/AuthContext";
import ProfileHeader from "@/components/ProfileHeader";
import ArticleCard from "@/components/ArticleCard";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useBookmarks } from "@/contexts/BookmarkContext";

const Profile = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, toggleFollow, isFollowing } = useAuth();
  const [activeTab, setActiveTab] = useState("articles");

  const [profileUser, setProfileUser] = useState(getUserById(id || ""));
  const { articles, deleteArticle } = useArticles();
  const { bookmarks } = useBookmarks();

  const followingFlag = isFollowing(profileUser?.id || "");

  useEffect(() => {
    setProfileUser(getUserById(id || ""));
  }, [id, followingFlag]);

  // ensure own profile reflects changes to currentUser
  useEffect(() => {
    if (currentUser && currentUser.id === profileUser?.id) {
      setProfileUser(currentUser);
    }
  }, [currentUser, profileUser?.id]);

  if (!profileUser) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <h1 className="font-display text-3xl font-bold">User not found</h1>
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === profileUser.id;
  const displayUser = isOwnProfile ? currentUser! : profileUser;
  const userArticles = articles.filter((a) => a.authorId === displayUser.id);
  const bookmarkedArticles = articles.filter((a) => bookmarks.includes(a.id));
  const tabs = ["Articles", "About", "Saved"];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-[720px] mx-auto px-4 sm:px-6 py-10"
    >
      <ProfileHeader
        user={displayUser}
        isOwnProfile={isOwnProfile}
        isFollowing={!isOwnProfile && isFollowing(displayUser.id)}
        onToggleFollow={() => {
          if (!isOwnProfile) {
            toggleFollow(displayUser.id);
          }
        }}
      />

      {/* Tabs */}
      <div className="flex gap-6 border-b mt-10 mb-8">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab.toLowerCase())}
            className={`pb-3 text-sm font-medium transition-colors border-b-2 ${
              activeTab === tab.toLowerCase()
                ? "border-foreground text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === "articles" && (
        <div className="space-y-8">
          {userArticles.map((article) => (
            <div key={article.id} className="pb-8 border-b last:border-0">
              <div className="flex justify-between items-start">
                <ArticleCard articleId={article.id} />
                {isOwnProfile && (
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => navigate(`/write?edit=${article.id}`)}
                      className="px-3 py-1 bg-secondary text-foreground rounded-full text-xs font-medium hover:opacity-90 transition-opacity"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm("Delete this article?")) {
                          deleteArticle(article.id);
                        }
                      }}
                      className="px-3 py-1 bg-destructive text-destructive-foreground rounded-full text-xs font-medium hover:opacity-90 transition-opacity"
                    >
                      Delete
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
          {userArticles.length === 0 && (
            <p className="text-muted-foreground text-center py-10">No articles yet.</p>
          )}
        </div>
      )}

      {activeTab === "about" && (
        <div className="prose max-w-none">
          <p className="text-lg leading-relaxed">{displayUser.bio}</p>
        </div>
      )}

      {activeTab === "saved" && (
        <div className="space-y-8">
          {bookmarkedArticles.map((article) => (
            <div key={article.id} className="pb-8 border-b last:border-0">
              <ArticleCard articleId={article.id} />
            </div>
          ))}
          {bookmarkedArticles.length === 0 && (
            <p className="text-muted-foreground text-center py-10">No saved articles yet.</p>
          )}
        </div>
      )}
    </motion.div>
  );
};

export default Profile;
