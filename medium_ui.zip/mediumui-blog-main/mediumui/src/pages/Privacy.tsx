import { motion } from "framer-motion";

const Privacy = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-[720px] mx-auto px-4 sm:px-6 py-12">
    <h1 className="font-display text-4xl font-bold mb-6">Privacy Policy</h1>
    <div className="prose max-w-none text-muted-foreground space-y-4 text-sm leading-relaxed">
      <p><strong className="text-foreground">Last updated:</strong> March 1, 2026</p>
      <p>Your privacy is important to us. This policy explains what information we collect and how we use it.</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">Information We Collect</h2>
      <p>We collect information you provide (name, email, profile data) and usage data (pages visited, interactions).</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">How We Use It</h2>
      <p>We use your information to provide and improve our services, personalize your experience, and communicate with you.</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">Data Protection</h2>
      <p>We implement industry-standard security measures to protect your personal information.</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">Your Rights</h2>
      <p>You can access, update, or delete your personal data at any time through your account settings.</p>
    </div>
  </motion.div>
);

export default Privacy;
