import { motion } from "framer-motion";

const Help = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-[720px] mx-auto px-4 sm:px-6 py-12">
    <h1 className="font-display text-4xl font-bold mb-6">Help Center</h1>
    <div className="space-y-6">
      {[
        { q: "How do I create an account?", a: "Click 'Sign up' in the top right corner. Enter your name, email, and a password to get started." },
        { q: "How do I write an article?", a: "Click 'Write' in the navigation bar. Add a title, write your content, select tags, and hit Publish." },
        { q: "How do I bookmark articles?", a: "Click the bookmark icon on any article to save it to your reading list. Find them on the Bookmarks page." },
        { q: "How do I edit my profile?", a: "Go to your profile page and click 'Edit profile' to update your name, bio, and avatar." },
        { q: "How do I follow other writers?", a: "Visit someone’s profile or article and click the 'Follow' button. You’ll see their posts in your feed and can unfollow at any time." },
        { q: "How do I search for articles?", a: "Click the search icon or press ⌘K to open search. Type keywords to find articles by title, subtitle, or topic." },
        { q: "How do I toggle dark mode?", a: "Click the sun/moon icon in the navigation bar to switch between light and dark themes." },
      ].map(({ q, a }) => (
        <div key={q} className="border rounded-lg p-5">
          <h3 className="font-display font-bold text-lg mb-2">{q}</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">{a}</p>
        </div>
      ))}
    </div>
  </motion.div>
);

export default Help;
