import { motion } from "framer-motion";

const Status = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-[720px] mx-auto px-4 sm:px-6 py-12">
    <h1 className="font-display text-4xl font-bold mb-6">Platform Status</h1>
    <p className="text-muted-foreground">All systems are operational. This is a placeholder page.</p>
  </motion.div>
);

export default Status;
