import { motion } from "framer-motion";

const Terms = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-[720px] mx-auto px-4 sm:px-6 py-12">
    <h1 className="font-display text-4xl font-bold mb-6">Terms of Service</h1>
    <div className="prose max-w-none text-muted-foreground space-y-4 text-sm leading-relaxed">
      <p><strong className="text-foreground">Last updated:</strong> March 1, 2026</p>
      <p>By using Medium, you agree to these terms. Please read them carefully.</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">1. Using Medium</h2>
      <p>You must be at least 13 years old to use Medium. You're responsible for your account and the content you post.</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">2. Content</h2>
      <p>You retain ownership of your content. By posting, you grant Medium a license to display and distribute it on our platform.</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">3. Conduct</h2>
      <p>Don't use Medium to harass, spam, or deceive others. We reserve the right to remove content or suspend accounts that violate our rules.</p>
      <h2 className="font-display text-xl font-bold text-foreground mt-6">4. Disclaimers</h2>
      <p>Medium is provided "as is." We don't guarantee uninterrupted access or that our service will be error-free.</p>
    </div>
  </motion.div>
);

export default Terms;
