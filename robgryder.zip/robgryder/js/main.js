// Main JS for robgryder – editorial magazine-style front-end

const ARTICLES_JSON_PATH = 'data/articles.json';
const READING_WORDS_PER_MINUTE = 220;
const ARTICLES_PER_PAGE = 6;

/**
 * Fetch articles JSON once and reuse.
 */
let cachedArticles = null;

async function loadArticles() {
  if (cachedArticles) return cachedArticles;
  const res = await fetch(ARTICLES_JSON_PATH);
  if (!res.ok) {
    console.error('Failed to load articles JSON.');
    return [];
  }
  const data = await res.json();
  cachedArticles = Array.isArray(data) ? data : [];
  return cachedArticles;
}

/**
 * Utility: get query param from URL.
 */
function getQueryParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

/**
 * Utility: simple sanitised slug for element IDs.
 */
function slugifyForId(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Utility: estimate reading time in minutes based on word count.
 */
function estimateReadingTime(textContent) {
  const words = textContent.trim().split(/\s+/).filter(Boolean);
  if (!words.length) return 1;
  return Math.max(1, Math.round(words.length / READING_WORDS_PER_MINUTE));
}

/**
 * Theme toggle (light / dark) with localStorage persistence.
 */
function initThemeToggle() {
  const toggle = document.getElementById('themeToggle');
  if (!toggle) return;

  const storedTheme = window.localStorage.getItem('rg-theme');
  if (storedTheme === 'dark') {
    document.body.classList.add('dark-theme');
  }

  toggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    const isDark = document.body.classList.contains('dark-theme');
    window.localStorage.setItem('rg-theme', isDark ? 'dark' : 'light');
  });
}

/**
 * Mobile navigation + search toggle.
 */
function initHeaderInteractions() {
  const navToggle = document.querySelector('.nav-toggle');
  const headerSearch = document.getElementById('headerSearchBar');
  const searchToggle = document.getElementById('searchToggle');

  if (navToggle) {
    navToggle.addEventListener('click', () => {
      document.body.classList.toggle('nav-open');
    });
  }

  if (searchToggle && headerSearch) {
    searchToggle.addEventListener('click', () => {
      headerSearch.classList.toggle('open');
    });
  }
}

/**
 * Lazy-load images using IntersectionObserver.
 */
function initLazyImages() {
  const lazyImages = document.querySelectorAll('img[data-src]');
  if (!lazyImages.length) return;

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.getAttribute('data-src');
            img.removeAttribute('data-src');
            obs.unobserve(img);
          }
        });
      },
      { rootMargin: '100px 0px' }
    );

    lazyImages.forEach((img) => observer.observe(img));
  } else {
    lazyImages.forEach((img) => {
      img.src = img.getAttribute('data-src');
      img.removeAttribute('data-src');
    });
  }
}

/**
 * Common footer + copyright.
 */
function initFooter() {
  const yearSpan = document.getElementById('copyrightYear');
  if (yearSpan) {
    yearSpan.textContent = String(new Date().getFullYear());
  }
}

/**
 * Render hero section on homepage.
 */
function renderHero(featuredArticle) {
  const heroEl = document.getElementById('heroFeatured');
  if (!heroEl || !featuredArticle) return;

  heroEl.innerHTML = `
    <a href="article.html?id=${encodeURIComponent(featuredArticle.slug)}" class="hero-link">
      <div class="hero-copy">
        <div class="hero-meta-top">
          <span class="category-pill">${featuredArticle.category}</span>
          <span>Featured</span>
        </div>
        <h1>${featuredArticle.title}</h1>
        <p class="hero-excerpt">${featuredArticle.excerpt}</p>
        <div class="hero-meta-bottom">
          <span>By ${featuredArticle.author}</span>
          <span>${new Date(featuredArticle.date).toLocaleDateString()}</span>
        </div>
        <button class="btn-primary" type="button">Read the feature</button>
      </div>
      <div class="hero-image-wrap">
        <img class="hero-image" data-src="${featuredArticle.image}" alt="${featuredArticle.imageCaption || ''}" loading="lazy" width="1200" height="800" />
      </div>
    </a>
  `;
}

/**
 * Render generic article card.
 */
function createArticleCard(article) {
  const div = document.createElement('article');
  div.className = 'article-card';
  const url = `article.html?id=${encodeURIComponent(article.slug)}`;
  div.innerHTML = `
    <a href="${url}">
      <div class="article-card-media">
        <img data-src="${article.image}" alt="${article.imageCaption || ''}" loading="lazy" width="1200" height="800" />
      </div>
      <div class="article-card-body">
        <span class="category-pill">${article.category}</span>
        <h3>${article.title}</h3>
        <p class="article-card-excerpt">${article.excerpt}</p>
        <div class="article-card-meta">
          <span>${article.author}</span>
          <span>${new Date(article.date).toLocaleDateString()}</span>
        </div>
      </div>
    </a>
  `;
  return div;
}

/**
 * Build category filters (pills).
 */
function renderCategoryFilters(containerId, articles, onFilterChange) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const categories = Array.from(new Set(articles.map((a) => a.category))).sort();

  container.innerHTML = '';

  const allPill = document.createElement('button');
  allPill.className = 'pill active';
  allPill.textContent = 'All';
  allPill.dataset.category = 'all';
  container.appendChild(allPill);

  categories.forEach((cat) => {
    const btn = document.createElement('button');
    btn.className = 'pill';
    btn.textContent = cat;
    btn.dataset.category = cat;
    container.appendChild(btn);
  });

  container.addEventListener('click', (e) => {
    const target = e.target;
    if (!(target instanceof HTMLElement)) return;
    const btn = target.closest('.pill');
    if (!btn) return;

    container.querySelectorAll('.pill').forEach((el) => el.classList.remove('active'));
    btn.classList.add('active');
    const category = btn.dataset.category || 'all';
    onFilterChange(category === 'all' ? null : category);
  });
}

/**
 * Pagination UI.
 */
function renderPagination(containerId, totalItems, currentPage, onPageChange) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const totalPages = Math.ceil(totalItems / ARTICLES_PER_PAGE) || 1;
  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  container.innerHTML = '';

  const prevBtn = document.createElement('button');
  prevBtn.textContent = 'Prev';
  prevBtn.disabled = currentPage <= 1;
  prevBtn.addEventListener('click', () => {
    if (currentPage > 1) onPageChange(currentPage - 1);
  });
  container.appendChild(prevBtn);

  for (let i = 1; i <= totalPages; i++) {
    const pageBtn = document.createElement('button');
    pageBtn.textContent = String(i);
    if (i === currentPage) pageBtn.classList.add('active');
    pageBtn.addEventListener('click', () => onPageChange(i));
    container.appendChild(pageBtn);
  }

  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Next';
  nextBtn.disabled = currentPage >= totalPages;
  nextBtn.addEventListener('click', () => {
    if (currentPage < totalPages) onPageChange(currentPage + 1);
  });
  container.appendChild(nextBtn);
}

/**
 * Homepage init: hero, latest grid + pagination, trending, sidebar, footer categories, search.
 */
async function initHomePage() {
  const heroEl = document.getElementById('heroFeatured');
  if (!heroEl) return;

  const [articles] = await Promise.all([loadArticles()]);
  if (!articles.length) return;

  // Hero
  const featured = articles.find((a) => a.featured) || articles[0];
  renderHero(featured);

  // Latest grid
  const gridEl = document.getElementById('latestGrid');
  let filtered = articles.slice().sort((a, b) => new Date(b.date) - new Date(a.date));
  let currentPage = 1;

  function renderGrid() {
    if (!gridEl) return;
    gridEl.innerHTML = '';
    const start = (currentPage - 1) * ARTICLES_PER_PAGE;
    const slice = filtered.slice(start, start + ARTICLES_PER_PAGE);
    slice.forEach((article) => {
      gridEl.appendChild(createArticleCard(article));
    });
    initLazyImages();
    renderPagination('pagination', filtered.length, currentPage, (page) => {
      currentPage = page;
      renderGrid();
    });
  }

  renderGrid();

  // Category filters
  renderCategoryFilters('categoryFilters', articles, (category) => {
    currentPage = 1;
    filtered = category ? articles.filter((a) => a.category === category) : articles.slice();
    filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    renderGrid();
  });

  // Trending
  const trendingRow = document.getElementById('trendingRow');
  if (trendingRow) {
    const trendingArticles = articles
      .slice()
      .sort((a, b) => (b.trendingScore || 0) - (a.trendingScore || 0))
      .slice(0, 8);
    trendingRow.innerHTML = '';
    trendingArticles.forEach((article) => {
      const card = document.createElement('article');
      card.className = 'trending-card';
      card.innerHTML = `
        <a href="article.html?id=${encodeURIComponent(article.slug)}">
          <div class="trending-card-title">${article.title}</div>
          <div class="trending-card-meta">${article.category} • ${new Date(article.date).toLocaleDateString()}</div>
        </a>
      `;
      trendingRow.appendChild(card);
    });
  }

  // Sidebar: categories and popular posts
  const sidebarCategories = document.getElementById('sidebarCategories');
  if (sidebarCategories) {
    const counts = {};
    articles.forEach((a) => {
      counts[a.category] = (counts[a.category] || 0) + 1;
    });
    sidebarCategories.innerHTML = '';
    Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .forEach(([category, count]) => {
        const li = document.createElement('li');
        li.innerHTML = `<a href="category.html?category=${encodeURIComponent(category)}"><span>${category}</span><span>${count}</span></a>`;
        sidebarCategories.appendChild(li);
      });
  }

  const sidebarPopular = document.getElementById('sidebarPopular');
  if (sidebarPopular) {
    const popular = articles
      .filter((a) => a.popular)
      .slice()
      .sort((a, b) => (b.trendingScore || 0) - (a.trendingScore || 0))
      .slice(0, 4);
    sidebarPopular.innerHTML = '';
    popular.forEach((a) => {
      const div = document.createElement('div');
      div.className = 'sidebar-popular-item';
      div.innerHTML = `<a href="article.html?id=${encodeURIComponent(a.slug)}">${a.title}</a><span>${a.author}</span>`;
      sidebarPopular.appendChild(div);
    });
  }

  // Global footer categories
  initFooterCategories(articles);

  // Live search (home + sidebar)
  initSearchFiltering(articles, (query) => {
    const term = query.trim().toLowerCase();
    currentPage = 1;
    if (!term) {
      filtered = articles.slice().sort((a, b) => new Date(b.date) - new Date(a.date));
    } else {
      filtered = articles
        .filter((a) => {
          const haystack = `${a.title} ${a.excerpt} ${a.author} ${a.category}`.toLowerCase();
          return haystack.includes(term);
        })
        .sort((a, b) => new Date(b.date) - new Date(a.date));
    }
    renderGrid();
  });
}

/**
 * Init category page.
 */
async function initCategoryPage() {
  const categoryGrid = document.getElementById('categoryPageGrid');
  if (!categoryGrid) return;

  const articles = await loadArticles();
  if (!articles.length) return;

  const initialCategory = getQueryParam('category');
  let currentCategory = initialCategory && initialCategory !== 'all' ? initialCategory : null;

  function renderCategoryGrid() {
    const list = currentCategory
      ? articles.filter((a) => a.category === currentCategory)
      : articles.slice();
    list.sort((a, b) => new Date(b.date) - new Date(a.date));
    categoryGrid.innerHTML = '';
    list.forEach((article) => {
      categoryGrid.appendChild(createArticleCard(article));
    });
    initLazyImages();
  }

  renderCategoryFilters('categoryPageFilters', articles, (category) => {
    currentCategory = category;
    renderCategoryGrid();
  });

  renderCategoryGrid();
  initFooterCategories(articles);

  const breadcrumbCategoryEl = document.querySelector('.page-header h1');
  if (breadcrumbCategoryEl && currentCategory) {
    breadcrumbCategoryEl.textContent = `Articles in “${currentCategory}”`;
  }
}

/**
 * Init article page: load article by slug / id, render content, TOC, reading time, related, share.
 */
async function initArticlePage() {
  const articleContainer = document.querySelector('.article-layout');
  if (!articleContainer) return;

  const articles = await loadArticles();
  if (!articles.length) return;

  const slug = getQueryParam('id');
  let article =
    articles.find((a) => a.slug === slug) ||
    articles.find((a) => String(a.id) === String(slug)) ||
    articles[0];

  // Populate header
  const categoryEl = document.getElementById('articleCategory');
  const titleEl = document.getElementById('articleTitle');
  const authorNameEl = document.getElementById('articleAuthorName');
  const authorBioEl = document.getElementById('articleAuthorBio');
  const authorAvatarEl = document.getElementById('articleAuthorAvatar');
  const dateEl = document.getElementById('articleDate');
  const readingTimeEl = document.getElementById('articleReadingTime');
  const heroImgEl = document.getElementById('articleImage');
  const heroCaptionEl = document.getElementById('articleImageCaption');
  const contentEl = document.getElementById('articleContent');
  const authorBoxName = document.getElementById('authorBoxName');
  const authorBoxBio = document.getElementById('authorBoxBio');
  const authorBoxAvatar = document.getElementById('authorBoxAvatar');

  if (!contentEl) return;

  if (categoryEl) categoryEl.textContent = article.category;
  if (titleEl) titleEl.textContent = article.title;
  if (authorNameEl) authorNameEl.textContent = article.author;
  if (authorBioEl) authorBioEl.textContent = article.authorBio || '';
  if (authorAvatarEl && article.authorAvatar) {
    authorAvatarEl.src = article.authorAvatar;
  }

  if (dateEl) {
    const d = new Date(article.date);
    dateEl.textContent = d.toLocaleDateString();
    dateEl.setAttribute('datetime', d.toISOString().split('T')[0]);
  }

  if (heroImgEl) {
    heroImgEl.src = article.image;
    heroImgEl.alt = article.imageCaption || article.title;
  }
  if (heroCaptionEl) {
    heroCaptionEl.textContent = article.imageCaption || '';
  }

  if (authorBoxName) authorBoxName.textContent = article.author;
  if (authorBoxBio) authorBoxBio.textContent = article.authorBio || '';
  if (authorBoxAvatar && article.authorAvatar) {
    authorBoxAvatar.src = article.authorAvatar;
  }

  // Content + reading time
  contentEl.innerHTML = article.contentHtml || '';
  const textOnly = contentEl.textContent || '';
  const minutes = article.readingMinutesOverride || estimateReadingTime(textOnly);
  if (readingTimeEl) readingTimeEl.textContent = `${minutes} min read`;

  // Breadcrumb title and category
  const breadcrumbTitle = document.getElementById('breadcrumbTitle');
  const breadcrumbCategory = document.getElementById('breadcrumbCategory');
  if (breadcrumbTitle) breadcrumbTitle.textContent = article.title;
  if (breadcrumbCategory) breadcrumbCategory.textContent = article.category;

  // Table of contents
  buildTableOfContents(contentEl);

  // Related articles
  const relatedEl = document.getElementById('relatedArticles');
  if (relatedEl) {
    const related = articles
      .filter((a) => a.id !== article.id && a.category === article.category)
      .slice(0, 3);
    relatedEl.innerHTML = '';
    related.forEach((a) => {
      relatedEl.appendChild(createArticleCard(a));
    });
  }

  // Social share
  initShareButtons(article);

  // JSON-LD update
  updateArticleJsonLd(article, minutes);

  initFooterCategories(articles);
}

/**
 * Build table of contents from headings inside article body.
 */
function buildTableOfContents(contentEl) {
  const tocNav = document.getElementById('tocList');
  if (!tocNav) return;

  const headings = contentEl.querySelectorAll('h2, h3');
  if (!headings.length) {
    tocNav.innerHTML = '<p>No sections</p>';
    return;
  }

  tocNav.innerHTML = '';
  headings.forEach((heading) => {
    if (!heading.id) {
      heading.id = slugifyForId(heading.textContent || 'section');
    }
    const a = document.createElement('a');
    a.href = `#${heading.id}`;
    a.textContent = heading.textContent || '';
    if (heading.tagName.toLowerCase() === 'h3') {
      a.style.paddingLeft = '0.75rem';
      a.style.fontSize = '0.84rem';
    }
    tocNav.appendChild(a);
  });

  // Optional scroll spy
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        const id = entry.target.getAttribute('id');
        if (!id) return;
        const link = tocNav.querySelector(`a[href="#${id}"]`);
        if (!link) return;
        if (entry.isIntersecting) {
          tocNav.querySelectorAll('a').forEach((el) => el.classList.remove('active'));
          link.classList.add('active');
        }
      });
    },
    {
      rootMargin: '-40% 0px -50% 0px',
      threshold: 0.1
    }
  );
  headings.forEach((h) => observer.observe(h));
}

/**
 * Update Article JSON-LD block from article data.
 */
function updateArticleJsonLd(article, readingMinutes) {
  const script = document.getElementById('articleJsonLd');
  if (!script) return;

  const url = window.location.href;
  const payload = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    author: {
      '@type': 'Person',
      name: article.author
    },
    publisher: {
      '@type': 'Organization',
      name: 'robgryder'
    },
    image: article.image,
    datePublished: article.date,
    timeRequired: `PT${readingMinutes}M`,
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': url
    },
    description: article.excerpt
  };

  script.textContent = JSON.stringify(payload);
}

/**
 * Footer categories list shared across pages.
 */
function initFooterCategories(articles) {
  const footerList = document.getElementById('footerCategories');
  if (!footerList) return;

  const categories = Array.from(new Set(articles.map((a) => a.category))).sort();
  footerList.innerHTML = '';
  categories.forEach((cat) => {
    const li = document.createElement('li');
    li.innerHTML = `<a href="category.html?category=${encodeURIComponent(cat)}">${cat}</a>`;
    footerList.appendChild(li);
  });
}

/**
 * Live search wiring for header + sidebar search inputs.
 */
function initSearchFiltering(articles, onQueryChange) {
  const globalInput = document.getElementById('globalSearchInput');
  const sidebarInput = document.getElementById('sidebarSearchInput');

  function handler(e) {
    const value = e.target.value || '';
    onQueryChange(value);
  }

  if (globalInput) globalInput.addEventListener('input', handler);
  if (sidebarInput) sidebarInput.addEventListener('input', handler);
}

/**
 * Social share handlers using query URLs and window.open.
 */
function initShareButtons(article) {
  const buttons = document.querySelectorAll('.share-button');
  if (!buttons.length) return;

  const url = window.location.href;
  const text = encodeURIComponent(article.title);

  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const network = btn.getAttribute('data-network');
      let shareUrl = '';
      if (network === 'twitter') {
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${text}`;
      } else if (network === 'linkedin') {
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
      } else if (network === 'facebook') {
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
      }
      if (shareUrl) {
        window.open(shareUrl, '_blank', 'noopener,noreferrer,width=600,height=500');
      }
    });
  });
}

/**
 * Init entrypoint.
 */
document.addEventListener('DOMContentLoaded', () => {
  initThemeToggle();
  initHeaderInteractions();
  initFooter();

  // Ensure footer categories are consistent on *all* pages.
  loadArticles()
    .then((articles) => {
      if (Array.isArray(articles) && articles.length) {
        initFooterCategories(articles);
      }
    })
    .catch((err) => {
      console.error('Failed to load footer categories.', err);
    });

  initHomePage();
  initCategoryPage();
  initArticlePage();

  // Lazy images across all routes
  initLazyImages();
});

