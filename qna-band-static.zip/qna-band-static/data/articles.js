
const articles = [
  {
    id: 1,
    title: "How to Build with Tailwind",
    category: "Development",
    author: "Admin",
    image: "https://source.unsplash.com/800x500/?tailwind,code,ai",
    readTime: "7 min read",
    content:
      "Tailwind CSS lets you design modern interfaces directly in your markup. In this guide we walk through the mental model, setup, and patterns that keep your components clean and consistent across a growing project."
  },
  {
    id: 2,
    title: "Modern UI Trends 2026",
    category: "Design",
    author: "John Carter",
    image: "https://source.unsplash.com/800x500/?design,ui,ai",
    readTime: "5 min read",
    content:
      "From glassmorphism to soft gradients and accessible color systems, UI design in 2026 is all about clarity, motion, and inclusivity. Learn how to apply these trends without sacrificing performance."
  },
  {
    id: 3,
    title: "Writing Articles That People Finish",
    category: "Productivity",
    author: "Alex Morgan",
    image: "https://source.unsplash.com/800x500/?writing,ai",
    readTime: "6 min read",
    content:
      "Attention is the most valuable currency on the web. Structure your posts with strong hooks, clear headings, and purposeful storytelling so readers stay until the very last line."
  },
  {
    id: 4,
    title: "A Practical Guide to Developer Blogging",
    category: "Development",
    author: "Priya Singh",
    image: "https://source.unsplash.com/800x500/?developer,blog,ai",
    readTime: "8 min read",
    content:
      "Developer blogs can accelerate your career, help you remember what you learn, and build trust with your audience. This article covers topics, rhythm, and realistic workflows for busy engineers."
  },
  {
    id: 5,
    title: "Designing Dark Mode the Right Way",
    category: "Design",
    author: "Lena Ortiz",
    image: "https://source.unsplash.com/800x500/?dark,interface,ai",
    readTime: "9 min read",
    content:
      "Dark mode is more than inverting colors. Learn about contrast ratios, elevation, ambient color, and how to keep content legible and comfortable for late‑night readers."
  },
  {
    id: 6,
    title: "From Idea to Published Article in One Evening",
    category: "Productivity",
    author: "Sam Lee",
    image: "https://source.unsplash.com/800x500/?laptop,night,ai",
    readTime: "4 min read",
    content:
      "You don’t need a full weekend to ship a great article. Use this lightweight framework to capture ideas, outline quickly, and publish with confidence in a single focused evening."
  },
  {
    id: 7,
    title: "SEO Basics for Technical Writers",
    category: "Tutorial",
    author: "Nora Adams",
    image: "https://source.unsplash.com/800x500/?seo,analytics,ai",
    readTime: "10 min read",
    content:
      "Search engines love the same things readers do: clarity, structure, and relevance. We break down keywords, intent, internal links, and simple on‑page optimizations tailored for technical blogs."
  },
  {
    id: 8,
    title: "What Makes a Great Knowledge Base?",
    category: "News",
    author: "Editorial Team",
    image: "https://source.unsplash.com/800x500/?knowledge,library,ai",
    readTime: "6 min read",
    content:
      "Teams that document well move faster. Explore how modern knowledge bases blend search, tagging, rich media, and community feedback into one cohesive reading experience."
  }
];
