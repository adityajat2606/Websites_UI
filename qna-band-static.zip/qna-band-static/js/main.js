
const container = document.getElementById("articlesContainer");
const filter = document.getElementById("categoryFilter");
const searchInput = document.getElementById("searchInput");

function renderArticles(list) {
  if (!container) return;
  container.innerHTML = list.map(article => `
    <div class="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-lg hover:border-teal-400 hover:-translate-y-0.5 transition transform overflow-hidden">
      <img src="${article.image}" class="w-full h-48 object-cover">
      <div class="p-6">
        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-500/10 text-teal-300 border border-teal-500/30">
          ${article.category}
        </span>
        <h3 class="text-xl font-semibold mt-3 text-slate-50">${article.title}</h3>
        <p class="text-slate-400 mt-2 text-sm">By ${article.author} • ${article.readTime || "5 min read"}</p>
        <p class="text-slate-300 text-sm mt-3 line-clamp-3">
          ${article.content}
        </p>
        <a href="article.html?id=${article.id}" 
           class="inline-flex items-center mt-5 text-teal-300 hover:text-teal-200 font-medium text-sm">
           Read Article
           <span class="ml-1">↗</span>
        </a>
      </div>
    </div>
  `).join("");
}

function getFilteredArticles() {
  let list = Array.isArray(articles) ? articles : [];

  if (filter && filter.value !== "all") {
    list = list.filter(a => a.category === filter.value);
  }

  if (searchInput && searchInput.value.trim() !== "") {
    const term = searchInput.value.toLowerCase();
    list = list.filter(a =>
      a.title.toLowerCase().includes(term) ||
      a.author.toLowerCase().includes(term) ||
      (a.content && a.content.toLowerCase().includes(term))
    );
  }

  return list;
}

if (container) {
  renderArticles(getFilteredArticles());
}

if (filter) {
  filter.addEventListener("change", () => {
    renderArticles(getFilteredArticles());
  });
}

if (searchInput) {
  searchInput.addEventListener("input", () => {
    renderArticles(getFilteredArticles());
  });
}
