// Simple site-wide day/night theme toggle
(function () {
  const THEME_KEY = "qna_band_theme";

  function getPreferredTheme() {
    const stored = localStorage.getItem(THEME_KEY);
    if (stored === "light" || stored === "dark") return stored;
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      return "dark";
    }
    return "light";
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
  }

  function updateToggleLabels(theme) {
    const toggles = document.querySelectorAll("[data-theme-toggle]");
    const label = theme === "dark" ? "Day" : "Night";
    toggles.forEach((btn) => {
      btn.textContent = label;
    });
  }

  function init() {
    const current = getPreferredTheme();
    applyTheme(current);
    updateToggleLabels(current);

    const toggles = document.querySelectorAll("[data-theme-toggle]");
    toggles.forEach((btn) => {
      btn.addEventListener("click", () => {
        const newTheme = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
        applyTheme(newTheme);
        localStorage.setItem(THEME_KEY, newTheme);
        updateToggleLabels(newTheme);
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

