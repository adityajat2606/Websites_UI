import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { useEffect } from "react";
import Homepage from "./pages/Homepage";
import SearchResults from "./pages/SearchResults";
import BusinessDetails from "./pages/BusinessDetails";
import WriteReview from "./pages/WriteReview";
import UserProfile from "./pages/UserProfile";
import CategoryPage from "./pages/CategoryPage";
import SavedBusinesses from "./pages/SavedBusinesses";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import StaticPage from "./pages/StaticPage";
import { AppStateProvider } from "@/context/appState";

const queryClient = new QueryClient();

const AnimatedRoutes = () => {
  const location = useLocation();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Homepage />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/business/:id" element={<BusinessDetails />} />
        <Route path="/write-review/:id" element={<WriteReview />} />
        <Route path="/profile" element={<UserProfile />} />
        <Route path="/category/:id" element={<CategoryPage />} />
        <Route path="/saved" element={<SavedBusinesses />} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/p/:slug" element={<StaticPage />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AnimatePresence>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AppStateProvider>
        <BrowserRouter>
          <AnimatedRoutes />
        </BrowserRouter>
      </AppStateProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
