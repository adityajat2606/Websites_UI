import { Link } from "react-router-dom";
import { MapPin, Mail, Phone } from "lucide-react";
import { getDynamicCategories } from "@/data/businesses";

const companyLinks = [
  { label: "About Us", slug: "about-us" },
  { label: "Careers", slug: "careers" },
  { label: "Press", slug: "press" },
  { label: "Blog", slug: "blog" },
  { label: "Terms", slug: "terms" },
  { label: "Privacy", slug: "privacy" },
] as const;

const Footer = () => {
  const categories = getDynamicCategories();

  return (
    <footer className="bg-foreground text-primary-foreground/80">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-display font-black text-lg">L</span>
              </div>
              <span className="font-display font-bold text-xl text-primary-foreground">Locale</span>
            </Link>
            <p className="text-sm text-primary-foreground/60 leading-relaxed">
              Discover the best local businesses in your area. Trusted reviews from real people.
            </p>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-display font-bold text-primary-foreground mb-4">Categories</h4>
            <ul className="space-y-2.5">
              {categories.map((cat) => (
                <li key={cat.id}>
                  <Link to={`/category/${cat.id}`} className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-display font-bold text-primary-foreground mb-4">Company</h4>
            <ul className="space-y-2.5">
              {companyLinks.map((item) => (
                <li key={item.slug}>
                  <Link to={`/p/${item.slug}`} className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-bold text-primary-foreground mb-4">Contact</h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="https://www.google.com/maps?q=San+Francisco,+CA"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 text-sm text-primary-foreground/60 hover:text-primary transition-colors"
                >
                  <MapPin size={14} /> San Francisco, CA
                </a>
              </li>
              <li>
                <a
                  href="mailto:hello@locale.com"
                  className="flex items-center gap-2 text-sm text-primary-foreground/60 hover:text-primary transition-colors"
                >
                  <Mail size={14} /> hello@locale.com
                </a>
              </li>
              <li>
                <a
                  href="tel:+14155550000"
                  className="flex items-center gap-2 text-sm text-primary-foreground/60 hover:text-primary transition-colors"
                >
                  <Phone size={14} /> (415) 555-0000
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 mt-12 pt-8 text-center">
          <p className="text-sm text-primary-foreground/40">
            © 2026 Locale. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
