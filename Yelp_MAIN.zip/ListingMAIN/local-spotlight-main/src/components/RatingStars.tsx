import { Star, StarHalf } from "lucide-react";

interface RatingStarsProps {
  rating: number;
  size?: number;
  showValue?: boolean;
}

const RatingStars = ({ rating, size = 16, showValue = false }: RatingStarsProps) => {
  const fullStars = Math.floor(rating);
  const hasHalf = rating % 1 >= 0.3;
  const emptyStars = 5 - fullStars - (hasHalf ? 1 : 0);

  return (
    <div className="flex items-center gap-1">
      <div className="flex">
        {Array.from({ length: fullStars }).map((_, i) => (
          <Star key={`full-${i}`} size={size} className="fill-primary text-primary" />
        ))}
        {hasHalf && <StarHalf size={size} className="fill-primary text-primary" />}
        {Array.from({ length: emptyStars }).map((_, i) => (
          <Star key={`empty-${i}`} size={size} className="text-muted-foreground/30" />
        ))}
      </div>
      {showValue && (
        <span className="text-sm font-semibold text-foreground ml-1">{rating.toFixed(1)}</span>
      )}
    </div>
  );
};

export default RatingStars;
