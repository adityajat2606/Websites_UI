import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, User, Bookmark } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import SearchBar from "./SearchBar";
import { Button } from "@/components/ui/button";
import { useAppState } from "@/context/appState";
import { toast } from "sonner";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === "/";
  const navigate = useNavigate();
  const { auth, profile, logout } = useAppState();

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 ${isHome ? "bg-transparent absolute w-full" : "bg-card/95 backdrop-blur-md border-b border-border shadow-card"}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-display font-black text-lg">L</span>
            </div>
            <span className={`font-display font-bold text-xl ${isHome ? "text-primary-foreground" : "text-foreground"}`}>
              Locale
            </span>
          </Link>

          {/* Desktop search - hidden on home */}
          {!isHome && (
            <div className="hidden md:block flex-1 max-w-md mx-8">
              <SearchBar variant="navbar" />
            </div>
          )}

          {/* Desktop nav - visible on all screen sizes so Sign Up / Log In are always visible */}
          <div className="flex items-center gap-2 shrink-0">
            {auth.isLoggedIn && (
              <Link to="/saved">
                <Button variant="ghost" size="sm" className={isHome ? "text-primary-foreground hover:bg-primary-foreground/10" : ""}>
                  <Bookmark size={16} className="mr-1.5" />
                  Saved
                </Button>
              </Link>
            )}
            {auth.isLoggedIn && (
              <Link to="/profile">
                <Button variant="ghost" size="sm" className={isHome ? "text-primary-foreground hover:bg-primary-foreground/10" : ""}>
                  <User size={16} className="mr-1.5" />
                  {profile?.name ?? "Profile"}
                </Button>
              </Link>
            )}
            {auth.isLoggedIn ? (
              <Button
                variant="outline"
                size="sm"
                className={`font-semibold ${isHome ? "border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" : ""}`}
                onClick={() => {
                  logout();
                  toast.success("Signed out.");
                  navigate("/");
                }}
              >
                Log Out
              </Button>
            ) : (
              <>
                <Button size="sm" className="font-semibold" onClick={() => navigate("/auth?mode=login")}>
                  Log In
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className={`font-semibold ${isHome ? "border-[rgba(215,25,25,0.3)] text-primary-foreground hover:bg-primary-foreground/10" : ""}`}
                  onClick={() => navigate("/auth?mode=signup")}
                >
                  Sign Up
                </Button>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? (
              <X size={24} className={isHome ? "text-primary-foreground" : "text-foreground"} />
            ) : (
              <Menu size={24} className={isHome ? "text-primary-foreground" : "text-foreground"} />
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-card border-b border-border overflow-hidden"
          >
            <div className="p-4 space-y-3">
              {!isHome && <SearchBar variant="navbar" />}
              {auth.isLoggedIn && (
                <Link to="/saved" onClick={() => setMobileOpen(false)} className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-secondary text-foreground">
                  <Bookmark size={18} /> Saved
                </Link>
              )}
              {auth.isLoggedIn && (
                <Link to="/profile" onClick={() => setMobileOpen(false)} className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-secondary text-foreground">
                  <User size={18} /> {profile?.name ?? "Profile"}
                </Link>
              )}
              <div className="flex gap-2 pt-2">
                {auth.isLoggedIn ? (
                  <Button
                    variant="outline"
                    className="flex-1 font-semibold"
                    size="sm"
                    onClick={() => {
                      setMobileOpen(false);
                      logout();
                      toast.success("Signed out.");
                      navigate("/");
                    }}
                  >
                    Log Out
                  </Button>
                ) : (
                  <>
                    <Button
                      className="flex-1 font-semibold"
                      size="sm"
                      onClick={() => {
                        setMobileOpen(false);
                        navigate("/auth?mode=login");
                      }}
                    >
                      Log In
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1 font-semibold"
                      size="sm"
                      onClick={() => {
                        setMobileOpen(false);
                        navigate("/auth?mode=signup");
                      }}
                    >
                      Sign Up
                    </Button>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
