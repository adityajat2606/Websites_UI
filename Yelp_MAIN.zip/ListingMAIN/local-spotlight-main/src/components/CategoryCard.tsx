import { motion } from "framer-motion";
import { UtensilsCrossed, Coffee, Wine, ShoppingBag, Sparkles, Wrench } from "lucide-react";
import { Link } from "react-router-dom";

const iconMap: Record<string, React.ReactNode> = {
  UtensilsCrossed: <UtensilsCrossed size={28} />,
  Coffee: <Coffee size={28} />,
  Wine: <Wine size={28} />,
  ShoppingBag: <ShoppingBag size={28} />,
  Sparkles: <Sparkles size={28} />,
  Wrench: <Wrench size={28} />,
};

interface CategoryCardProps {
  id: string;
  name: string;
  icon: string;
  count: number;
  color: string;
  index?: number;
}

const CategoryCard = ({ id, name, icon, count, color, index = 0 }: CategoryCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
    >
      <Link to={`/category/${id}`}>
        <motion.div
          whileHover={{ scale: 1.03, y: -2 }}
          className="relative overflow-hidden rounded-2xl p-6 cursor-pointer group"
        >
          <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-10 group-hover:opacity-20 transition-opacity`} />
          <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center text-primary-foreground mb-4`}>
            {iconMap[icon]}
          </div>
          <h3 className="font-display font-bold text-lg text-foreground mb-1">{name}</h3>
          <p className="text-sm text-muted-foreground">{count.toLocaleString()} businesses</p>
        </motion.div>
      </Link>
    </motion.div>
  );
};

export default CategoryCard;
