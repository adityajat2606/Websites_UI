import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Business } from "@/data/businesses";

// Fix default marker icon
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

interface LeafletMapProps {
  businesses: Business[];
  center?: [number, number];
  zoom?: number;
  className?: string;
  singleBusiness?: boolean;
}

const LeafletMap = ({
  businesses,
  center,
  zoom = 13,
  className = "h-full w-full",
  singleBusiness = false,
}: LeafletMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const defaultCenter: [number, number] = center || [37.7749, -122.4194];

    const map = L.map(mapRef.current).setView(defaultCenter, zoom);
    mapInstanceRef.current = map;

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    businesses.forEach((biz) => {
      const marker = L.marker([biz.lat, biz.lng]).addTo(map);
      marker.bindPopup(
        `<div style="min-width:150px">
          <strong>${biz.name}</strong><br/>
          <span style="color:#666">${biz.category} · ${biz.priceRange}</span><br/>
          <span>⭐ ${biz.rating} (${biz.reviewCount})</span>
        </div>`
      );
    });

    if (businesses.length > 1 && !singleBusiness) {
      const bounds = L.latLngBounds(businesses.map((b) => [b.lat, b.lng]));
      map.fitBounds(bounds, { padding: [40, 40] });
    }

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, [businesses, center, zoom, singleBusiness]);

  return <div ref={mapRef} className={className} />;
};

export default LeafletMap;
