import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ThumbsUp, MessageCircle, Reply, Pencil, Trash2, Send, Star, ImagePlus, X } from "lucide-react";
import RatingStars from "./RatingStars";
import { Review } from "@/data/reviews";
import type { ReviewComment } from "@/data/reviews";
import { useAppState } from "@/context/appState";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import ImageLightbox from "./ImageLightbox";
import { toast } from "sonner";

const MAX_COMMENT_IMAGES = 3;

interface ReviewCardProps {
  review: Review;
  index?: number;
}

const CommentBlock = ({
  comment,
  replies,
  currentUserEmail,
  onReply,
  updateComment,
  deleteComment,
  onImageClick,
}: {
  comment: ReviewComment;
  replies: ReviewComment[];
  currentUserEmail: string | null;
  onReply: (parentId: string) => void;
  updateComment: (id: string, payload: Partial<Pick<ReviewComment, "text" | "images">>) => void;
  deleteComment: (id: string) => void;
  onImageClick: (src: string) => void;
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");

  const isOwn = currentUserEmail !== null && comment.authorId === currentUserEmail;

  const startEdit = () => {
    setEditingId(comment.id);
    setEditText(comment.text);
  };

  const saveEdit = () => {
    if (!editText.trim()) return;
    updateComment(comment.id, { text: editText.trim() });
    setEditingId(null);
    setEditText("");
  };

  const images = comment.images ?? [];

  return (
    <div className={comment.parentId ? "ml-6 mt-2 pl-3 border-l-2 border-border" : ""}>
      <div className="flex items-start gap-2 py-1.5">
        <img
          src={comment.authorAvatar}
          alt={comment.authorName}
          className="w-7 h-7 rounded-full object-cover shrink-0"
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-card-foreground text-sm">{comment.authorName}</span>
            <span className="text-xs text-muted-foreground">
              {new Date(comment.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
            </span>
            {isOwn && (
              <span className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={startEdit}
                  className="text-xs text-muted-foreground hover:text-foreground p-0.5"
                  aria-label="Edit comment"
                >
                  <Pencil size={12} />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (confirm("Delete this comment?")) {
                      deleteComment(comment.id);
                    }
                  }}
                  className="text-xs text-muted-foreground hover:text-destructive p-0.5"
                  aria-label="Delete comment"
                >
                  <Trash2 size={12} />
                </button>
              </span>
            )}
            {!isOwn && currentUserEmail && (
              <button
                type="button"
                onClick={() => onReply(comment.id)}
                className="text-xs text-primary hover:underline flex items-center gap-0.5"
              >
                <Reply size={11} /> Reply
              </button>
            )}
          </div>
          {editingId === comment.id ? (
            <div className="mt-1 space-y-2">
              <Textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className="min-h-[60px] text-sm"
                autoFocus
              />
              <div className="flex gap-2">
                <Button size="sm" onClick={saveEdit} className="h-7 text-xs">
                  Save
                </Button>
                <Button size="sm" variant="ghost" onClick={() => { setEditingId(null); setEditText(""); }} className="h-7 text-xs">
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <>
              <p className="text-sm text-card-foreground leading-relaxed mt-0.5">{comment.text}</p>
              {images.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {images.map((src, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => onImageClick(src)}
                      className="focus:outline-none focus:ring-2 focus:ring-primary rounded-lg overflow-hidden"
                    >
                      <img src={src} alt="" className="w-20 h-20 object-cover rounded-lg cursor-pointer hover:opacity-90" />
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
      {replies.map((r) => (
        <CommentBlock
          key={r.id}
          comment={r}
          replies={[]}
          currentUserEmail={currentUserEmail}
          onReply={onReply}
          updateComment={updateComment}
          deleteComment={deleteComment}
          onImageClick={onImageClick}
        />
      ))}
    </div>
  );
};

const ReviewCard = ({ review, index = 0 }: ReviewCardProps) => {
  const { profile, userReviews, reviewComments, addComment, updateComment, deleteComment, updateReview, deleteReview, toggleHelpful, isHelpful } = useAppState();
  const [showComments, setShowComments] = useState(false);
  const [newCommentText, setNewCommentText] = useState("");
  const [newCommentImages, setNewCommentImages] = useState<string[]>([]);
  const [replyToId, setReplyToId] = useState<string | null>(null);
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [editingReview, setEditingReview] = useState(false);
  const [editRating, setEditRating] = useState(review.rating);
  const [editText, setEditText] = useState(review.text);
  const [editImages, setEditImages] = useState<string[]>(review.images ?? []);
  const commentFileRef = useRef<HTMLInputElement>(null);
  const reviewEditFileRef = useRef<HTMLInputElement>(null);

  const currentUserEmail = profile?.email ?? null;
  const isOwnReview = Boolean(
    profile && userReviews.some((r) => r.id === review.id) && (review.userId === profile.email || review.userId === "me" || review.userId === "guest")
  );

  const commentsForReview = reviewComments.filter((c) => c.reviewId === review.id);
  const topLevel = commentsForReview.filter((c) => c.parentId === null);
  const repliesByParent = commentsForReview.reduce<Record<string, ReviewComment[]>>((acc, c) => {
    if (c.parentId) {
      if (!acc[c.parentId]) acc[c.parentId] = [];
      acc[c.parentId].push(c);
    }
    return acc;
  }, {});

  const helpful = isHelpful(review.id);

  const openLightbox = (src: string) => {
    setLightboxSrc(src);
    setLightboxOpen(true);
  };

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    const text = newCommentText.trim();
    if (!text) return;
    if (!profile) {
      toast.error("Sign in to comment");
      return;
    }
    addComment({
      id: `comment-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      reviewId: review.id,
      parentId: replyToId,
      authorId: profile.email,
      authorName: profile.name,
      authorAvatar: profile.avatar,
      text,
      date: new Date().toISOString(),
      images: newCommentImages.length > 0 ? newCommentImages : undefined,
    });
    setNewCommentText("");
    setNewCommentImages([]);
    setReplyToId(null);
    if (!showComments) setShowComments(true);
  };

  const handleCommentImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files?.length) return;
    const remaining = MAX_COMMENT_IMAGES - newCommentImages.length;
    Array.from(files)
      .slice(0, remaining)
      .forEach((file) => {
        if (!file.type.startsWith("image/")) return;
        const reader = new FileReader();
        reader.onload = () => {
          setNewCommentImages((prev) => [...prev, reader.result as string].slice(0, MAX_COMMENT_IMAGES));
        };
        reader.readAsDataURL(file);
      });
    e.target.value = "";
  };

  const handleSaveReviewEdit = () => {
    updateReview(review.id, { rating: editRating, text: editText.trim() || review.text, images: editImages });
    setEditingReview(false);
    toast.success("Review updated");
  };

  const handleDeleteReview = () => {
    if (!confirm("Delete this review? This cannot be undone.")) return;
    deleteReview(review.id);
    toast.success("Review deleted");
  };

  const displayRating = editRating;
  const ratingLabels = ["", "Not good", "Could be better", "OK", "Good", "Great!"];

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3, delay: index * 0.1 }}
        className="bg-card rounded-xl p-5 shadow-card"
      >
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <img
              src={review.userAvatar}
              alt={review.userName}
              className="w-10 h-10 rounded-full object-cover"
            />
            <div>
              <p className="font-semibold text-card-foreground text-sm">{review.userName}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(review.date).toLocaleDateString("en-US", {
                  month: "long",
                  day: "numeric",
                  year: "numeric",
                })}
              </p>
            </div>
          </div>
          {isOwnReview && !editingReview && (
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  setEditingReview(true);
                  setEditRating(review.rating);
                  setEditText(review.text);
                  setEditImages(review.images ?? []);
                }}
                className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-secondary"
                aria-label="Edit review"
              >
                <Pencil size={14} />
              </button>
              <button
                type="button"
                onClick={handleDeleteReview}
                className="p-1.5 rounded text-muted-foreground hover:text-destructive hover:bg-secondary"
                aria-label="Delete review"
              >
                <Trash2 size={14} />
              </button>
            </div>
          )}
        </div>

        {editingReview ? (
          <div className="space-y-4 mb-4">
            <div>
              <p className="text-xs text-muted-foreground mb-2">Rating</p>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setEditRating(star)}
                    className="p-0.5"
                  >
                    <Star
                      size={22}
                      className={star <= displayRating ? "fill-primary text-primary" : "text-muted-foreground/40"}
                    />
                  </button>
                ))}
                {displayRating > 0 && <span className="text-xs text-muted-foreground ml-1">{ratingLabels[displayRating]}</span>}
              </div>
            </div>
            <Textarea
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              className="min-h-[80px] text-sm"
              placeholder="Your review..."
            />
            <div>
              <p className="text-xs text-muted-foreground mb-2">Photos</p>
              <input
                ref={reviewEditFileRef}
                type="file"
                accept="image/*"
                multiple
                className="sr-only"
                onChange={(e) => {
                  const files = e.target.files;
                  if (!files?.length) return;
                  const remaining = 5 - editImages.length;
                  Array.from(files).slice(0, remaining).forEach((file) => {
                    if (!file.type.startsWith("image/")) return;
                    const reader = new FileReader();
                    reader.onload = () => setEditImages((p) => [...p, reader.result as string].slice(0, 5));
                    reader.readAsDataURL(file);
                  });
                  e.target.value = "";
                }}
              />
              <div className="flex flex-wrap gap-2">
                {editImages.map((src, i) => (
                  <div key={i} className="relative">
                    <button type="button" onClick={() => openLightbox(src)}>
                      <img src={src} alt="" className="w-20 h-20 rounded-lg object-cover" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditImages((p) => p.filter((_, j) => j !== i))}
                      className="absolute -top-1 -right-1 p-0.5 rounded-full bg-destructive text-destructive-foreground"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
                {editImages.length < 5 && (
                  <button
                    type="button"
                    onClick={() => reviewEditFileRef.current?.click()}
                    className="w-20 h-20 rounded-lg border-2 border-dashed border-border flex items-center justify-center text-muted-foreground hover:border-primary/50"
                  >
                    <ImagePlus size={24} />
                  </button>
                )}
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={handleSaveReviewEdit}>
                Save
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setEditingReview(false)}>
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-3">
              <RatingStars rating={review.rating} size={14} />
            </div>
            <p className="text-sm text-card-foreground leading-relaxed mb-3">{review.text}</p>
            {review.images && review.images.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {review.images.map((img, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => openLightbox(img)}
                    className="focus:outline-none focus:ring-2 focus:ring-primary rounded-lg overflow-hidden"
                  >
                    <img
                      src={img}
                      alt="Review"
                      className="w-24 h-20 rounded-lg object-cover cursor-pointer hover:opacity-90"
                    />
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {!editingReview && (
          <>
            <div className="flex items-center gap-4 flex-wrap">
              <button
                type="button"
                onClick={() => toggleHelpful(review.id)}
                className={`flex items-center gap-1.5 text-xs transition-colors ${helpful ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
              >
                <ThumbsUp size={13} className={helpful ? "fill-current" : ""} />
                Helpful ({review.helpful + (helpful ? 1 : 0)})
              </button>
              <button
                type="button"
                onClick={() => setShowComments(!showComments)}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                <MessageCircle size={13} />
                {commentsForReview.length} {commentsForReview.length === 1 ? "comment" : "comments"}
              </button>
            </div>

            {showComments && (
              <div className="mt-4 pt-4 border-t border-border space-y-3">
                {topLevel.map((c) => (
                  <CommentBlock
                    key={c.id}
                    comment={c}
                    replies={repliesByParent[c.id] ?? []}
                    currentUserEmail={currentUserEmail}
                    onReply={setReplyToId}
                    updateComment={updateComment}
                    deleteComment={deleteComment}
                    onImageClick={openLightbox}
                  />
                ))}

                <form onSubmit={handleSubmitComment} className="flex gap-2 mt-3">
                  {profile ? (
                    <>
                      <img src={profile.avatar} alt="" className="w-7 h-7 rounded-full object-cover shrink-0" />
                      <div className="flex-1 flex flex-col gap-2">
                        {replyToId && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            Replying to comment
                            <button type="button" onClick={() => setReplyToId(null)} className="text-primary hover:underline">
                              Cancel
                            </button>
                          </p>
                        )}
                        <Textarea
                          value={newCommentText}
                          onChange={(e) => setNewCommentText(e.target.value)}
                          placeholder={replyToId ? "Write a reply..." : "Add a comment..."}
                          className="min-h-[60px] text-sm resize-none"
                        />
                        <div className="flex flex-wrap items-center gap-2">
                          <input
                            ref={commentFileRef}
                            type="file"
                            accept="image/*"
                            multiple
                            className="sr-only"
                            onChange={handleCommentImageChange}
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="gap-1 h-7 text-xs"
                            onClick={() => commentFileRef.current?.click()}
                            disabled={newCommentImages.length >= MAX_COMMENT_IMAGES}
                          >
                            <ImagePlus size={12} /> Photo {newCommentImages.length > 0 && `(${newCommentImages.length}/${MAX_COMMENT_IMAGES})`}
                          </Button>
                          {newCommentImages.map((src, i) => (
                            <div key={i} className="relative">
                              <button type="button" onClick={() => openLightbox(src)}>
                                <img src={src} alt="" className="w-10 h-10 rounded object-cover" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setNewCommentImages((p) => p.filter((_, j) => j !== i))}
                                className="absolute -top-0.5 -right-0.5 p-0.5 rounded-full bg-destructive text-destructive-foreground"
                              >
                                <X size={10} />
                              </button>
                            </div>
                          ))}
                          <Button type="submit" size="sm" className="gap-1" disabled={!newCommentText.trim()}>
                            <Send size={12} /> {replyToId ? "Reply" : "Comment"}
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      <Link to="/auth?mode=signup" className="text-primary hover:underline font-medium">Sign in</Link> to comment or reply.
                    </p>
                  )}
                </form>
              </div>
            )}
          </>
        )}
      </motion.div>

      <ImageLightbox src={lightboxSrc} open={lightboxOpen} onOpenChange={setLightboxOpen} />
    </>
  );
};

export default ReviewCard;
