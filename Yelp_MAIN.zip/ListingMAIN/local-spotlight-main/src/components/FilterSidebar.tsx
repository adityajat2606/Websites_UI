import { useState, useEffect } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Star, ChevronDown, ChevronUp } from "lucide-react";
import type { BusinessFilters } from "@/types/filters";

interface FilterSidebarProps {
  filters?: BusinessFilters;
  onFilterChange?: (filters: BusinessFilters) => void;
}

const priceOptions = ["$", "$$", "$$$", "$$$$"];
const categoryOptions = ["Restaurants", "Cafes", "Nightlife", "Shopping", "Beauty", "Home Services"];

const FilterSidebar = ({ filters: controlledFilters, onFilterChange }: FilterSidebarProps) => {
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    rating: true,
    price: true,
    category: true,
    features: true,
  });
  const [selectedRating, setSelectedRating] = useState(controlledFilters?.minRating ?? 0);
  const [selectedPrice, setSelectedPrice] = useState<string[]>(controlledFilters?.priceRange ?? []);
  const [selectedCategories, setSelectedCategories] = useState<string[]>(controlledFilters?.categories ?? []);
  const [distance, setDistance] = useState([controlledFilters?.maxDistanceMiles ?? 5]);
  const [openNow, setOpenNow] = useState(controlledFilters?.openNow ?? false);

  useEffect(() => {
    onFilterChange?.({
      minRating: selectedRating,
      priceRange: selectedPrice,
      categories: selectedCategories,
      maxDistanceMiles: distance[0],
      openNow,
    });
  }, [selectedRating, selectedPrice, selectedCategories, distance, openNow, onFilterChange]);

  const toggleSection = (section: string) => {
    setOpenSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const toggleCategory = (cat: string) => {
    setSelectedCategories((prev) =>
      prev.includes(cat) ? prev.filter((x) => x !== cat) : [...prev, cat]
    );
  };

  return (
    <div className="bg-card rounded-xl p-5 shadow-card space-y-5">
      <h3 className="font-display font-bold text-lg text-card-foreground">Filters</h3>

      {/* Rating */}
      <div>
        <button onClick={() => toggleSection("rating")} className="flex items-center justify-between w-full text-sm font-semibold text-card-foreground mb-3">
          Rating {openSections.rating ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        {openSections.rating && (
          <div className="space-y-2">
            <button
              onClick={() => setSelectedRating(0)}
              className={`flex items-center gap-2 w-full text-sm px-2 py-1.5 rounded-lg transition-colors ${selectedRating === 0 ? "bg-primary/10 text-primary" : "hover:bg-secondary text-card-foreground"}`}
            >
              Any rating
            </button>
            {[5, 4, 3, 2].map((r) => (
              <button
                key={r}
                onClick={() => setSelectedRating(r)}
                className={`flex items-center gap-2 w-full text-sm px-2 py-1.5 rounded-lg transition-colors ${selectedRating === r ? "bg-primary/10 text-primary" : "hover:bg-secondary text-card-foreground"}`}
              >
                <div className="flex">
                  {Array.from({ length: r }).map((_, i) => (
                    <Star key={i} size={14} className="fill-primary text-primary" />
                  ))}
                </div>
                <span>& up</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Price */}
      <div>
        <button onClick={() => toggleSection("price")} className="flex items-center justify-between w-full text-sm font-semibold text-card-foreground mb-3">
          Price Range {openSections.price ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        {openSections.price && (
          <div className="flex gap-2">
            {priceOptions.map((p) => (
              <button
                key={p}
                onClick={() => setSelectedPrice((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]))}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${selectedPrice.includes(p) ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"}`}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Category */}
      <div>
        <button onClick={() => toggleSection("category")} className="flex items-center justify-between w-full text-sm font-semibold text-card-foreground mb-3">
          Category {openSections.category ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        {openSections.category && (
          <div className="space-y-2.5">
            {categoryOptions.map((cat) => (
              <label key={cat} className="flex items-center gap-2.5 text-sm text-card-foreground cursor-pointer">
                <Checkbox
                  checked={selectedCategories.includes(cat)}
                  onCheckedChange={() => toggleCategory(cat)}
                />
                {cat}
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Distance & Open Now */}
      <div>
        <button onClick={() => toggleSection("features")} className="flex items-center justify-between w-full text-sm font-semibold text-card-foreground mb-3">
          Distance {openSections.features ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        {openSections.features && (
          <div className="space-y-3">
            <Slider value={distance} onValueChange={setDistance} max={25} step={1} />
            <p className="text-sm text-muted-foreground">Within {distance[0]} miles</p>
            <label className="flex items-center gap-2.5 text-sm text-card-foreground cursor-pointer">
              <Checkbox checked={openNow} onCheckedChange={(checked) => setOpenNow(checked === true)} />
              Open Now
            </label>
          </div>
        )}
      </div>
    </div>
  );
};

export default FilterSidebar;
