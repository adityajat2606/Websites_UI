import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, X } from "lucide-react";

interface PhotoGalleryProps {
  images: string[];
  businessName: string;
}

const PhotoGallery = ({ images, businessName }: PhotoGalleryProps) => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 h-64 md:h-80">
        {images.slice(0, 4).map((img, i) => (
          <div
            key={i}
            className={`relative overflow-hidden cursor-pointer ${i === 0 ? "col-span-2 row-span-2 md:col-span-2" : ""}`}
            onClick={() => setSelectedIndex(i)}
          >
            <img
              src={img}
              alt={`${businessName} photo ${i + 1}`}
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
            />
            {i === 3 && images.length > 4 && (
              <div className="absolute inset-0 bg-foreground/50 flex items-center justify-center">
                <span className="text-primary-foreground font-display font-bold text-lg">
                  +{images.length - 4} more
                </span>
              </div>
            )}
          </div>
        ))}
      </div>

      <AnimatePresence>
        {selectedIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-foreground/90 flex items-center justify-center p-4"
            onClick={() => setSelectedIndex(null)}
          >
            <button className="absolute top-4 right-4 text-primary-foreground p-2" onClick={() => setSelectedIndex(null)}>
              <X size={28} />
            </button>
            <button
              className="absolute left-4 text-primary-foreground p-2"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedIndex(selectedIndex > 0 ? selectedIndex - 1 : images.length - 1);
              }}
            >
              <ChevronLeft size={32} />
            </button>
            <motion.img
              key={selectedIndex}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              src={images[selectedIndex]}
              alt={`${businessName} photo`}
              className="max-w-full max-h-[80vh] rounded-xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
            <button
              className="absolute right-4 text-primary-foreground p-2"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedIndex(selectedIndex < images.length - 1 ? selectedIndex + 1 : 0);
              }}
            >
              <ChevronRight size={32} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default PhotoGallery;
