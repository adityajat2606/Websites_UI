import { motion } from "framer-motion";
import { MapPin, Bookmark, BookmarkCheck } from "lucide-react";
import { Link } from "react-router-dom";
import RatingStars from "./RatingStars";
import { Business } from "@/data/businesses";
import { Badge } from "@/components/ui/badge";
import { useAppState } from "@/context/appState";

interface BusinessCardProps {
  business: Business;
  index?: number;
}

const BusinessCard = ({ business, index = 0 }: BusinessCardProps) => {
  const { isSaved, toggleSaved } = useAppState();
  const saved = isSaved(business.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
      whileHover={{ y: -4 }}
      className="group"
    >
      <Link to={`/business/${business.id}`} className="block">
        <div className="bg-card rounded-xl overflow-hidden shadow-card transition-shadow duration-300 group-hover:shadow-card-hover">
          <div className="relative h-48 overflow-hidden">
            <img
              src={business.image}
              alt={business.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute top-3 right-3">
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  toggleSaved(business.id);
                }}
                className="p-2 rounded-full bg-card/80 backdrop-blur-sm transition-colors hover:bg-card"
                aria-label={saved ? "Unsave" : "Save"}
              >
                {saved ? (
                  <BookmarkCheck size={18} className="text-primary" />
                ) : (
                  <Bookmark size={18} className="text-foreground" />
                )}
              </button>
            </div>
            {business.isOpen && (
              <Badge className="absolute bottom-3 left-3 bg-green-500/90 text-primary-foreground border-0 backdrop-blur-sm">
                Open Now
              </Badge>
            )}
          </div>
          <div className="p-4">
            <div className="flex items-start justify-between mb-1">
              <h3 className="font-display font-bold text-card-foreground group-hover:text-primary transition-colors line-clamp-1">
                {business.name}
              </h3>
              <span className="text-sm text-muted-foreground font-medium ml-2 shrink-0">
                {business.priceRange}
              </span>
            </div>
            <div className="flex items-center gap-2 mb-2">
              <RatingStars rating={business.rating} size={14} />
              <span className="text-sm text-muted-foreground">({business.reviewCount})</span>
            </div>
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <span className="text-primary font-medium">{business.category}</span>
              <span>·</span>
              <MapPin size={13} />
              <span className="line-clamp-1">{business.location}</span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default BusinessCard;
