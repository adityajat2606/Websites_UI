import { Search, MapPin } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface SearchBarProps {
  variant?: "hero" | "navbar";
  defaultQuery?: string;
  defaultLocation?: string;
}

const SearchBar = ({ variant = "navbar", defaultQuery = "", defaultLocation = "" }: SearchBarProps) => {
  const [query, setQuery] = useState(defaultQuery);
  const [location, setLocation] = useState(defaultLocation || "San Francisco, CA");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/search?q=${encodeURIComponent(query)}&location=${encodeURIComponent(location)}`);
  };

  if (variant === "hero") {
    return (
      <form onSubmit={handleSearch} className="w-full max-w-3xl mx-auto">
        <div className="flex flex-col sm:flex-row bg-card rounded-2xl shadow-elevated p-2 gap-2">
          <div className="flex items-center flex-1 px-4 py-2 gap-3 border-b sm:border-b-0 sm:border-r border-border">
            <Search size={20} className="text-muted-foreground shrink-0" />
            <input
              type="text"
              placeholder="Restaurants, cafes, services..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-transparent outline-none text-foreground placeholder:text-muted-foreground font-body"
            />
          </div>
          <div className="flex items-center flex-1 px-4 py-2 gap-3">
            <MapPin size={20} className="text-muted-foreground shrink-0" />
            <input
              type="text"
              placeholder="City, neighborhood..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full bg-transparent outline-none text-foreground placeholder:text-muted-foreground font-body"
            />
          </div>
          <Button type="submit" size="lg" className="rounded-xl px-8 font-semibold text-base">
            Search
          </Button>
        </div>
      </form>
    );
  }

  return (
    <form onSubmit={handleSearch} className="flex items-center gap-0 bg-secondary rounded-lg overflow-hidden">
      <div className="flex items-center px-3 py-2 gap-2 flex-1">
        <Search size={16} className="text-muted-foreground shrink-0" />
        <input
          type="text"
          placeholder="Search businesses..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full bg-transparent outline-none text-sm text-foreground placeholder:text-muted-foreground"
        />
      </div>
      <Button type="submit" size="sm" className="rounded-none rounded-r-lg h-full">
        <Search size={16} />
      </Button>
    </form>
  );
};

export default SearchBar;
