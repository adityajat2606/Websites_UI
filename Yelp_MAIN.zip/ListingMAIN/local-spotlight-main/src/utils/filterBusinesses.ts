import type { Business } from "@/data/businesses";
import type { BusinessFilters } from "@/types/filters";

function parseDistanceMiles(distanceStr: string): number {
  const match = distanceStr.match(/[\d.]+/);
  return match ? parseFloat(match[0]) : Infinity;
}

export function applyFilters(businesses: Business[], filters: BusinessFilters): Business[] {
  return businesses.filter((b) => {
    if (filters.minRating > 0 && b.rating < filters.minRating) return false;
    if (filters.priceRange.length > 0 && !filters.priceRange.includes(b.priceRange)) return false;
    if (filters.categories.length > 0) {
      const matchesCategory =
        filters.categories.includes(b.category) ||
        b.categories.some((c) => filters.categories.includes(c));
      if (!matchesCategory) return false;
    }
    if (filters.maxDistanceMiles > 0 && filters.maxDistanceMiles < 25) {
      const miles = parseDistanceMiles(b.distance);
      if (miles > filters.maxDistanceMiles) return false;
    }
    if (filters.openNow && !b.isOpen) return false;
    return true;
  });
}
