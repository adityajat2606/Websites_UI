import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { businesses } from "@/data/businesses";
import type { Review, ReviewComment } from "@/data/reviews";

export type Profile = {
  name: string;
  email: string;
  joinDate: string;
  bio: string;
  location: string;
  avatar: string;
};

type AuthState =
  | { isLoggedIn: false }
  | { isLoggedIn: true; name: string; email: string };

type AppStateContextValue = {
  auth: AuthState;
  profile: Profile | null;
  login: (payload: { name: string; email: string; password: string }) => Promise<boolean>;
  signup: (payload: { name: string; email: string; password: string }) => Promise<boolean>;
  logout: () => void;
  updateProfile: (partial: Partial<Profile>) => void;
  authenticate: (email: string, password: string) => Promise<boolean>;

  savedBusinessIds: Set<string>;
  isSaved: (businessId: string) => boolean;
  toggleSaved: (businessId: string) => void;

  helpfulReviewIds: Set<string>;
  isHelpful: (reviewId: string) => boolean;
  toggleHelpful: (reviewId: string) => void;

  userReviews: Review[];
  addReview: (review: Review) => void;
  updateReview: (id: string, payload: Partial<Pick<Review, "rating" | "text" | "images">>) => void;
  deleteReview: (id: string) => void;

  reviewComments: ReviewComment[];
  addComment: (comment: ReviewComment) => void;
  updateComment: (id: string, payload: Partial<Pick<ReviewComment, "text" | "images">>) => void;
  deleteComment: (id: string) => void;
};

const AppStateContext = createContext<AppStateContextValue | null>(null);

const STORAGE_KEYS = {
  auth: "locale:auth",
  profile: "locale:profile",
  savedBusinessIds: "locale:savedBusinessIds",
  helpfulReviewIds: "locale:helpfulReviewIds",
  userReviews: "locale:userReviews",
  reviewComments: "locale:reviewComments",
  users: "locale:users",
} as const;

interface UserAccount {
  email: string;
  name: string;
  password: string; // In real app, this would be hashed
  createdAt: string;
}

function readJson<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function writeJson(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore storage failures (private mode / quota)
  }
}

function getUserStorageKey(baseKey: string): string {
  const auth = readJson<AuthState>(STORAGE_KEYS.auth);
  if (!auth?.isLoggedIn) return baseKey;
  return `${baseKey}:${auth.email}`;
}

function seedSavedBusinessIds(): string[] {
  const seeded = businesses.filter((b) => b.isSaved).map((b) => b.id);
  return Array.from(new Set(seeded));
}

export function AppStateProvider({ children }: { children: React.ReactNode }) {
  const [auth, setAuth] = useState<AuthState>({ isLoggedIn: false });
  const [profile, setProfile] = useState<Profile | null>(null);
  const [savedBusinessIdList, setSavedBusinessIdList] = useState<string[]>([]);
  const [helpfulReviewIdList, setHelpfulReviewIdList] = useState<string[]>([]);
  const [userReviews, setUserReviews] = useState<Review[]>([]);
  const [reviewComments, setReviewComments] = useState<ReviewComment[]>([]);

  useEffect(() => {
    const storedAuth = readJson<AuthState>(STORAGE_KEYS.auth);
    if (storedAuth) setAuth(storedAuth);

    const storedProfile = readJson<Profile>(STORAGE_KEYS.profile);
    if (storedProfile) setProfile(storedProfile);
    else if (storedAuth?.isLoggedIn)
      setProfile({
        name: storedAuth.name,
        email: storedAuth.email,
        joinDate: new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" }),
        bio: "",
        location: "",
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(storedAuth.name)}&size=200&background=random`,
      });

    // Load user-specific saved businesses
    const savedKey = getUserStorageKey(STORAGE_KEYS.savedBusinessIds);
    const storedSaved = readJson<string[]>(savedKey);
    setSavedBusinessIdList(storedSaved && Array.isArray(storedSaved) ? storedSaved : (storedAuth?.isLoggedIn ? [] : seedSavedBusinessIds()));

    // Load user-specific helpful reviews
    const helpfulKey = getUserStorageKey(STORAGE_KEYS.helpfulReviewIds);
    const storedHelpful = readJson<string[]>(helpfulKey);
    setHelpfulReviewIdList(storedHelpful && Array.isArray(storedHelpful) ? storedHelpful : []);

    // Load user-specific reviews
    const reviewsKey = getUserStorageKey(STORAGE_KEYS.userReviews);
    const storedReviews = readJson<Review[]>(reviewsKey);
    setUserReviews(storedReviews && Array.isArray(storedReviews) ? storedReviews : []);

    // Load user-specific comments
    const commentsKey = getUserStorageKey(STORAGE_KEYS.reviewComments);
    const storedComments = readJson<ReviewComment[]>(commentsKey);
    setReviewComments(storedComments && Array.isArray(storedComments) ? storedComments : []);
  }, []);

  // Reload user-specific data when auth state changes
  useEffect(() => {
    if (auth.isLoggedIn) {
      // Load user-specific saved businesses
      const savedKey = getUserStorageKey(STORAGE_KEYS.savedBusinessIds);
      const storedSaved = readJson<string[]>(savedKey);
      setSavedBusinessIdList(storedSaved && Array.isArray(storedSaved) ? storedSaved : []);

      // Load user-specific helpful reviews
      const helpfulKey = getUserStorageKey(STORAGE_KEYS.helpfulReviewIds);
      const storedHelpful = readJson<string[]>(helpfulKey);
      setHelpfulReviewIdList(storedHelpful && Array.isArray(storedHelpful) ? storedHelpful : []);

      // Load user-specific reviews
      const reviewsKey = getUserStorageKey(STORAGE_KEYS.userReviews);
      const storedReviews = readJson<Review[]>(reviewsKey);
      setUserReviews(storedReviews && Array.isArray(storedReviews) ? storedReviews : []);

      // Load user-specific comments
      const commentsKey = getUserStorageKey(STORAGE_KEYS.reviewComments);
      const storedComments = readJson<ReviewComment[]>(commentsKey);
      setReviewComments(storedComments && Array.isArray(storedComments) ? storedComments : []);
    } else {
      // Clear user data when logged out
      setSavedBusinessIdList(seedSavedBusinessIds());
      setHelpfulReviewIdList([]);
      setUserReviews([]);
      setReviewComments([]);
    }
  }, [auth.isLoggedIn, auth.isLoggedIn ? auth.email : undefined]);

  const savedBusinessIds = useMemo(() => new Set(savedBusinessIdList), [savedBusinessIdList]);
  const helpfulReviewIds = useMemo(() => new Set(helpfulReviewIdList), [helpfulReviewIdList]);

  const authenticate = async (email: string, password: string): Promise<boolean> => {
    try {
      const users = readJson<UserAccount[]>(STORAGE_KEYS.users) || [];
      const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (!user) {
        return false;
      }
      
      // In a real app, you'd use proper password hashing and comparison
      if (user.password !== password) {
        return false;
      }
      
      const nextAuth: AuthState = { isLoggedIn: true, name: user.name, email: user.email };
      setAuth(nextAuth);
      writeJson(STORAGE_KEYS.auth, nextAuth);

      const joinDate = new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" });
      const existing = readJson<Profile>(STORAGE_KEYS.profile);
      const nextProfile: Profile = existing
        ? { ...existing, name: user.name, email: user.email }
        : {
            name: user.name,
            email: user.email,
            joinDate,
            bio: "",
            location: "",
            avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&size=200&background=random`,
          };
      setProfile(nextProfile);
      writeJson(STORAGE_KEYS.profile, nextProfile);
      
      return true;
    } catch (error) {
      console.error('Authentication error:', error);
      return false;
    }
  };

  const login = async (payload: { name: string; email: string; password: string }): Promise<boolean> => {
    return authenticate(payload.email, payload.password);
  };

  const signup = async (payload: { name: string; email: string; password: string }): Promise<boolean> => {
    try {
      const users = readJson<UserAccount[]>(STORAGE_KEYS.users) || [];
      
      // Check if user already exists
      if (users.some(u => u.email.toLowerCase() === payload.email.toLowerCase())) {
        return false; // User already exists
      }
      
      // Create new user
      const newUser: UserAccount = {
        name: payload.name.trim(),
        email: payload.email.trim().toLowerCase(),
        password: payload.password, // In real app, this would be hashed
        createdAt: new Date().toISOString(),
      };
      
      // Save user
      const updatedUsers = [...users, newUser];
      writeJson(STORAGE_KEYS.users, updatedUsers);
      
      // Auto-login after signup
      return authenticate(payload.email, payload.password);
    } catch (error) {
      console.error('Signup error:', error);
      return false;
    }
  };

  const logout = () => {
    setAuth({ isLoggedIn: false });
    setProfile(null);
    writeJson(STORAGE_KEYS.auth, { isLoggedIn: false });
    try {
      localStorage.removeItem(STORAGE_KEYS.profile);
    } catch {
      // ignore
    }
  };

  const updateProfile = (partial: Partial<Profile>) => {
    setProfile((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...partial };
      writeJson(STORAGE_KEYS.profile, next);
      return next;
    });
    if (partial.name !== undefined || partial.email !== undefined) {
      setAuth((prev) => {
        if (!prev.isLoggedIn) return prev;
        const next = { ...prev, ...(partial.name !== undefined && { name: partial.name }), ...(partial.email !== undefined && { email: partial.email }) };
        writeJson(STORAGE_KEYS.auth, next);
        return next;
      });
    }
  };

  const isSaved = (businessId: string) => savedBusinessIds.has(businessId);

  const toggleSaved = (businessId: string) => {
    setSavedBusinessIdList((prev) => {
      const next = prev.includes(businessId) ? prev.filter((id) => id !== businessId) : [...prev, businessId];
      const savedKey = getUserStorageKey(STORAGE_KEYS.savedBusinessIds);
      writeJson(savedKey, next);
      return next;
    });
  };

  const isHelpful = (reviewId: string) => helpfulReviewIds.has(reviewId);

  const toggleHelpful = (reviewId: string) => {
    setHelpfulReviewIdList((prev) => {
      const next = prev.includes(reviewId) ? prev.filter((id) => id !== reviewId) : [...prev, reviewId];
      const helpfulKey = getUserStorageKey(STORAGE_KEYS.helpfulReviewIds);
      writeJson(helpfulKey, next);
      return next;
    });
  };

  const addReview = (review: Review) => {
    setUserReviews((prev) => {
      const next = [review, ...prev];
      const reviewsKey = getUserStorageKey(STORAGE_KEYS.userReviews);
      writeJson(reviewsKey, next);
      return next;
    });
  };

  const updateReview = (id: string, payload: Partial<Pick<Review, "rating" | "text" | "images">>) => {
    setUserReviews((prev) => {
      const next = prev.map((r) => (r.id === id ? { ...r, ...payload } : r));
      const reviewsKey = getUserStorageKey(STORAGE_KEYS.userReviews);
      writeJson(reviewsKey, next);
      return next;
    });
  };

  const deleteReview = (id: string) => {
    setUserReviews((prev) => {
      const next = prev.filter((r) => r.id !== id);
      const reviewsKey = getUserStorageKey(STORAGE_KEYS.userReviews);
      writeJson(reviewsKey, next);
      return next;
    });
  };

  const addComment = (comment: ReviewComment) => {
    setReviewComments((prev) => {
      const next = [comment, ...prev];
      const commentsKey = getUserStorageKey(STORAGE_KEYS.reviewComments);
      writeJson(commentsKey, next);
      return next;
    });
  };

  const updateComment = (id: string, payload: Partial<Pick<ReviewComment, "text" | "images">>) => {
    setReviewComments((prev) => {
      const next = prev.map((c) => (c.id === id ? { ...c, ...payload } : c));
      const commentsKey = getUserStorageKey(STORAGE_KEYS.reviewComments);
      writeJson(commentsKey, next);
      return next;
    });
  };

  const deleteComment = (id: string) => {
    setReviewComments((prev) => {
      const toRemove = new Set<string>([id]);
      let changed = true;
      while (changed) {
        changed = false;
        for (const c of prev) {
          if (c.parentId && toRemove.has(c.parentId) && !toRemove.has(c.id)) {
            toRemove.add(c.id);
            changed = true;
          }
        }
      }
      const next = prev.filter((c) => !toRemove.has(c.id));
      const commentsKey = getUserStorageKey(STORAGE_KEYS.reviewComments);
      writeJson(commentsKey, next);
      return next;
    });
  };

  const value: AppStateContextValue = {
    auth,
    profile,
    login,
    signup,
    authenticate,
    logout,
    updateProfile,
    savedBusinessIds,
    isSaved,
    toggleSaved,
    helpfulReviewIds,
    isHelpful,
    toggleHelpful,
    userReviews,
    addReview,
    reviewComments,
    addComment,
    updateComment,
    deleteComment,
    updateReview,
    deleteReview,
  };

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error("useAppState must be used within AppStateProvider");
  return ctx;
}

