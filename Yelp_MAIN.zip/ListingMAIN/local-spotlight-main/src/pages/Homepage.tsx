import { AnimatePresence, motion } from "framer-motion";
import { Search, MapPin, ArrowRight, Zap, Star, Shield } from "lucide-react";
import Navbar from "@/components/Navbar";
import SearchBar from "@/components/SearchBar";
import BusinessCard from "@/components/BusinessCard";
import CategoryCarousel from "@/components/CategoryCarousel";
import Footer from "@/components/Footer";
import { businesses, getDynamicCategories, trendingCities, categoryHeroImages } from "@/data/businesses";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import PageTransition from "@/components/PageTransition";
import { useEffect, useMemo, useState } from "react";

const Homepage = () => {
  const featuredBusinesses = businesses.slice(0, 8);
  const categories = useMemo(() => getDynamicCategories(), []);
  const heroImages = useMemo(
    () => [
      "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop",
      "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=1920&h=1080&fit=crop",
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=1920&h=1080&fit=crop",
    ],
    [],
  );
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => {
      setHeroIndex((prev) => (prev + 1) % heroImages.length);
    }, 3000);
    return () => window.clearInterval(id);
  }, [heroImages.length]);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        {/* Hero */}
        <div className="relative min-h-[600px] flex items-center">
          <div className="absolute inset-0 overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.div
                key={heroImages[heroIndex]}
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.22 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.9, ease: "easeInOut" }}
                className="absolute inset-0"
                style={{
                  backgroundImage: `url('${heroImages[heroIndex]}')`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              />
            </AnimatePresence>
            <div className="absolute inset-0 bg-gradient-to-br from-foreground via-foreground/95 to-primary/30" />
            <motion.div
              className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-primary/20 blur-3xl"
              animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
              transition={{ duration: 8, repeat: Infinity }}
            />
          </div>
          <div className="absolute top-0 left-0 right-0 z-20 overflow-visible">
            <Navbar />
          </div>
          <div className="relative z-10 container mx-auto px-4 pt-32 pb-20 text-center">
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-6xl lg:text-7xl font-display font-black text-primary-foreground mb-4 leading-tight"
            >
              Discover Local
              <br />
              <span className="text-primary">Businesses</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="text-lg md:text-xl text-primary-foreground/70 mb-10 max-w-2xl mx-auto"
            >
              Find and review the best restaurants, cafes, services and more in your neighborhood.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <SearchBar variant="hero" />
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap justify-center gap-3 mt-8"
            >
              {["Restaurants", "Cafes", "Nightlife", "Shopping"].map((cat) => (
                <Link key={cat} to={`/category/${cat.toLowerCase()}`}>
                  <span className="px-4 py-2 rounded-full bg-primary-foreground/10 text-primary-foreground/80 text-sm hover:bg-primary-foreground/20 transition-colors cursor-pointer backdrop-blur-sm">
                    {cat}
                  </span>
                </Link>
              ))}
            </motion.div>
          </div>
        </div>

        {/* Categories Carousel */}
        <section className="container mx-auto px-4 py-20">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-display font-bold text-foreground mb-3"
            >
              Explore Categories
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-muted-foreground"
            >
              Discover businesses by category with our premium carousel
            </motion.p>
          </div>
          
          <CategoryCarousel 
            autoPlay={true}
            interval={4000}
            showControls={true}
            className="max-w-7xl mx-auto"
          >
            {categories.map((category, index) => (
              <div key={category.id} className="px-4">
                <Link
                  to={`/category/${category.id}`}
                  className="group block rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
                  aria-label={`Browse ${category.name}`}
                >
                  <div className="relative">
                    <div className="relative h-72 md:h-80 lg:h-[26rem] w-full overflow-hidden rounded-2xl mb-4">
                      <img 
                        src={categoryHeroImages[category.id as keyof typeof categoryHeroImages] || categoryHeroImages.restaurants}
                        alt={category.name}
                        loading={index === 0 ? "eager" : "lazy"}
                        decoding="async"
                        sizes="(max-width: 768px) 100vw, (max-width: 1280px) 80vw, 1200px"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="bg-foreground/95 backdrop-blur-md rounded-xl px-4 py-3 shadow-xl">
                          <h3 className="text-primary-foreground font-display font-bold text-xl mb-1">{category.name}</h3>
                          <p className="text-primary-foreground/90 text-sm font-medium">{category.count.toLocaleString()} businesses</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </CategoryCarousel>

          {/* Quick Category Links */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="flex flex-wrap justify-center gap-3 mt-12"
          >
            {categories.slice(0, 6).map((cat) => (
              <Link key={cat.id} to={`/category/${cat.id}`}>
                <motion.span
                  whileHover={{ scale: 1.05, y: -2 }}
                  className="px-4 py-2 rounded-full bg-background text-foreground text-sm font-semibold hover:bg-primary/10 transition-colors cursor-pointer border border-primary/40"
                >
                  {cat.name}
                </motion.span>
              </Link>
            ))}
          </motion.div>
        </section>

        {/* Featured */}
        <section className="bg-secondary/50 py-20">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">Featured Businesses</h2>
                <p className="text-muted-foreground">Hand-picked favorites from our community</p>
              </div>
              <Link to="/search">
                <Button variant="outline" className="hidden md:flex">
                  View All <ArrowRight size={16} className="ml-1.5" />
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredBusinesses.map((biz, i) => (
                <BusinessCard key={biz.id} business={biz} index={i} />
              ))}
            </div>
          </div>
        </section>

        {/* Trending Cities */}
        <section className="container mx-auto px-4 py-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-3">Trending Cities</h2>
            <p className="text-muted-foreground">Popular destinations people are exploring</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {trendingCities.map((city, i) => (
              <Link
                key={city.slug}
                to={`/search?location=${encodeURIComponent(city.name)}`}
                className="block focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 rounded-xl"
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                  whileHover={{ y: -4 }}
                  className="group cursor-pointer"
                >
                  <div className="relative rounded-xl overflow-hidden aspect-[4/3]">
                    <img src={city.image} alt={city.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 to-transparent" />
                    <div className="absolute bottom-3 left-3">
                      <p className="text-primary-foreground font-display font-bold text-sm">{city.name}</p>
                      <p className="text-primary-foreground/70 text-xs">{city.count.toLocaleString()} places</p>
                    </div>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section className="bg-secondary/50 py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-14">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-3">How It Works</h2>
              <p className="text-muted-foreground">Three simple steps to find your next favorite spot</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {[
                { icon: <Search size={28} />, title: "Search", desc: "Enter what you're looking for and where" },
                { icon: <Star size={28} />, title: "Compare", desc: "Read reviews and compare businesses" },
                { icon: <Zap size={28} />, title: "Visit", desc: "Pick the perfect spot and enjoy" },
              ].map((step, i) => (
                <motion.div
                  key={step.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mx-auto mb-5">
                    {step.icon}
                  </div>
                  <h3 className="font-display font-bold text-lg text-foreground mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground">{step.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="container mx-auto px-4 py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-accent p-12 md:p-16 text-center"
          >
            <motion.div
              className="absolute -top-20 -right-20 w-60 h-60 rounded-full bg-primary-foreground/10 blur-2xl"
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 6, repeat: Infinity }}
            />
            <div className="relative">
              <Shield size={40} className="mx-auto mb-6 text-primary-foreground/80" />
              <h2 className="text-3xl md:text-4xl font-display font-bold text-primary-foreground mb-4">
                Ready to Discover?
              </h2>
              <p className="text-primary-foreground/80 mb-8 max-w-xl mx-auto">
                Join thousands of people finding the best local businesses every day.
              </p>
              <Link to="/search">
                <Button size="lg" variant="secondary" className="font-semibold text-base px-8">
                  Explore Businesses
                </Button>
              </Link>
            </div>
          </motion.div>
        </section>

        <Footer />
      </div>
    </PageTransition>
  );
};

export default Homepage;
