import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Star, ImagePlus, X } from "lucide-react";
import { useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { businesses } from "@/data/businesses";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import PageTransition from "@/components/PageTransition";
import { useAppState } from "@/context/appState";

const MAX_FILE_SIZE_MB = 10;
const MAX_FILES = 5;

const WriteReview = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { auth, profile, addReview } = useAppState();
  const business = businesses.find((b) => b.id === id);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [text, setText] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!business) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="text-muted-foreground">Business not found.</p>
        </div>
      </div>
    );
  }

  if (!auth.isLoggedIn) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="text-muted-foreground mb-4">Please sign in to write a review.</p>
          <Button onClick={() => navigate(`/auth?mode=signup&redirect=/write-review/${id}`)}>
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.isLoggedIn || !profile) {
      toast.error("Please sign in to write a review");
      navigate(`/auth?mode=signup&redirect=/write-review/${id}`);
      return;
    }
    if (rating === 0) {
      toast.error("Please select a rating");
      return;
    }
    const user = profile;
    addReview({
      id: `user-${Date.now()}`,
      businessId: id!,
      userId: profile.email,
      userName: user.name,
      userAvatar: user.avatar,
      rating,
      text: text.trim() || "No comment.",
      images,
      date: new Date().toISOString().slice(0, 10),
      helpful: 0,
    });
    toast.success("Review submitted! Thank you for your feedback.");
    navigate(`/business/${id}`);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files?.length) return;
    const maxBytes = MAX_FILE_SIZE_MB * 1024 * 1024;
    const remaining = MAX_FILES - images.length;
    const toProcess = Array.from(files).slice(0, remaining);
    toProcess.forEach((file) => {
      if (!file.type.startsWith("image/")) {
        toast.error(`${file.name} is not an image`);
        return;
      }
      if (file.size > maxBytes) {
        toast.error(`${file.name} is over ${MAX_FILE_SIZE_MB}MB`);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setImages((prev) => [...prev, reader.result as string].slice(0, MAX_FILES));
      };
      reader.readAsDataURL(file);
    });
    e.target.value = "";
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const displayRating = hoverRating || rating;

  const ratingLabels = ["", "Not good", "Could be better", "OK", "Good", "Great!"];

  return (
    <PageTransition>
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-10 max-w-2xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-display font-bold text-foreground mb-2">Write a Review</h1>
          <p className="text-muted-foreground mb-8">
            for <span className="text-primary font-semibold">{business.name}</span>
          </p>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Rating */}
            <div className="bg-card rounded-xl p-6 shadow-card text-center">
              <p className="text-sm text-muted-foreground mb-4">Select your rating</p>
              <div className="flex justify-center gap-2 mb-3">
                {[1, 2, 3, 4, 5].map((star) => (
                  <motion.button
                    key={star}
                    type="button"
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    onClick={() => setRating(star)}
                    className="p-1"
                  >
                    <Star
                      size={36}
                      className={`transition-colors ${star <= displayRating ? "fill-primary text-primary" : "text-muted-foreground/30"}`}
                    />
                  </motion.button>
                ))}
              </div>
              {displayRating > 0 && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-sm font-medium text-foreground"
                >
                  {ratingLabels[displayRating]}
                </motion.p>
              )}
            </div>

            {/* Review text */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Your Review</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Share your experience. What was great? What could be improved?"
                className="min-h-[160px] resize-none"
              />
            </div>

            {/* Image upload */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Add Photos</label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp,image/gif"
                multiple
                className="sr-only"
                aria-label="Upload photos"
                onChange={handleImageChange}
              />
              <div
                role="button"
                tabIndex={0}
                onClick={() => fileInputRef.current?.click()}
                onKeyDown={(e) => e.key === "Enter" && fileInputRef.current?.click()}
                className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20"
              >
                <ImagePlus size={32} className="mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Click to upload photos</p>
                <p className="text-xs text-muted-foreground/60 mt-1">JPG, PNG, WebP, GIF up to {MAX_FILE_SIZE_MB}MB · max {MAX_FILES} photos</p>
              </div>
              {images.length > 0 && (
                <div className="flex flex-wrap gap-3 mt-3">
                  {images.map((src, i) => (
                    <div key={i} className="relative group">
                      <img src={src} alt={`Upload ${i + 1}`} className="w-24 h-24 rounded-lg object-cover border border-border" />
                      <button
                        type="button"
                        onClick={() => removeImage(i)}
                        className="absolute -top-1.5 -right-1.5 p-1 rounded-full bg-destructive text-destructive-foreground shadow hover:bg-destructive/90"
                        aria-label="Remove photo"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Button type="submit" size="lg" className="w-full font-semibold text-base">
              Submit Review
            </Button>
          </form>
        </motion.div>
      </div>
      <Footer />
    </div>
    </PageTransition>
  );
};

export default WriteReview;
