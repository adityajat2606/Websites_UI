import { motion } from "framer-motion";
import { Bookmark, SlidersHorizontal, X } from "lucide-react";
import { useState, useCallback, useMemo, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import BusinessCard from "@/components/BusinessCard";
import FilterSidebar from "@/components/FilterSidebar";
import Footer from "@/components/Footer";
import { businesses } from "@/data/businesses";
import PageTransition from "@/components/PageTransition";
import { useAppState } from "@/context/appState";
import { applyFilters } from "@/utils/filterBusinesses";
import type { BusinessFilters } from "@/types/filters";
import { DEFAULT_FILTERS } from "@/types/filters";
import { Button } from "@/components/ui/button";

const SavedBusinesses = () => {
  const { auth, savedBusinessIds } = useAppState();
  const navigate = useNavigate();
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<BusinessFilters>(DEFAULT_FILTERS);

  // Redirect to auth page if not logged in
  useEffect(() => {
    if (!auth.isLoggedIn) {
      navigate("/auth?mode=login");
    }
  }, [auth.isLoggedIn, navigate]);

  const onFilterChange = useCallback((f: BusinessFilters) => setFilters(f), []);

  const savedBusinesses = useMemo(
    () => businesses.filter((b) => savedBusinessIds.has(b.id)).map((b) => ({ ...b, isSaved: true })),
    [savedBusinessIds]
  );

  const filteredBusinesses = useMemo(
    () => applyFilters(savedBusinesses, filters),
    [savedBusinesses, filters]
  );

  return (
    <PageTransition>
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-10">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Bookmark size={20} className="text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-display font-bold text-foreground">Saved Businesses</h1>
                <p className="text-sm text-muted-foreground">{filteredBusinesses.length} saved</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="md:hidden"
              onClick={() => setShowFilters(!showFilters)}
            >
              <SlidersHorizontal size={16} className="mr-1.5" />
              Filters
            </Button>
          </div>
        </motion.div>

        <div className="flex gap-6">
          <div className="hidden md:block w-72 shrink-0">
            <div className="sticky top-20">
              <FilterSidebar onFilterChange={onFilterChange} />
            </div>
          </div>

          {showFilters && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="fixed inset-0 z-50 bg-foreground/50 md:hidden"
              onClick={() => setShowFilters(false)}
            >
              <motion.div
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                className="w-80 h-full bg-background overflow-y-auto p-4"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-display font-bold text-foreground">Filters</h3>
                  <button onClick={() => setShowFilters(false)}>
                    <X size={20} />
                  </button>
                </div>
                <FilterSidebar onFilterChange={onFilterChange} />
              </motion.div>
            </motion.div>
          )}

          <div className="flex-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBusinesses.map((biz, i) => (
                <BusinessCard key={biz.id} business={biz} index={i} />
              ))}
            </div>

            {filteredBusinesses.length === 0 && (
              <div className="text-center py-20">
                <p className="text-muted-foreground text-lg">
                  {savedBusinesses.length === 0 ? "No saved businesses yet." : "No saved businesses match your filters."}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
    </PageTransition>
  );
};

export default SavedBusinesses;
