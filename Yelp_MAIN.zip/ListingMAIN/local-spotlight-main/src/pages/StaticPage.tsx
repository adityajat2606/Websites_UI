import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PageTransition from "@/components/PageTransition";

type StaticContent = {
  title: string;
  body: string[];
};

const CONTENT: Record<string, StaticContent> = {
  "about-us": {
    title: "About Locale",
    body: [
      "Locale is your trusted companion for discovering the best local businesses in your community. We believe that great local businesses deserve to be recognized, and consumers deserve authentic, reliable information to make informed decisions.",
      "Our platform connects millions of users with thousands of local businesses, from cozy cafes to innovative tech startups, from family-owned restaurants to professional service providers. Every review on our platform comes from real customers who have experienced these businesses firsthand.",
      "Founded in 2024, Locale started with a simple mission: to help people find and support local businesses that make their communities special. Today, we're proud to be the most trusted platform for local business discovery, powered by genuine customer experiences and community-driven reviews.",
      "Whether you're looking for a new favorite restaurant, a reliable plumber, or the perfect gift shop, Locale is here to help you discover the hidden gems and established favorites that make your community unique.",
    ],
  },
  careers: {
    title: "Careers at Locale",
    body: [
      "Join us in our mission to connect communities with great local businesses. At Locale, we're building a team of passionate individuals who believe in the power of local commerce and authentic customer experiences.",
      "We're always looking for talented people in various roles including engineering, product management, marketing, customer success, and business development. Our team works remotely across the globe, united by our shared values of innovation, integrity, and community.",
      "Current opportunities include Senior Frontend Developer, Backend Engineer, Product Designer, Community Manager, and Business Development roles. We offer competitive compensation, flexible work arrangements, and the chance to make a real impact on local businesses everywhere.",
      "If you're passionate about helping local businesses thrive and want to join a dynamic, growing team, we'd love to hear from you. Send your resume to careers@locale.com and let us know how you can contribute to our mission.",
    ],
  },
  press: {
    title: "Press & Media",
    body: [
      "Welcome to the Locale press room. Here you'll find our latest press releases, company information, and media resources. We're always excited to share our story and impact on local communities.",
      "Recent highlights: Locale has helped over 1 million users discover local businesses, with more than 500,000 authentic reviews published on our platform. We've been featured in TechCrunch, Business Insider, and Local Business Journal for our innovative approach to local business discovery.",
      "For media inquiries, interview requests, or additional information about Locale, please contact our press team at press@locale.com. Our media kit includes high-resolution logos, executive headshots, company statistics, and brand guidelines.",
      "Download our media kit at locale.com/press-kit or contact us directly for personalized assistance. We typically respond to media inquiries within 24 hours.",
    ],
  },
  blog: {
    title: "Locale Blog",
    body: [
      "Welcome to the Locale blog, your source for local business insights, community spotlights, and platform updates. Here we share stories that celebrate local entrepreneurship and help consumers make informed decisions.",
      "Recent posts include '5 Ways to Support Local Businesses This Weekend,' 'The Rise of Sustainable Local Shopping,' 'Behind the Scenes: Meet Our Top-Rated Restaurant Owners,' and 'How to Write Reviews That Actually Help Other Customers.'",
      "Our blog features contributions from local business owners, industry experts, and the Locale team. We cover topics ranging from business tips and marketing strategies to community spotlights and platform tutorials.",
      "Subscribe to our newsletter to get the latest posts delivered to your inbox, and follow us on social media @locale for daily tips and local business highlights. Have a story to share? Contact us at blog@locale.com.",
    ],
  },
  terms: {
    title: "Terms of Service",
    body: [
      "These Terms of Service govern your use of Locale's platform and services. By using Locale, you agree to these terms, which are designed to ensure a fair, transparent, and safe environment for all users and businesses.",
      "Service Description: Locale provides a platform for users to discover, review, and engage with local businesses. We facilitate connections between consumers and businesses but do not directly provide the goods or services offered by listed businesses.",
      "User Responsibilities: Users must provide accurate information, respect intellectual property rights, and refrain from posting false, misleading, or harmful content. Reviews must be based on genuine experiences and follow our community guidelines.",
      "Business Listings: Business owners are responsible for maintaining accurate information about their services. Locale reserves the right to remove listings or content that violate our terms or applicable laws.",
      "Privacy and Data: We collect and use data as described in our Privacy Policy. Users maintain ownership of their content while granting Locale the right to use it for platform improvement and promotional purposes.",
      "Limitation of Liability: Locale is provided 'as is' without warranties. We are not liable for business transactions, service quality, or disputes between users and businesses.",
      "These terms may be updated periodically. Continued use of the platform constitutes acceptance of any changes. For questions about these terms, contact legal@locale.com.",
    ],
  },
  privacy: {
    title: "Privacy Policy",
    body: [
      "At Locale, we take your privacy seriously. This Privacy Policy explains how we collect, use, and protect your information when you use our platform to discover and review local businesses.",
      "Information We Collect: We collect information you provide directly (name, email, profile details), information about your usage (searches, reviews, saved businesses), and technical information (IP address, device type, browser information). We also collect location data to provide relevant local business recommendations.",
      "How We Use Your Information: We use your information to provide and improve our services, personalize your experience, facilitate communication with businesses, ensure platform security, and send relevant updates and marketing communications (which you can opt out of).",
      "Information Sharing: We don't sell your personal information. We may share anonymized, aggregated data for analytics and share your information with businesses when you interact with them or leave reviews. We may also disclose information when required by law or to protect our rights.",
      "Data Security: We implement industry-standard security measures including encryption, secure servers, and regular security audits. However, no method of transmission over the internet is 100% secure.",
      "Your Rights: You can access, update, or delete your account information at any time. You can also download your data or request data portability. For data-related requests, contact privacy@locale.com.",
      "Cookies and Tracking: We use cookies and similar technologies to enhance your experience, analyze usage, and provide personalized recommendations. You can control cookie settings through your browser.",
      "This policy may be updated periodically. We'll notify users of significant changes. For privacy questions or concerns, contact our Data Protection Officer at privacy@locale.com.",
    ],
  },
};

const StaticPage = () => {
  const { slug } = useParams();

  const content = useMemo<StaticContent>(() => {
    if (!slug) return { title: "Page", body: ["Missing page."] };
    return CONTENT[slug] ?? { title: "Page", body: ["This page doesn't exist yet."] };
  }, [slug]);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <main className="flex-1 container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto bg-card rounded-2xl p-8 shadow-card">
            <h1 className="text-3xl md:text-4xl font-display font-black text-foreground mb-4">
              {content.title}
            </h1>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              {content.body.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <div className="mt-8">
              <Link to="/" className="text-primary hover:underline font-semibold">
                Back to Home
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
};

export default StaticPage;

