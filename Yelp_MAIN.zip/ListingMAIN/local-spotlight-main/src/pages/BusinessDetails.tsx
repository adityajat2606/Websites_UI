import { useParams, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { MapPin, Phone, Globe, Clock, Bookmark, BookmarkCheck, Share2, PenLine, ExternalLink } from "lucide-react";
import Navbar from "@/components/Navbar";
import PhotoGallery from "@/components/PhotoGallery";
import RatingStars from "@/components/RatingStars";
import ReviewCard from "@/components/ReviewCard";
import LeafletMap from "@/components/LeafletMap";
import Footer from "@/components/Footer";
import { businesses } from "@/data/businesses";
import { reviews } from "@/data/reviews";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import PageTransition from "@/components/PageTransition";
import { useAppState } from "@/context/appState";
import { toast } from "sonner";

const BusinessDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { auth, isSaved, toggleSaved, userReviews } = useAppState();
  const business = businesses.find((b) => b.id === id);
  const staticReviews = reviews.filter((r) => r.businessId === id);
  const userReviewsForBusiness = id ? userReviews.filter((r) => r.businessId === id) : [];
  const businessReviews = [...userReviewsForBusiness, ...staticReviews];
  const saved = business ? isSaved(business.id) : false;

  if (!business) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="text-muted-foreground text-lg">Business not found.</p>
        </div>
      </div>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <PhotoGallery images={business.images} businessName={business.name} />

        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main Content */}
            <div className="flex-1">
              <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
                {/* Header */}
                <div className="mb-6">
                  <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">
                    {business.name}
                  </h1>
                  <div className="flex flex-wrap items-center gap-3 mb-3">
                    <RatingStars rating={business.rating} size={18} showValue />
                    <span className="text-sm text-muted-foreground">({business.reviewCount} reviews)</span>
                    <span className="text-sm font-medium text-foreground">{business.priceRange}</span>
                    {business.categories.map((cat) => (
                      <Badge key={cat} variant="secondary" className="text-xs">{cat}</Badge>
                    ))}
                  </div>
                  {business.isOpen ? (
                    <Badge className="bg-green-500/10 text-green-600 border-green-500/20">Open Now</Badge>
                  ) : (
                    <Badge variant="secondary">Closed</Badge>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-3 mb-8">
                  {auth.isLoggedIn ? (
                    <Link to={`/write-review/${business.id}`}>
                      <Button className="font-semibold">
                        <PenLine size={16} className="mr-1.5" />
                        Write a Review
                      </Button>
                    </Link>
                  ) : (
                    <Button
                      className="font-semibold"
                      onClick={() => {
                        toast.info("Sign in to write a review");
                        navigate(`/auth?mode=signup&redirect=/write-review/${business.id}`);
                      }}
                    >
                      <PenLine size={16} className="mr-1.5" />
                      Write a Review
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => toggleSaved(business.id)}
                    className="gap-1.5"
                  >
                    {saved ? <BookmarkCheck size={16} className="text-primary" /> : <Bookmark size={16} />}
                    {saved ? "Saved" : "Save"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.href);
                      toast.success("Link copied to clipboard");
                    }}
                  >
                    <Share2 size={16} className="mr-1.5" />
                    Share
                  </Button>
                </div>

                {/* Description */}
                <div className="mb-8">
                  <h2 className="font-display font-bold text-xl text-foreground mb-3">About</h2>
                  <p className="text-muted-foreground leading-relaxed">{business.description}</p>
                </div>

                {/* Reviews */}
                <div>
                  <h2 className="font-display font-bold text-xl text-foreground mb-5">
                    Reviews ({businessReviews.length})
                  </h2>
                  <div className="space-y-4">
                    {businessReviews.map((review, i) => (
                      <ReviewCard key={review.id} review={review} index={i} />
                    ))}
                    {businessReviews.length === 0 && (
                      <p className="text-muted-foreground">No reviews yet. Be the first!</p>
                    )}
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Sidebar */}
            <div className="lg:w-80 shrink-0">
              <div className="sticky top-20 space-y-4">
                <motion.div
                  initial={{ opacity: 0, x: 15 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="bg-card rounded-xl p-5 shadow-card space-y-4"
                >
                  <div className="flex items-start gap-3">
                    <MapPin size={18} className="text-primary mt-0.5 shrink-0" />
                    <span className="text-sm text-card-foreground">{business.address}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone size={18} className="text-primary shrink-0" />
                    <span className="text-sm text-card-foreground">{business.phone}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Globe size={18} className="text-primary shrink-0" />
                    <a href={business.website} className="text-sm text-primary hover:underline flex items-center gap-1">
                      Visit Website <ExternalLink size={12} />
                    </a>
                  </div>
                </motion.div>

                {/* Hours */}
                <motion.div
                  initial={{ opacity: 0, x: 15 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  className="bg-card rounded-xl p-5 shadow-card"
                >
                  <h3 className="font-display font-bold text-card-foreground mb-3 flex items-center gap-2">
                    <Clock size={16} className="text-primary" />
                    Hours
                  </h3>
                  <div className="space-y-2">
                    {business.hours.map((h) => (
                      <div key={h.day} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{h.day}</span>
                        <span className="text-card-foreground font-medium">{h.time}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>

                {/* Interactive Map */}
                <motion.div
                  initial={{ opacity: 0, x: 15 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  className="rounded-xl overflow-hidden h-48"
                >
                  <LeafletMap
                    businesses={[business]}
                    center={[business.lat, business.lng]}
                    zoom={15}
                    singleBusiness
                  />
                </motion.div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </PageTransition>
  );
};

export default BusinessDetails;
