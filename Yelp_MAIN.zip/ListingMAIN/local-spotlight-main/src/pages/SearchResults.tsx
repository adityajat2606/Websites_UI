import { useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { SlidersHorizontal, X } from "lucide-react";
import { useState, useCallback, useMemo } from "react";
import Navbar from "@/components/Navbar";
import SearchBar from "@/components/SearchBar";
import BusinessCard from "@/components/BusinessCard";
import FilterSidebar from "@/components/FilterSidebar";
import LeafletMap from "@/components/LeafletMap";
import Footer from "@/components/Footer";
import { businesses, businessInCity } from "@/data/businesses";
import { Button } from "@/components/ui/button";
import PageTransition from "@/components/PageTransition";
import { applyFilters } from "@/utils/filterBusinesses";
import type { BusinessFilters } from "@/types/filters";
import { DEFAULT_FILTERS } from "@/types/filters";

const SearchResults = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get("q") || "";
  const locationParam = searchParams.get("location") || "";
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<BusinessFilters>(DEFAULT_FILTERS);

  const onFilterChange = useCallback((f: BusinessFilters) => setFilters(f), []);

  const searchFiltered = useMemo(() => {
    let list = businesses;
    if (locationParam) {
      list = list.filter((b) => businessInCity(b, locationParam));
    }
    if (query) {
      list = list.filter(
        (b) =>
          b.name.toLowerCase().includes(query.toLowerCase()) ||
          b.category.toLowerCase().includes(query.toLowerCase()) ||
          b.categories.some((c) => c.toLowerCase().includes(query.toLowerCase())) ||
          b.location.toLowerCase().includes(query.toLowerCase()) ||
          b.address.toLowerCase().includes(query.toLowerCase())
      );
    }
    return list;
  }, [query, locationParam]);

  const filteredBusinesses = useMemo(
    () => applyFilters(searchFiltered, filters),
    [searchFiltered, filters]
  );

  const pageTitle = locationParam
    ? `Businesses in ${locationParam}`
    : query
      ? `Results for "${query}"`
      : "All Businesses";

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-6">
          {/* Top bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-display font-bold text-foreground">
                {pageTitle}
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                {filteredBusinesses.length} businesses found
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden md:block w-80">
                <SearchBar variant="navbar" defaultQuery={query} defaultLocation={locationParam} />
              </div>
              <Button
                variant="outline"
                size="sm"
                className="md:hidden"
                onClick={() => setShowFilters(!showFilters)}
              >
                <SlidersHorizontal size={16} className="mr-1.5" />
                Filters
              </Button>
            </div>
          </div>

          <div className="flex gap-6">
            {/* Sidebar */}
            <div className="hidden md:block w-72 shrink-0">
              <div className="sticky top-20">
                <FilterSidebar onFilterChange={onFilterChange} />
              </div>
            </div>

            {/* Mobile filters */}
            {showFilters && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="fixed inset-0 z-50 bg-foreground/50 md:hidden"
                onClick={() => setShowFilters(false)}
              >
                <motion.div
                  initial={{ x: "-100%" }}
                  animate={{ x: 0 }}
                  className="w-80 h-full bg-background overflow-y-auto p-4"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-display font-bold text-foreground">Filters</h3>
                    <button onClick={() => setShowFilters(false)}>
                      <X size={20} />
                    </button>
                  </div>
                  <FilterSidebar onFilterChange={onFilterChange} />
                </motion.div>
              </motion.div>
            )}

            {/* Results + Map */}
            <div className="flex-1 flex gap-6">
              {/* Results */}
              <div className="flex-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {filteredBusinesses.map((biz, i) => (
                    <BusinessCard key={biz.id} business={biz} index={i} />
                  ))}
                </div>
                {filteredBusinesses.length === 0 && (
                  <div className="text-center py-20">
                    <p className="text-muted-foreground text-lg">
                      {locationParam
                        ? `No businesses found in ${locationParam}. Try another city or search.`
                        : "No businesses found. Try a different search or location."}
                    </p>
                  </div>
                )}
              </div>

              {/* Interactive Map */}
              <div className="hidden lg:block w-80 shrink-0">
                <div className="sticky top-20 rounded-xl overflow-hidden h-[calc(100vh-120px)]">
                  <LeafletMap businesses={filteredBusinesses} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </PageTransition>
  );
};

export default SearchResults;
