import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { MapPin, Calendar, Camera, MessageSquare, Bookmark, Pencil, Check } from "lucide-react";
import Navbar from "@/components/Navbar";
import ReviewCard from "@/components/ReviewCard";
import BusinessCard from "@/components/BusinessCard";
import Footer from "@/components/Footer";
import { businesses } from "@/data/businesses";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import PageTransition from "@/components/PageTransition";
import { useAppState } from "@/context/appState";

const UserProfile = () => {
  const navigate = useNavigate();
  const { auth, profile, updateProfile, userReviews, savedBusinessIds } = useAppState();
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editBio, setEditBio] = useState("");
  const [editLocation, setEditLocation] = useState("");
  const [editAvatar, setEditAvatar] = useState("");
  const avatarInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!auth.isLoggedIn) {
      navigate("/auth?mode=login", { replace: true });
      return;
    }
    if (profile) {
      setEditName(profile.name);
      setEditEmail(profile.email);
      setEditBio(profile.bio);
      setEditLocation(profile.location);
      setEditAvatar(profile.avatar);
    }
  }, [auth.isLoggedIn, navigate, profile]);

  if (!auth.isLoggedIn) return null;

  const savedList = profile
    ? businesses.filter((b) => savedBusinessIds.has(b.id)).map((b) => ({ ...b, isSaved: true }))
    : [];
  const reviewCount = userReviews.length;
  const photoCount = userReviews.reduce((acc, r) => acc + (r.images?.length ?? 0), 0);
  const savedCount = savedList.length;

  const handleSaveEdit = () => {
    updateProfile({
      name: editName.trim() || profile!.name,
      email: editEmail.trim() || profile!.email,
      bio: editBio,
      location: editLocation,
      avatar: editAvatar.trim() || profile!.avatar,
    });
    setEditing(false);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      updateProfile({ avatar: dataUrl });
      setEditAvatar(dataUrl);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  if (!profile) return null;

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-10">
          {/* Profile header - editable */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card rounded-2xl p-8 shadow-card mb-8"
          >
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <div className="relative group">
                <img
                  src={editing ? editAvatar || profile.avatar : profile.avatar}
                  alt={profile.name}
                  className="w-24 h-24 rounded-full object-cover ring-4 ring-primary/20"
                />
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  aria-label="Upload profile photo"
                  onChange={handleAvatarUpload}
                />
                <button
                  type="button"
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute bottom-0 right-0 p-2 rounded-full bg-primary text-primary-foreground shadow-md hover:bg-primary/90 transition-colors opacity-90 group-hover:opacity-100"
                  title="Upload profile photo"
                >
                  <Camera size={14} />
                </button>
                {editing && (
                  <div className="mt-2">
                    <label className="text-xs text-muted-foreground block mb-1">Avatar URL</label>
                    <Input
                      value={editAvatar}
                      onChange={(e) => setEditAvatar(e.target.value)}
                      placeholder="Image URL"
                      className="text-sm h-8"
                    />
                  </div>
                )}
              </div>
              <div className="text-center md:text-left flex-1">
                {editing ? (
                  <div className="space-y-3 max-w-md">
                    <div>
                      <label className="text-xs text-muted-foreground">Name</label>
                      <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="mt-0.5" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Email</label>
                      <Input type="email" value={editEmail} onChange={(e) => setEditEmail(e.target.value)} className="mt-0.5" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Location</label>
                      <Input value={editLocation} onChange={(e) => setEditLocation(e.target.value)} placeholder="e.g. San Francisco, CA" className="mt-0.5" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Bio</label>
                      <Textarea value={editBio} onChange={(e) => setEditBio(e.target.value)} placeholder="A short bio..." className="mt-0.5 min-h-[80px]" />
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSaveEdit} className="gap-1">
                        <Check size={14} /> Save
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditing(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-center md:justify-start gap-2">
                      <h1 className="text-2xl font-display font-bold text-card-foreground">{profile.name}</h1>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setEditing(true)} title="Edit profile">
                        <Pencil size={14} />
                      </Button>
                    </div>
                    <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-sm text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <MapPin size={14} /> {profile.location || "Add location"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar size={14} /> Joined {profile.joinDate}
                      </span>
                    </div>
                    <p className="text-muted-foreground text-sm max-w-lg">{profile.bio || "Add a short bio in edit mode."}</p>
                  </>
                )}
              </div>
              {!editing && (
                <div className="flex gap-6 text-center">
                  <div>
                    <p className="text-2xl font-display font-bold text-foreground">{reviewCount}</p>
                    <p className="text-xs text-muted-foreground">Reviews</p>
                  </div>
                  <div>
                    <p className="text-2xl font-display font-bold text-foreground">{photoCount}</p>
                    <p className="text-xs text-muted-foreground">Photos</p>
                  </div>
                  <div>
                    <p className="text-2xl font-display font-bold text-foreground">{savedCount}</p>
                    <p className="text-xs text-muted-foreground">Saved</p>
                  </div>
                </div>
              )}
            </div>
          </motion.div>

          {/* Tabs - data from appState, updates in realtime */}
          <Tabs defaultValue="reviews">
            <TabsList className="mb-6">
              <TabsTrigger value="reviews" className="gap-1.5">
                <MessageSquare size={14} /> Reviews ({reviewCount})
              </TabsTrigger>
              <TabsTrigger value="photos" className="gap-1.5">
                <Camera size={14} /> Photos ({photoCount})
              </TabsTrigger>
              <TabsTrigger value="saved" className="gap-1.5">
                <Bookmark size={14} /> Saved ({savedCount})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="reviews">
              <div className="space-y-4">
                {userReviews.map((review, i) => (
                  <ReviewCard key={review.id} review={review} index={i} />
                ))}
                {userReviews.length === 0 && <p className="text-muted-foreground text-center py-10">No reviews yet. Write one from a business page!</p>}
              </div>
            </TabsContent>

            <TabsContent value="photos">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {userReviews.flatMap((r) => r.images ?? []).map((img, i) => (
                  <img key={i} src={img} alt="User photo" className="w-full aspect-square rounded-xl object-cover" />
                ))}
              </div>
              {photoCount === 0 && <p className="text-muted-foreground col-span-full text-center py-10">No photos uploaded yet.</p>}
            </TabsContent>

            <TabsContent value="saved">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {savedList.map((biz, i) => (
                  <BusinessCard key={biz.id} business={biz} index={i} />
                ))}
              </div>
              {savedCount === 0 && <p className="text-muted-foreground text-center py-10">No saved businesses yet.</p>}
            </TabsContent>
          </Tabs>
        </div>
        <Footer />
      </div>
    </PageTransition>
  );
};

export default UserProfile;
