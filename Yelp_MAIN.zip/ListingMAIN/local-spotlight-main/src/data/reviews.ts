export interface Review {
  id: string;
  businessId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  rating: number;
  text: string;
  images: string[];
  date: string;
  helpful: number;
}

/** Comment or reply on a review. parentId null = top-level comment; otherwise reply to that comment. */
export interface ReviewComment {
  id: string;
  reviewId: string;
  parentId: string | null;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  text: string;
  date: string;
  /** Optional images attached to the comment; tap to open full size. */
  images?: string[];
}

export const reviews: Review[] = [
  {
    id: "r1",
    businessId: "1",
    userId: "u1",
    userName: "Sarah M.",
    userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Absolutely stunning experience! The truffle pasta was out of this world. The ambiance is perfect for a date night. Chef Marco came out to greet us personally. Will definitely be coming back!",
    images: ["https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=300&fit=crop"],
    date: "2026-02-15",
    helpful: 24,
  },
  {
    id: "r2",
    businessId: "1",
    userId: "u2",
    userName: "James K.",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    rating: 4,
    text: "Great food and wine selection. The service was a bit slow during peak hours but the quality more than makes up for it. The tiramisu is a must-try.",
    images: [],
    date: "2026-02-10",
    helpful: 12,
  },
  {
    id: "r3",
    businessId: "1",
    userId: "u3",
    userName: "Emily R.",
    userAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Best Italian food I've had outside of Italy. The handmade pasta is incredible and the wine pairing suggestions from the sommelier were spot on.",
    images: ["https://images.unsplash.com/photo-1551218808-94e220e084d2?w=400&h=300&fit=crop"],
    date: "2026-01-28",
    helpful: 18,
  },
  {
    id: "r4",
    businessId: "2",
    userId: "u1",
    userName: "Sarah M.",
    userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "My go-to coffee spot! The pour-over is consistently amazing. Love the cozy atmosphere and friendly baristas.",
    images: [],
    date: "2026-02-20",
    helpful: 8,
  },
  {
    id: "r5",
    businessId: "7",
    userId: "u2",
    userName: "James K.",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "The omakase here is a transcendent experience. Every piece of sushi is perfection. Chef Tanaka is a true master. Worth every penny.",
    images: ["https://images.unsplash.com/photo-1553621042-f6e147245754?w=400&h=300&fit=crop"],
    date: "2026-02-18",
    helpful: 32,
  },
  {
    id: "r6",
    businessId: "5",
    userId: "u3",
    userName: "Emily R.",
    userAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Glow completely transformed my hair. The stylist really listened to what I wanted and the results exceeded my expectations. The spa is gorgeous too.",
    images: [],
    date: "2026-01-15",
    helpful: 15,
  },
  // New reviews
  {
    id: "r7",
    businessId: "9",
    userId: "u4",
    userName: "David L.",
    userAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Best pho in the city, hands down. The broth is rich and complex — you can taste those 24 hours of simmering. The spring rolls are incredible too. Come early, there's always a line!",
    images: ["https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=400&h=300&fit=crop"],
    date: "2026-02-22",
    helpful: 41,
  },
  {
    id: "r8",
    businessId: "10",
    userId: "u1",
    userName: "Sarah M.",
    userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face",
    rating: 4,
    text: "Beautiful space, fantastic latte art, and the almond croissant is dangerously good. Only wish it was a bit less crowded on weekends. The wifi is blazing fast though.",
    images: ["https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=400&h=300&fit=crop"],
    date: "2026-02-19",
    helpful: 9,
  },
  {
    id: "r9",
    businessId: "11",
    userId: "u3",
    userName: "Emily R.",
    userAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "The views are absolutely breathtaking. Watched the sunset with a perfectly crafted Old Fashioned. The small plates are creative and delicious. A must-visit for anyone in SF!",
    images: ["https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=400&h=300&fit=crop"],
    date: "2026-02-25",
    helpful: 27,
  },
  {
    id: "r10",
    businessId: "15",
    userId: "u4",
    userName: "David L.",
    userAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "The al pastor tacos are life-changing. Perfectly seasoned meat, fresh tortillas, and that salsa verde will haunt your dreams. Huge portions for the price. This is the real deal.",
    images: ["https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=300&fit=crop"],
    date: "2026-02-27",
    helpful: 53,
  },
  {
    id: "r11",
    businessId: "13",
    userId: "u2",
    userName: "James K.",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Pure bliss. The hot stone massage melted away months of tension. The atmosphere is serene and the staff is incredibly attentive. Splurge-worthy experience.",
    images: [],
    date: "2026-03-01",
    helpful: 19,
  },
  {
    id: "r12",
    businessId: "15",
    userId: "u1",
    userName: "Sarah M.",
    userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face",
    rating: 4,
    text: "Excellent tacos! The carnitas are melt-in-your-mouth tender. Only giving 4 stars because we had to wait 20 minutes for a table, but totally worth the wait.",
    images: [],
    date: "2026-02-28",
    helpful: 14,
  },
  {
    id: "r13",
    businessId: "3",
    userId: "u4",
    userName: "David L.",
    userAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
    rating: 4,
    text: "Cool vibe, great cocktails, live jazz on Thursdays is a real treat. Prices are a bit steep but the atmosphere makes up for it. The negroni is stellar.",
    images: ["https://images.unsplash.com/photo-1572116469696-31de0f17cc34?w=400&h=300&fit=crop"],
    date: "2026-02-12",
    helpful: 11,
  },
  {
    id: "r14",
    businessId: "4",
    userId: "u3",
    userName: "Emily R.",
    userAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Found the most gorgeous vintage denim jacket here! The curation is impeccable — every piece feels hand-selected. The staff really knows their fashion history.",
    images: [],
    date: "2026-01-20",
    helpful: 7,
  },
  {
    id: "r15",
    businessId: "16",
    userId: "u2",
    userName: "James K.",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "A book lover's paradise. The staff recommendations are always spot-on, and the author events bring in incredible talent. The in-store coffee is a nice bonus.",
    images: ["https://images.unsplash.com/photo-1526243741027-444d633d7365?w=400&h=300&fit=crop"],
    date: "2026-03-02",
    helpful: 16,
  },
  {
    id: "r16",
    businessId: "8",
    userId: "u4",
    userName: "David L.",
    userAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
    rating: 4,
    text: "The weekend brunch is phenomenal. Fluffy pancakes, perfectly poached eggs, and the best Bloody Mary in town. Gets packed so make a reservation.",
    images: ["https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop"],
    date: "2026-02-08",
    helpful: 22,
  },
];

export const users = [
  {
    id: "u1",
    name: "Sarah Mitchell",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face",
    bio: "Foodie & coffee enthusiast. Always looking for the next great restaurant in SF.",
    reviewCount: 47,
    photoCount: 23,
    savedCount: 12,
    joinDate: "January 2024",
    location: "San Francisco, CA",
  },
];
