export interface Business {
  id: string;
  name: string;
  image: string;
  rating: number;
  reviewCount: number;
  priceRange: string;
  category: string;
  categories: string[];
  location: string;
  address: string;
  phone: string;
  website: string;
  description: string;
  hours: { day: string; time: string }[];
  images: string[];
  isSaved?: boolean;
  isOpen: boolean;
  distance: string;
  lat: number;
  lng: number;
}

const defaultHours = [
  { day: "Monday", time: "9:00 AM - 9:00 PM" },
  { day: "Tuesday", time: "9:00 AM - 9:00 PM" },
  { day: "Wednesday", time: "9:00 AM - 9:00 PM" },
  { day: "Thursday", time: "9:00 AM - 10:00 PM" },
  { day: "Friday", time: "9:00 AM - 10:00 PM" },
  { day: "Saturday", time: "10:00 AM - 10:00 PM" },
  { day: "Sunday", time: "10:00 AM - 8:00 PM" },
];

export const businesses: Business[] = [
  {
    id: "1",
    name: "The Golden Fork",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=400&fit=crop",
    rating: 4.7,
    reviewCount: 342,
    priceRange: "$$$",
    category: "Restaurants",
    categories: ["Italian", "Fine Dining", "Wine Bar"],
    location: "Downtown, San Francisco",
    address: "456 Market St, San Francisco, CA 94105",
    phone: "(415) 555-0123",
    website: "https://goldenfork.com",
    description: "An exquisite Italian dining experience in the heart of downtown. Chef Marco brings authentic flavors from Tuscany with a modern Californian twist.",
    hours: [
      { day: "Monday", time: "11:00 AM - 10:00 PM" },
      { day: "Tuesday", time: "11:00 AM - 10:00 PM" },
      { day: "Wednesday", time: "11:00 AM - 10:00 PM" },
      { day: "Thursday", time: "11:00 AM - 11:00 PM" },
      { day: "Friday", time: "11:00 AM - 12:00 AM" },
      { day: "Saturday", time: "10:00 AM - 12:00 AM" },
      { day: "Sunday", time: "10:00 AM - 9:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1559339352-11d035aa65de?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1551218808-94e220e084d2?w=800&h=500&fit=crop",
    ],
    isSaved: true,
    isOpen: true,
    distance: "0.3 mi",
    lat: 37.7749,
    lng: -122.4194,
  },
  {
    id: "2",
    name: "Brew & Bean",
    image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=600&h=400&fit=crop",
    rating: 4.5,
    reviewCount: 218,
    priceRange: "$$",
    category: "Cafes",
    categories: ["Coffee", "Breakfast", "Pastries"],
    location: "Mission District, San Francisco",
    address: "789 Valencia St, San Francisco, CA 94110",
    phone: "(415) 555-0456",
    website: "https://brewandbean.com",
    description: "Artisan coffee roasted in-house daily. A cozy neighborhood spot with the best pour-overs in the city.",
    hours: [
      { day: "Monday", time: "6:00 AM - 7:00 PM" },
      { day: "Tuesday", time: "6:00 AM - 7:00 PM" },
      { day: "Wednesday", time: "6:00 AM - 7:00 PM" },
      { day: "Thursday", time: "6:00 AM - 7:00 PM" },
      { day: "Friday", time: "6:00 AM - 8:00 PM" },
      { day: "Saturday", time: "7:00 AM - 8:00 PM" },
      { day: "Sunday", time: "7:00 AM - 6:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "1.2 mi",
    lat: 37.7599,
    lng: -122.4148,
  },
  {
    id: "3",
    name: "Neon Nights Lounge",
    image: "https://images.unsplash.com/photo-1566417713940-fe7c737a9ef2?w=600&h=400&fit=crop",
    rating: 4.3,
    reviewCount: 156,
    priceRange: "$$$",
    category: "Nightlife",
    categories: ["Cocktail Bar", "Live Music", "Lounge"],
    location: "SoMa, San Francisco",
    address: "123 Folsom St, San Francisco, CA 94105",
    phone: "(415) 555-0789",
    website: "https://neonnights.com",
    description: "Premium cocktails and live jazz in a stunning art-deco setting. The place to be on Friday nights.",
    hours: [
      { day: "Monday", time: "Closed" },
      { day: "Tuesday", time: "5:00 PM - 1:00 AM" },
      { day: "Wednesday", time: "5:00 PM - 1:00 AM" },
      { day: "Thursday", time: "5:00 PM - 2:00 AM" },
      { day: "Friday", time: "5:00 PM - 2:00 AM" },
      { day: "Saturday", time: "5:00 PM - 2:00 AM" },
      { day: "Sunday", time: "Closed" },
    ],
    images: [
      "https://images.unsplash.com/photo-1566417713940-fe7c737a9ef2?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1572116469696-31de0f17cc34?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: false,
    distance: "0.8 mi",
    lat: 37.7849,
    lng: -122.3994,
  },
  {
    id: "4",
    name: "Urban Threads",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop",
    rating: 4.6,
    reviewCount: 89,
    priceRange: "$$",
    category: "Shopping",
    categories: ["Clothing", "Boutique", "Accessories"],
    location: "Hayes Valley, San Francisco",
    address: "321 Hayes St, San Francisco, CA 94102",
    phone: "(415) 555-0321",
    website: "https://urbanthreads.com",
    description: "Curated fashion from local and international designers. Sustainable style for the modern urbanite.",
    hours: [
      { day: "Monday", time: "10:00 AM - 7:00 PM" },
      { day: "Tuesday", time: "10:00 AM - 7:00 PM" },
      { day: "Wednesday", time: "10:00 AM - 7:00 PM" },
      { day: "Thursday", time: "10:00 AM - 8:00 PM" },
      { day: "Friday", time: "10:00 AM - 8:00 PM" },
      { day: "Saturday", time: "10:00 AM - 8:00 PM" },
      { day: "Sunday", time: "11:00 AM - 6:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=800&h=500&fit=crop",
    ],
    isSaved: true,
    isOpen: true,
    distance: "1.5 mi",
    lat: 37.7769,
    lng: -122.4234,
  },
  {
    id: "5",
    name: "Glow Beauty Studio",
    image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=600&h=400&fit=crop",
    rating: 4.8,
    reviewCount: 275,
    priceRange: "$$$",
    category: "Beauty",
    categories: ["Spa", "Hair Salon", "Skincare"],
    location: "Pacific Heights, San Francisco",
    address: "555 Fillmore St, San Francisco, CA 94117",
    phone: "(415) 555-0555",
    website: "https://glowbeauty.com",
    description: "Award-winning beauty studio offering premium hair, skin, and wellness services in a luxurious setting.",
    hours: [
      { day: "Monday", time: "9:00 AM - 7:00 PM" },
      { day: "Tuesday", time: "9:00 AM - 7:00 PM" },
      { day: "Wednesday", time: "9:00 AM - 7:00 PM" },
      { day: "Thursday", time: "9:00 AM - 8:00 PM" },
      { day: "Friday", time: "9:00 AM - 8:00 PM" },
      { day: "Saturday", time: "9:00 AM - 6:00 PM" },
      { day: "Sunday", time: "10:00 AM - 5:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "2.1 mi",
    lat: 37.7869,
    lng: -122.4334,
  },
  {
    id: "6",
    name: "Handy Home Pros",
    image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&h=400&fit=crop",
    rating: 4.4,
    reviewCount: 132,
    priceRange: "$$",
    category: "Home Services",
    categories: ["Plumbing", "Electrical", "General Repair"],
    location: "Sunset District, San Francisco",
    address: "890 Irving St, San Francisco, CA 94122",
    phone: "(415) 555-0890",
    website: "https://handyhomepros.com",
    description: "Reliable and affordable home repair services. Licensed professionals you can trust for any job.",
    hours: [
      { day: "Monday", time: "8:00 AM - 6:00 PM" },
      { day: "Tuesday", time: "8:00 AM - 6:00 PM" },
      { day: "Wednesday", time: "8:00 AM - 6:00 PM" },
      { day: "Thursday", time: "8:00 AM - 6:00 PM" },
      { day: "Friday", time: "8:00 AM - 6:00 PM" },
      { day: "Saturday", time: "9:00 AM - 4:00 PM" },
      { day: "Sunday", time: "Closed" },
    ],
    images: [
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "3.4 mi",
    lat: 37.7639,
    lng: -122.4634,
  },
  {
    id: "7",
    name: "Sakura Sushi",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=600&h=400&fit=crop",
    rating: 4.9,
    reviewCount: 412,
    priceRange: "$$$$",
    category: "Restaurants",
    categories: ["Japanese", "Sushi", "Omakase"],
    location: "Japantown, San Francisco",
    address: "1600 Post St, San Francisco, CA 94115",
    phone: "(415) 555-1600",
    website: "https://sakurasushi.com",
    description: "Authentic omakase experience by Chef Tanaka. Fresh fish flown in daily from Tokyo's Tsukiji market.",
    hours: [
      { day: "Monday", time: "Closed" },
      { day: "Tuesday", time: "5:30 PM - 10:00 PM" },
      { day: "Wednesday", time: "5:30 PM - 10:00 PM" },
      { day: "Thursday", time: "5:30 PM - 10:00 PM" },
      { day: "Friday", time: "5:30 PM - 11:00 PM" },
      { day: "Saturday", time: "12:00 PM - 11:00 PM" },
      { day: "Sunday", time: "12:00 PM - 9:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1553621042-f6e147245754?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?w=800&h=500&fit=crop",
    ],
    isSaved: true,
    isOpen: true,
    distance: "1.8 mi",
    lat: 37.7859,
    lng: -122.4294,
  },
  {
    id: "8",
    name: "The Rustic Table",
    image: "https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?w=600&h=400&fit=crop",
    rating: 4.2,
    reviewCount: 198,
    priceRange: "$$",
    category: "Restaurants",
    categories: ["American", "Brunch", "Farm-to-Table"],
    location: "Noe Valley, San Francisco",
    address: "3800 24th St, San Francisco, CA 94114",
    phone: "(415) 555-3800",
    website: "https://rustictable.com",
    description: "Farm-to-table American cuisine with a focus on sustainable, locally-sourced ingredients. Famous weekend brunch.",
    hours: [
      { day: "Monday", time: "8:00 AM - 9:00 PM" },
      { day: "Tuesday", time: "8:00 AM - 9:00 PM" },
      { day: "Wednesday", time: "8:00 AM - 9:00 PM" },
      { day: "Thursday", time: "8:00 AM - 10:00 PM" },
      { day: "Friday", time: "8:00 AM - 10:00 PM" },
      { day: "Saturday", time: "8:00 AM - 10:00 PM" },
      { day: "Sunday", time: "8:00 AM - 9:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "2.5 mi",
    lat: 37.7509,
    lng: -122.4334,
  },
  // New businesses
  {
    id: "9",
    name: "Pho King Delicious",
    image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=600&h=400&fit=crop",
    rating: 4.6,
    reviewCount: 287,
    priceRange: "$",
    category: "Restaurants",
    categories: ["Vietnamese", "Soup", "Asian"],
    location: "Tenderloin, San Francisco",
    address: "230 Larkin St, San Francisco, CA 94102",
    phone: "(415) 555-2300",
    website: "https://phokingdelicious.com",
    description: "Authentic Vietnamese pho and banh mi made with family recipes passed down three generations. The bone broth simmers for 24 hours.",
    hours: defaultHours,
    images: [
      "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1555126634-323283e090fa?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "0.6 mi",
    lat: 37.7825,
    lng: -122.4150,
  },
  {
    id: "10",
    name: "Velvet Espresso",
    image: "https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=600&h=400&fit=crop",
    rating: 4.7,
    reviewCount: 164,
    priceRange: "$$",
    category: "Cafes",
    categories: ["Coffee", "Desserts", "Wifi"],
    location: "North Beach, San Francisco",
    address: "580 Columbus Ave, San Francisco, CA 94133",
    phone: "(415) 555-5800",
    website: "https://velvetespresso.com",
    description: "Third-wave coffee shop with single-origin beans and house-made pastries. A paradise for remote workers with lightning-fast wifi.",
    hours: [
      { day: "Monday", time: "6:30 AM - 8:00 PM" },
      { day: "Tuesday", time: "6:30 AM - 8:00 PM" },
      { day: "Wednesday", time: "6:30 AM - 8:00 PM" },
      { day: "Thursday", time: "6:30 AM - 8:00 PM" },
      { day: "Friday", time: "6:30 AM - 9:00 PM" },
      { day: "Saturday", time: "7:00 AM - 9:00 PM" },
      { day: "Sunday", time: "7:00 AM - 7:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1511920170033-f8396924c348?w=800&h=500&fit=crop",
    ],
    isSaved: true,
    isOpen: true,
    distance: "1.0 mi",
    lat: 37.7980,
    lng: -122.4074,
  },
  {
    id: "11",
    name: "Luna Rooftop Bar",
    image: "https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=600&h=400&fit=crop",
    rating: 4.4,
    reviewCount: 203,
    priceRange: "$$$",
    category: "Nightlife",
    categories: ["Rooftop Bar", "Cocktails", "Views"],
    location: "Financial District, San Francisco",
    address: "101 California St, San Francisco, CA 94111",
    phone: "(415) 555-1010",
    website: "https://lunarooftop.com",
    description: "Skyline views, craft cocktails, and small plates 32 floors above the city. The sunset happy hour is legendary.",
    hours: [
      { day: "Monday", time: "Closed" },
      { day: "Tuesday", time: "4:00 PM - 12:00 AM" },
      { day: "Wednesday", time: "4:00 PM - 12:00 AM" },
      { day: "Thursday", time: "4:00 PM - 1:00 AM" },
      { day: "Friday", time: "4:00 PM - 2:00 AM" },
      { day: "Saturday", time: "3:00 PM - 2:00 AM" },
      { day: "Sunday", time: "3:00 PM - 11:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "0.4 mi",
    lat: 37.7935,
    lng: -122.3985,
  },
  {
    id: "12",
    name: "The Vintage Rack",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=600&h=400&fit=crop",
    rating: 4.3,
    reviewCount: 76,
    priceRange: "$",
    category: "Shopping",
    categories: ["Vintage", "Thrift", "Clothing"],
    location: "Haight-Ashbury, San Francisco",
    address: "1475 Haight St, San Francisco, CA 94117",
    phone: "(415) 555-1475",
    website: "https://thevintagerack.com",
    description: "Hand-curated vintage clothing and accessories from the '60s to '90s. Treasure hunting at its finest in the heart of Haight-Ashbury.",
    hours: defaultHours,
    images: [
      "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "2.3 mi",
    lat: 37.7695,
    lng: -122.4508,
  },
  {
    id: "13",
    name: "Zen Wellness Spa",
    image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&h=400&fit=crop",
    rating: 4.9,
    reviewCount: 310,
    priceRange: "$$$$",
    category: "Beauty",
    categories: ["Spa", "Massage", "Wellness"],
    location: "Marina District, San Francisco",
    address: "2100 Chestnut St, San Francisco, CA 94123",
    phone: "(415) 555-2100",
    website: "https://zenwellness.com",
    description: "A sanctuary of tranquility offering Japanese-inspired spa treatments. Hot stone massages, aromatherapy, and rejuvenating facials.",
    hours: [
      { day: "Monday", time: "10:00 AM - 8:00 PM" },
      { day: "Tuesday", time: "10:00 AM - 8:00 PM" },
      { day: "Wednesday", time: "10:00 AM - 8:00 PM" },
      { day: "Thursday", time: "10:00 AM - 9:00 PM" },
      { day: "Friday", time: "10:00 AM - 9:00 PM" },
      { day: "Saturday", time: "9:00 AM - 9:00 PM" },
      { day: "Sunday", time: "9:00 AM - 7:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1540555700478-4be289fbec6d?w=800&h=500&fit=crop",
    ],
    isSaved: true,
    isOpen: true,
    distance: "1.7 mi",
    lat: 37.8005,
    lng: -122.4382,
  },
  {
    id: "14",
    name: "CleanSweep Services",
    image: "https://images.unsplash.com/photo-1558317374-067fb5f30001?w=600&h=400&fit=crop",
    rating: 4.5,
    reviewCount: 95,
    priceRange: "$$",
    category: "Home Services",
    categories: ["Cleaning", "Organizing", "Deep Clean"],
    location: "Richmond District, San Francisco",
    address: "450 Clement St, San Francisco, CA 94118",
    phone: "(415) 555-4500",
    website: "https://cleansweepsf.com",
    description: "Eco-friendly house cleaning using all-natural products. Move-in/out cleans, regular maintenance, and deep cleaning services.",
    hours: [
      { day: "Monday", time: "7:00 AM - 6:00 PM" },
      { day: "Tuesday", time: "7:00 AM - 6:00 PM" },
      { day: "Wednesday", time: "7:00 AM - 6:00 PM" },
      { day: "Thursday", time: "7:00 AM - 6:00 PM" },
      { day: "Friday", time: "7:00 AM - 6:00 PM" },
      { day: "Saturday", time: "8:00 AM - 4:00 PM" },
      { day: "Sunday", time: "Closed" },
    ],
    images: [
      "https://images.unsplash.com/photo-1558317374-067fb5f30001?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "2.8 mi",
    lat: 37.7825,
    lng: -122.4592,
  },
  {
    id: "15",
    name: "Taqueria El Sol",
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600&h=400&fit=crop",
    rating: 4.8,
    reviewCount: 523,
    priceRange: "$",
    category: "Restaurants",
    categories: ["Mexican", "Tacos", "Burritos"],
    location: "Mission District, San Francisco",
    address: "2889 Mission St, San Francisco, CA 94110",
    phone: "(415) 555-2889",
    website: "https://taqueriaelsol.com",
    description: "The Mission's best-kept secret for authentic street tacos. Al pastor on a real trompo, handmade tortillas, and legendary salsa verde.",
    hours: [
      { day: "Monday", time: "10:00 AM - 11:00 PM" },
      { day: "Tuesday", time: "10:00 AM - 11:00 PM" },
      { day: "Wednesday", time: "10:00 AM - 11:00 PM" },
      { day: "Thursday", time: "10:00 AM - 12:00 AM" },
      { day: "Friday", time: "10:00 AM - 2:00 AM" },
      { day: "Saturday", time: "10:00 AM - 2:00 AM" },
      { day: "Sunday", time: "10:00 AM - 10:00 PM" },
    ],
    images: [
      "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "1.4 mi",
    lat: 37.7505,
    lng: -122.4185,
  },
  {
    id: "16",
    name: "Page Turner Books",
    image: "https://images.unsplash.com/photo-1526243741027-444d633d7365?w=600&h=400&fit=crop",
    rating: 4.7,
    reviewCount: 142,
    priceRange: "$$",
    category: "Shopping",
    categories: ["Books", "Cafe", "Events"],
    location: "Cole Valley, San Francisco",
    address: "900 Cole St, San Francisco, CA 94117",
    phone: "(415) 555-9000",
    website: "https://pageturnerbooks.com",
    description: "Independent bookstore with a curated selection, in-store coffee bar, and weekly author readings. A literary haven.",
    hours: defaultHours,
    images: [
      "https://images.unsplash.com/photo-1526243741027-444d633d7365?w=800&h=500&fit=crop",
      "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800&h=500&fit=crop",
    ],
    isSaved: false,
    isOpen: true,
    distance: "2.0 mi",
    lat: 37.7655,
    lng: -122.4498,
  },
];

// Category-specific hero images for carousel
export const categoryHeroImages = {
  "restaurants": "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=2400&h=1350&fit=crop&auto=format&q=85",
  "cafes": "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085d?w=2400&h=1350&fit=crop&auto=format&q=85",
  "nightlife": "https://images.unsplash.com/photo-1566417713940-fe7c737a9ef2?w=2400&h=1350&fit=crop&auto=format&q=85",
  "shopping": "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=2400&h=1350&fit=crop&auto=format&q=85",
  "beauty": "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=2400&h=1350&fit=crop&auto=format&q=85",
  "home-services": "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=2400&h=1350&fit=crop&auto=format&q=85",
};

// Dynamic categories calculated from business data
export const getDynamicCategories = () => {
  const categoryMap = new Map<string, { 
    id: string; 
    name: string; 
    icon: string; 
    count: number; 
    color: string;
  }>();

  // Predefined category configurations
  const categoryConfigs = {
    "restaurants": { icon: "UtensilsCrossed", color: "from-red-500 to-orange-500" },
    "cafes": { icon: "Coffee", color: "from-amber-500 to-yellow-500" },
    "nightlife": { icon: "Wine", color: "from-purple-500 to-pink-500" },
    "shopping": { icon: "ShoppingBag", color: "from-blue-500 to-cyan-500" },
    "beauty": { icon: "Sparkles", color: "from-pink-500 to-rose-500" },
    "home-services": { icon: "Wrench", color: "from-green-500 to-emerald-500" },
  };

  // Count businesses per category
  businesses.forEach(business => {
    const categoryId = business.category.toLowerCase().replace(/\s+/g, '-');
    const config = categoryConfigs[categoryId as keyof typeof categoryConfigs];
    
    if (config) {
      const existing = categoryMap.get(categoryId);
      if (existing) {
        existing.count += 1;
      } else {
        categoryMap.set(categoryId, {
          id: categoryId,
          name: business.category,
          icon: config.icon,
          count: 1,
          color: config.color
        });
      }
    }
  });

  return Array.from(categoryMap.values());
};

// Fallback static categories for compatibility
export const categories = [
  { id: "restaurants", name: "Restaurants", icon: "UtensilsCrossed", count: 0, color: "from-red-500 to-orange-500" },
  { id: "cafes", name: "Cafes", icon: "Coffee", count: 0, color: "from-amber-500 to-yellow-500" },
  { id: "nightlife", name: "Nightlife", icon: "Wine", count: 0, color: "from-purple-500 to-pink-500" },
  { id: "shopping", name: "Shopping", icon: "ShoppingBag", count: 0, color: "from-blue-500 to-cyan-500" },
  { id: "beauty", name: "Beauty", icon: "Sparkles", count: 0, color: "from-pink-500 to-rose-500" },
  { id: "home-services", name: "Home Services", icon: "Wrench", count: 0, color: "from-green-500 to-emerald-500" },
];

export type TrendingCity = {
  name: string;
  slug: string;
  image: string;
  count: number;
};

const trendingCitiesData: Omit<TrendingCity, "count">[] = [
  { name: "San Francisco", slug: "san-francisco", image: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=400&h=300&fit=crop" },
  { name: "New York", slug: "new-york", image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400&h=300&fit=crop" },
  { name: "Los Angeles", slug: "los-angeles", image: "https://images.unsplash.com/photo-1534190760961-74e8c1c5c3da?w=400&h=300&fit=crop" },
  { name: "Chicago", slug: "chicago", image: "https://images.unsplash.com/photo-1494522855154-9297ac14b55f?w=400&h=300&fit=crop" },
  { name: "Austin", slug: "austin", image: "https://images.unsplash.com/photo-1531218150217-54595bc2b934?w=400&h=300&fit=crop" },
  { name: "Seattle", slug: "seattle", image: "https://images.unsplash.com/photo-1502175353174-a7a70e73b4c3?w=400&h=300&fit=crop" },
];

/** Whether a business is in the given city (matches location or address). */
export function businessInCity(business: Business, cityName: string): boolean {
  const lower = cityName.toLowerCase();
  return (
    business.location.toLowerCase().includes(lower) ||
    business.address.toLowerCase().includes(lower)
  );
}

/** Trending cities with counts derived from actual businesses in that location. */
export const trendingCities: TrendingCity[] = trendingCitiesData.map((city) => ({
  ...city,
  count: businesses.filter((b) => businessInCity(b, city.name)).length,
}));
