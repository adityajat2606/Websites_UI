export interface BusinessFilters {
  minRating: number;
  priceRange: string[];
  categories: string[];
  maxDistanceMiles: number;
  openNow: boolean;
}

export const DEFAULT_FILTERS: BusinessFilters = {
  minRating: 0,
  priceRange: [],
  categories: [],
  maxDistanceMiles: 25,
  openNow: false,
};
