import { useState, createContext, useContext, ReactNode, useCallback } from "react";

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  favorites: string[];
}

interface AuthContextType {
  isAuthenticated: boolean;
  user: UserProfile | null;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  toggleFavorite: (photoId: string) => void;
  updateProfile: (updates: Partial<Pick<UserProfile, "name" | "avatar">>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

interface StoredUser {
  profile: UserProfile;
  password: string;
}

const getStoredUsers = (): StoredUser[] => {
  try {
    return JSON.parse(localStorage.getItem("luxe_users") || "[]");
  } catch {
    return [];
  }
};

const saveStoredUsers = (users: StoredUser[]) => {
  localStorage.setItem("luxe_users", JSON.stringify(users));
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);

  const login = (email: string, password: string) => {
    const users = getStoredUsers();
    const found = users.find((u) => u.profile.email === email && u.password === password);
    if (found) {
      setIsAuthenticated(true);
      setUser(found.profile);
      return true;
    }
    return false;
  };

  const signup = (name: string, email: string, password: string) => {
    const users = getStoredUsers();
    if (users.some((u) => u.profile.email === email)) {
      return false; // email already exists
    }
    const newUser: UserProfile = {
      id: crypto.randomUUID(),
      name,
      email,
      avatar: "",
      favorites: [],
    };
    saveStoredUsers([...users, { profile: newUser, password }]);
    setIsAuthenticated(true);
    setUser(newUser);
    return true;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
  };

  const toggleFavorite = useCallback((photoId: string) => {
    setUser((prev) => {
      if (!prev) return prev;
      const isFav = prev.favorites.includes(photoId);
      const updated = {
        ...prev,
        favorites: isFav
          ? prev.favorites.filter((id) => id !== photoId)
          : [...prev.favorites, photoId],
      };
      // Persist favorites
      const users = getStoredUsers();
      const idx = users.findIndex((u) => u.profile.id === prev.id);
      if (idx >= 0) {
        users[idx].profile = updated;
        saveStoredUsers(users);
      }
      return updated;
    });
  }, []);

  const updateProfile = useCallback((updates: Partial<Pick<UserProfile, "name" | "avatar">>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const updated = { ...prev, ...updates };
      const users = getStoredUsers();
      const idx = users.findIndex((u) => u.profile.id === prev.id);
      if (idx >= 0) {
        users[idx].profile = updated;
        saveStoredUsers(users);
      }
      return updated;
    });
  }, []);

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, signup, logout, toggleFavorite, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};
