import { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import LoadingScreen from "@/components/LoadingScreen";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import GalleryPage from "./pages/GalleryPage";
import ProfilePage from "./pages/ProfilePage";
import AuthPage from "./pages/AuthPage";
import AdminLayout from "./pages/AdminLayout";
import BlogPage from "./pages/BlogPage";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUpload from "./pages/admin/AdminUpload";
import AdminManage from "./pages/admin/AdminManage";
import AdminAnalytics from "./pages/admin/AdminAnalytics";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <div className="dark">
            <Toaster />
            <Sonner />
            <LoadingScreen isLoading={isLoading} />
            <BrowserRouter>
              <Routes>
                {/* Public routes with navbar */}
                <Route
                  path="/"
                  element={
                    <>
                      <Navbar />
                      <Index />
                    </>
                  }
                />
                <Route
                  path="/gallery"
                  element={
                    <>
                      <Navbar />
                      <GalleryPage />
                    </>
                  }
                />
                <Route
                  path="/blog"
                  element={
                    <>
                      <Navbar />
                      <BlogPage />
                    </>
                  }
                />

                {/* Auth page */}
                <Route path="/login" element={<AuthPage />} />

                {/* Profile route (protected) */}
                <Route element={<ProtectedRoute />}>
                  <Route
                    path="/profile"
                    element={
                      <>
                        <Navbar />
                        <ProfilePage />
                      </>
                    }
                  />
                </Route>

                {/* Protected dashboard routes */}
                <Route element={<ProtectedRoute />}>
                  <Route path="/admin" element={<AdminLayout />}>
                    <Route index element={<AdminDashboard />} />
                    <Route path="upload" element={<AdminUpload />} />
                    <Route path="manage" element={<AdminManage />} />
                    <Route path="analytics" element={<AdminAnalytics />} />
                  </Route>
                </Route>

                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </div>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
