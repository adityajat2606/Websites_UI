import { useState } from "react";
import { motion } from "framer-motion";
import { Lock, Mail, User } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate, useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { pageTransition, slideUp } from "@/animations/variants";
import Navbar from "@/components/Navbar";

const AuthPage = () => {
  const [searchParams] = useSearchParams();
  const [isSignUp, setIsSignUp] = useState(searchParams.get("signup") === "true");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login, signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSignUp) {
      if (!name.trim()) {
        toast.error("Please enter your name");
        return;
      }
      if (signup(name, email, password)) {
        toast.success("Account created! Welcome to LUXE.");
        navigate("/profile");
      } else {
        toast.error("An account with this email already exists.");
      }
    } else {
      if (login(email, password)) {
        toast.success("Welcome back!");
        navigate("/profile");
      } else {
        toast.error("Invalid email or password.");
      }
    }
  };

  return (
    <>
      <Navbar />
      <motion.div
        className="min-h-screen flex items-center justify-center px-6 bg-background pt-20"
        variants={pageTransition}
        initial="initial"
        animate="animate"
      >
        <motion.div
          className="glass-panel rounded-sm p-10 w-full max-w-md"
          variants={slideUp}
          initial="hidden"
          animate="visible"
        >
          <div className="text-center mb-8">
            <h1 className="text-gradient-gold font-display text-3xl font-bold tracking-widest mb-2">LUXE</h1>
            <p className="text-muted-foreground font-body text-sm">
              {isSignUp ? "Create your account" : "Sign in to your account"}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {isSignUp && (
              <div className="relative">
                <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-card border border-border rounded-sm pl-11 pr-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
                />
              </div>
            )}
            <div className="relative">
              <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-card border border-border rounded-sm pl-11 pr-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
              />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-card border border-border rounded-sm pl-11 pr-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
              />
            </div>
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="bg-gradient-gold px-8 py-3 text-sm font-body font-semibold tracking-[0.2em] uppercase text-primary-foreground rounded-sm shadow-gold mt-2"
            >
              {isSignUp ? "Create Account" : "Sign In"}
            </motion.button>
          </form>

          <p className="text-muted-foreground text-sm font-body text-center mt-6">
            {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-gold hover:underline font-semibold"
            >
              {isSignUp ? "Sign In" : "Sign Up"}
            </button>
          </p>
        </motion.div>
      </motion.div>
    </>
  );
};

export default AuthPage;
