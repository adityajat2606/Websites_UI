import { useState } from "react";
import { motion } from "framer-motion";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { LayoutDashboard, Upload, Image, BarChart3, LogOut, Menu, ArrowLeft } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { pageTransition } from "@/animations/variants";

const sidebarLinks = [
  { label: "Dashboard", to: "/admin", icon: LayoutDashboard, end: true },
  { label: "Upload", to: "/admin/upload", icon: Upload },
  { label: "Manage Photos", to: "/admin/manage", icon: Image },
  { label: "Analytics", to: "/admin/analytics", icon: BarChart3 },
];

const AdminLayout = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleBack = () => {
    // If the user landed directly on /admin (no history), send them home.
    if (window.history.length <= 1) {
      navigate("/");
      return;
    }
    navigate(-1);
  };

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <motion.div
      className="min-h-screen flex bg-background"
      variants={pageTransition}
      initial="initial"
      animate="animate"
    >
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 glass-panel-strong flex flex-col transition-transform duration-300 lg:relative lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="p-6 border-b border-border">
          <h2 className="text-gradient-gold font-display text-xl font-bold tracking-widest">LUXE</h2>
          <p className="text-muted-foreground font-body text-xs mt-1">Admin Panel</p>
        </div>

        <nav className="flex-1 p-4 flex flex-col gap-1">
          {sidebarLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-sm text-sm font-body transition-all duration-200 ${
                  isActive
                    ? "bg-gradient-gold text-primary-foreground shadow-gold"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                }`
              }
            >
              <link.icon size={18} />
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-border">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-3 rounded-sm text-sm font-body text-muted-foreground hover:text-destructive transition-colors w-full"
          >
            <LogOut size={18} /> Sign Out
          </button>
        </div>
      </aside>

      {/* Backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-background/50 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 flex items-center px-6 border-b border-border glass-panel">
          <button className="lg:hidden mr-4 text-foreground" onClick={() => setSidebarOpen(true)}>
            <Menu size={22} />
          </button>
          <button
            onClick={handleBack}
            className="mr-4 inline-flex items-center gap-2 text-sm font-body text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft size={18} />
            Back
          </button>
          <h1 className="font-display text-lg font-semibold text-foreground">
            {location.pathname === "/admin"
              ? "Dashboard"
              : location.pathname === "/admin/upload"
                ? "Upload"
                : location.pathname === "/admin/manage"
                  ? "Manage Photos"
                  : location.pathname === "/admin/analytics"
                    ? "Analytics"
                    : "Dashboard"}
          </h1>
        </header>

        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </motion.div>
  );
};

export default AdminLayout;
