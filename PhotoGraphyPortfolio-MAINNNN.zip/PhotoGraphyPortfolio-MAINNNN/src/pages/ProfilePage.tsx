import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { User, Heart, Settings, LogOut, Camera, Save } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { photos } from "@/data/photos";
import { pageTransition, slideUp, staggerContainer } from "@/animations/variants";
import Lightbox from "@/components/Lightbox";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const ProfilePage = () => {
  const { user, logout, toggleFavorite, updateProfile } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"favorites" | "settings">("favorites");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [editName, setEditName] = useState(user?.name || "");
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const favoritePhotos = photos.filter((p) => user?.favorites.includes(p.id));

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const handleAvatarFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }
    const maxSizeMb = 2;
    if (file.size > maxSizeMb * 1024 * 1024) {
      toast.error(`Please choose an image under ${maxSizeMb}MB`);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === "string" ? reader.result : "";
      if (!dataUrl) {
        toast.error("Could not read that file");
        return;
      }
      updateProfile({ avatar: dataUrl });
      toast.success("Profile photo updated");
    };
    reader.onerror = () => toast.error("Could not read that file");
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = () => {
    updateProfile({ name: editName });
    toast.success("Profile updated successfully");
  };

  const tabs = [
    { key: "favorites" as const, label: "Favorites", icon: Heart, count: favoritePhotos.length },
    { key: "settings" as const, label: "Settings", icon: Settings },
  ];

  return (
    <motion.div
      className="pt-24 min-h-screen"
      variants={pageTransition}
      initial="initial"
      animate="animate"
    >
      <div className="container mx-auto px-6">
        {/* Profile Header */}
        <motion.div
          className="glass-panel rounded-sm p-8 md:p-12 mb-8"
          variants={slideUp}
          initial="hidden"
          animate="visible"
        >
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="relative group">
              <div className="w-24 h-24 rounded-full bg-gradient-gold flex items-center justify-center shadow-gold">
                {user?.avatar ? (
                  <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
                ) : (
                  <User size={40} className="text-primary-foreground" />
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleAvatarFile(f);
                  e.currentTarget.value = "";
                }}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 glass-panel p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Camera size={14} className="text-gold" />
              </button>
            </div>
            <div className="text-center md:text-left flex-1">
              <h1 className="font-display text-3xl font-bold text-foreground">{user?.name}</h1>
              <p className="text-muted-foreground font-body text-sm mt-1">{user?.email}</p>
              <p className="text-gold font-body text-xs tracking-[0.2em] uppercase mt-2">
                {favoritePhotos.length} Favorites · Member
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-5 py-2.5 glass-panel rounded-sm text-sm font-body text-muted-foreground hover:text-destructive transition-colors"
            >
              <LogOut size={16} /> Sign Out
            </button>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-6 py-3 rounded-sm text-sm font-body tracking-[0.1em] uppercase transition-all duration-300 ${
                activeTab === tab.key
                  ? "bg-gradient-gold text-primary-foreground shadow-gold"
                  : "glass-panel text-muted-foreground hover:text-foreground"
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
              {tab.count !== undefined && (
                <span className="ml-1 text-xs opacity-70">({tab.count})</span>
              )}
            </button>
          ))}
        </div>

        {/* Favorites Tab */}
        {activeTab === "favorites" && (
          <motion.div variants={staggerContainer} initial="hidden" animate="visible">
            {favoritePhotos.length === 0 ? (
              <motion.div
                className="glass-panel rounded-sm p-16 text-center"
                variants={slideUp}
              >
                <Heart size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="font-display text-xl text-foreground mb-2">No favorites yet</h3>
                <p className="text-muted-foreground font-body text-sm">
                  Browse the gallery and click the heart icon to save your favorite photos.
                </p>
                <button
                  onClick={() => navigate("/gallery")}
                  className="mt-6 bg-gradient-gold px-6 py-2.5 text-xs font-body font-semibold tracking-[0.15em] uppercase text-primary-foreground rounded-sm shadow-gold"
                >
                  Explore Gallery
                </button>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {favoritePhotos.map((photo, index) => (
                  <motion.div
                    key={photo.id}
                    className="relative group cursor-pointer overflow-hidden rounded-sm aspect-[4/3]"
                    variants={slideUp}
                    onClick={() => setLightboxIndex(index)}
                  >
                    <img
                      src={photo.url}
                      alt={photo.title}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-background/0 group-hover:bg-background/60 transition-all duration-500 flex items-end p-4">
                      <div className="w-full opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                        <h3 className="font-display text-lg font-semibold text-foreground">{photo.title}</h3>
                        <p className="text-muted-foreground text-xs font-body">{photo.description}</p>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(photo.id);
                        toast.success("Removed from favorites");
                      }}
                      className="absolute top-3 right-3 glass-panel p-2 rounded-full text-gold hover:scale-110 transition-transform"
                    >
                      <Heart size={16} fill="currentColor" />
                    </button>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <motion.div
            className="glass-panel rounded-sm p-8 max-w-lg"
            variants={slideUp}
            initial="hidden"
            animate="visible"
          >
            <h3 className="font-display text-xl font-semibold text-foreground mb-6">Account Settings</h3>
            <div className="flex flex-col gap-5">
              <div>
                <label className="text-xs font-body tracking-[0.15em] uppercase text-muted-foreground mb-2 block">
                  Display Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-card border border-border rounded-sm px-4 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <div>
                <label className="text-xs font-body tracking-[0.15em] uppercase text-muted-foreground mb-2 block">
                  Email
                </label>
                <input
                  type="email"
                  value={user?.email || ""}
                  disabled
                  className="w-full bg-card border border-border rounded-sm px-4 py-3 text-muted-foreground font-body text-sm cursor-not-allowed opacity-60"
                />
              </div>
              <motion.button
                onClick={handleSaveProfile}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center justify-center gap-2 bg-gradient-gold px-6 py-3 text-sm font-body font-semibold tracking-[0.15em] uppercase text-primary-foreground rounded-sm shadow-gold mt-2"
              >
                <Save size={16} /> Save Changes
              </motion.button>
            </div>
          </motion.div>
        )}
      </div>

      <div className="mt-20">
        <Footer />
      </div>

      <Lightbox
        photos={favoritePhotos}
        currentIndex={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onNavigate={setLightboxIndex}
      />
    </motion.div>
  );
};

export default ProfilePage;
