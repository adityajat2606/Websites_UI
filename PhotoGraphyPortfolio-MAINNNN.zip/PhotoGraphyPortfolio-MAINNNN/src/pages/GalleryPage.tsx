import { motion } from "framer-motion";
import GalleryGrid from "@/components/GalleryGrid";
import Footer from "@/components/Footer";
import { photos } from "@/data/photos";
import { pageTransition, slideUp } from "@/animations/variants";

const GalleryPage = () => {
  return (
    <motion.div
      className="pt-24"
      variants={pageTransition}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <div className="container mx-auto px-6 mb-8">
        <motion.div
          className="text-center"
          variants={slideUp}
          initial="hidden"
          animate="visible"
        >
          <span className="text-gold font-body text-xs tracking-[0.3em] uppercase">Explore</span>
          <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mt-4">
            The <span className="text-gradient-gold italic">Gallery</span>
          </h1>
          <div className="line-gold w-20 mx-auto mt-6" />
        </motion.div>
      </div>

      <GalleryGrid photos={photos} />
      <Footer />
    </motion.div>
  );
};

export default GalleryPage;
