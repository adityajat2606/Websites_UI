import { motion } from "framer-motion";
import Footer from "@/components/Footer";
import { pageTransition, slideUp, staggerContainer } from "@/animations/variants";

const posts = [
  {
    title: "Behind the Lens: Building a Premium Gallery",
    date: "2024-11-12",
    excerpt:
      "A quick look at how we curate collections, keep layouts feeling organic, and design interactions that stay fast on any device.",
  },
  {
    title: "Lighting Notes: From Golden Hour to Studio",
    date: "2024-10-03",
    excerpt:
      "Practical tips on shaping light and color grading for a consistent, high-end look across a full portfolio.",
  },
  {
    title: "Print vs. Digital: Preparing Images for Both",
    date: "2024-08-19",
    excerpt:
      "Resolution, aspect ratios, and compression choices that keep your work sharp on screens and beautiful in print.",
  },
];

const BlogPage = () => {
  return (
    <motion.div className="pt-24" variants={pageTransition} initial="initial" animate="animate" exit="exit">
      <div className="container mx-auto px-6">
        <motion.div className="text-center mb-12" variants={slideUp} initial="hidden" animate="visible">
          <span className="text-gold font-body text-xs tracking-[0.3em] uppercase">Journal</span>
          <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mt-4">
            The <span className="text-gradient-gold italic">Blog</span>
          </h1>
          <div className="line-gold w-20 mx-auto mt-6" />
          <p className="text-muted-foreground font-body text-sm mt-6 max-w-2xl mx-auto">
            Notes on photography, curation, and the craft behind visual storytelling.
          </p>
        </motion.div>

        <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="grid gap-6 max-w-3xl mx-auto">
          {posts.map((p) => (
            <motion.article key={p.title} variants={slideUp} className="glass-panel rounded-sm p-8">
              <p className="text-muted-foreground font-body text-xs tracking-[0.2em] uppercase">{p.date}</p>
              <h2 className="font-display text-2xl font-semibold text-foreground mt-3">{p.title}</h2>
              <p className="text-muted-foreground font-body text-sm mt-3 leading-relaxed">{p.excerpt}</p>
            </motion.article>
          ))}
        </motion.div>
      </div>

      <div className="mt-20">
        <Footer />
      </div>
    </motion.div>
  );
};

export default BlogPage;

