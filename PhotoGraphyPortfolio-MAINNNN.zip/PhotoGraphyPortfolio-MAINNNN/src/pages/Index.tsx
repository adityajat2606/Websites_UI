import { motion } from "framer-motion";
import HeroSection from "@/components/HeroSection";
import GalleryGrid from "@/components/GalleryGrid";
import FeaturedSection from "@/components/FeaturedSection";
import StatsSection from "@/components/StatsSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import { photos } from "@/data/photos";
import { pageTransition } from "@/animations/variants";

const Index = () => {
  return (
    <motion.div
      variants={pageTransition}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <HeroSection />

      <section className="py-24 px-6">
        <div className="container mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-gold font-body text-xs tracking-[0.3em] uppercase">Portfolio</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mt-4">
              Selected <span className="text-gradient-gold italic">Works</span>
            </h2>
            <div className="line-gold w-20 mx-auto mt-6" />
          </motion.div>
        </div>
        <GalleryGrid photos={photos.slice(0, 6)} showFilters={false} />
      </section>

      <FeaturedSection />
      <StatsSection />
      <TestimonialsSection />
      <ContactSection />
      <Footer />
    </motion.div>
  );
};

export default Index;
