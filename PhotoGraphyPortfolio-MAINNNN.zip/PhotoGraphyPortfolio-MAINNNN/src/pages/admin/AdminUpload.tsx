import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { Upload, Image, X } from "lucide-react";
import { toast } from "sonner";
import { slideUp } from "@/animations/variants";

const AdminUpload = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [form, setForm] = useState({ title: "", description: "", category: "Nature", tags: "" });

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(e.type === "dragenter" || e.type === "dragover");
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const dropped = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith("image/"));
    setFiles((prev) => [...prev, ...dropped]);
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles((prev) => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const removeFile = (index: number) => setFiles((prev) => prev.filter((_, i) => i !== index));

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!files.length) { toast.error("Please select files"); return; }
    if (!form.title.trim()) { toast.error("Please enter a title"); return; }
    toast.success(`${files.length} photo(s) uploaded successfully!`);
    setFiles([]);
    setForm({ title: "", description: "", category: "Nature", tags: "" });
  };

  return (
    <motion.div variants={slideUp} initial="hidden" animate="visible">
      <h2 className="font-display text-2xl font-bold text-foreground mb-6">Upload Photos</h2>

      <form onSubmit={handleUpload} className="space-y-6">
        {/* Drop zone */}
        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          className={`glass-panel rounded-sm p-12 text-center cursor-pointer transition-all duration-300 border-2 border-dashed ${
            isDragging ? "border-gold bg-gold/5" : "border-border"
          }`}
          onClick={() => document.getElementById("file-input")?.click()}
        >
          <Upload size={40} className="mx-auto text-gold mb-4" />
          <p className="text-foreground font-body text-sm mb-1">Drag & drop images here</p>
          <p className="text-muted-foreground font-body text-xs">or click to browse</p>
          <input id="file-input" type="file" accept="image/*" multiple onChange={handleFileInput} className="hidden" />
        </div>

        {/* Preview */}
        {files.length > 0 && (
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
            {files.map((f, i) => (
              <div key={i} className="relative aspect-square rounded-sm overflow-hidden group">
                <img src={URL.createObjectURL(f)} alt={f.name} className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => removeFile(i)}
                  className="absolute top-1 right-1 bg-background/80 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X size={14} className="text-destructive" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Metadata */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            type="text" placeholder="Title" value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
          />
          <select
            value={form.category}
            onChange={(e) => setForm({ ...form, category: e.target.value })}
            className="bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm focus:outline-none focus:border-gold transition-colors"
          >
            {["Nature", "Portrait", "Wedding", "Travel", "Street"].map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <textarea
          placeholder="Description" rows={3} value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="w-full bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors resize-none"
        />
        <input
          type="text" placeholder="Tags (comma separated)" value={form.tags}
          onChange={(e) => setForm({ ...form, tags: e.target.value })}
          className="w-full bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
        />

        <motion.button
          type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
          className="bg-gradient-gold px-8 py-3 text-sm font-body font-semibold tracking-[0.2em] uppercase text-primary-foreground rounded-sm shadow-gold flex items-center gap-2"
        >
          <Upload size={16} /> Upload Photos
        </motion.button>
      </form>
    </motion.div>
  );
};

export default AdminUpload;
