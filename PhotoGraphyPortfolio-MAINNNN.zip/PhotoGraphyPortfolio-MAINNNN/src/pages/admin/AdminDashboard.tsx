import { motion } from "framer-motion";
import { Camera, Eye, Heart, TrendingUp } from "lucide-react";
import { photos } from "@/data/photos";
import { staggerContainer, slideUp } from "@/animations/variants";

const totalViews = photos.reduce((s, p) => s + p.views, 0);
const totalLikes = photos.reduce((s, p) => s + p.likes, 0);

const stats = [
  { label: "Total Photos", value: photos.length, icon: Camera, color: "text-gold" },
  { label: "Total Views", value: totalViews.toLocaleString(), icon: Eye, color: "text-gold" },
  { label: "Total Likes", value: totalLikes.toLocaleString(), icon: Heart, color: "text-gold" },
  { label: "Avg Views", value: Math.round(totalViews / photos.length).toLocaleString(), icon: TrendingUp, color: "text-gold" },
];

const AdminDashboard = () => {
  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="visible">
      <motion.h2 variants={slideUp} className="font-display text-2xl font-bold text-foreground mb-6">
        Overview
      </motion.h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((s) => (
          <motion.div
            key={s.label}
            variants={slideUp}
            className="glass-panel rounded-sm p-6"
            whileHover={{ scale: 1.03, transition: { duration: 0.2 } }}
          >
            <s.icon size={24} className={s.color + " mb-3"} />
            <p className="text-gradient-gold font-display text-3xl font-bold">{s.value}</p>
            <p className="text-muted-foreground text-xs font-body tracking-[0.15em] uppercase mt-1">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <motion.div variants={slideUp} className="glass-panel rounded-sm p-6">
        <h3 className="font-display text-lg font-semibold text-foreground mb-4">Recent Photos</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {photos.slice(0, 4).map((p) => (
            <div key={p.id} className="relative overflow-hidden rounded-sm aspect-square">
              <img src={p.url} alt={p.title} className="w-full h-full object-cover" />
              <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-background/80 to-transparent">
                <p className="text-foreground text-xs font-body truncate">{p.title}</p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default AdminDashboard;
