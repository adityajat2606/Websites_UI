import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Trash2, Edit, X, Tag } from "lucide-react";
import { photos as initialPhotos, Photo, categories } from "@/data/photos";
import { toast } from "sonner";
import { staggerContainer, slideUp, modalOverlay, modalContent } from "@/animations/variants";

const AdminManage = () => {
  const [photoList, setPhotoList] = useState<Photo[]>(initialPhotos);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editPhoto, setEditPhoto] = useState<Photo | null>(null);

  const handleDelete = (id: string) => {
    setPhotoList((prev) => prev.filter((p) => p.id !== id));
    setDeleteId(null);
    toast.success("Photo deleted");
  };

  const handleEditSave = () => {
    if (!editPhoto) return;
    setPhotoList((prev) => prev.map((p) => (p.id === editPhoto.id ? editPhoto : p)));
    setEditPhoto(null);
    toast.success("Photo updated");
  };

  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="visible">
      <motion.h2 variants={slideUp} className="font-display text-2xl font-bold text-foreground mb-6">
        Manage Photos
      </motion.h2>

      <motion.div variants={slideUp} className="glass-panel rounded-sm overflow-hidden">
        <table className="w-full text-sm font-body">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground text-xs tracking-wider uppercase">
              <th className="p-4">Photo</th>
              <th className="p-4 hidden sm:table-cell">Title</th>
              <th className="p-4 hidden md:table-cell">Category</th>
              <th className="p-4 hidden md:table-cell">Tags</th>
              <th className="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {photoList.map((photo) => (
              <motion.tr
                key={photo.id}
                className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors"
                layout
              >
                <td className="p-4">
                  <img src={photo.url} alt={photo.title} className="w-12 h-12 rounded-sm object-cover" />
                </td>
                <td className="p-4 hidden sm:table-cell text-foreground">{photo.title}</td>
                <td className="p-4 hidden md:table-cell">
                  <span className="px-2 py-1 text-xs rounded-sm bg-secondary text-secondary-foreground">{photo.category}</span>
                </td>
                <td className="p-4 hidden md:table-cell">
                  <div className="flex gap-1 flex-wrap">
                    {photo.tags.slice(0, 3).map((t) => (
                      <span key={t} className="px-2 py-0.5 text-xs rounded-sm bg-card text-muted-foreground">{t}</span>
                    ))}
                  </div>
                </td>
                <td className="p-4 text-right">
                  <div className="flex gap-2 justify-end">
                    <motion.button
                      whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                      onClick={() => setEditPhoto(photo)}
                      className="p-2 rounded-sm hover:bg-secondary text-muted-foreground hover:text-gold transition-colors"
                    >
                      <Edit size={16} />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                      onClick={() => setDeleteId(photo.id)}
                      className="p-2 rounded-sm hover:bg-secondary text-muted-foreground hover:text-destructive transition-colors"
                    >
                      <Trash2 size={16} />
                    </motion.button>
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </motion.div>

      {/* Delete confirmation modal */}
      <AnimatePresence>
        {deleteId && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm"
            variants={modalOverlay}
            initial="hidden" animate="visible" exit="exit"
            onClick={() => setDeleteId(null)}
          >
            <motion.div
              className="glass-panel rounded-sm p-8 max-w-sm w-full mx-4"
              variants={modalContent}
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="font-display text-xl font-semibold text-foreground mb-4">Delete Photo?</h3>
              <p className="text-muted-foreground text-sm font-body mb-6">
                This action cannot be undone. The photo will be permanently removed.
              </p>
              <div className="flex gap-3 justify-end">
                <motion.button
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={() => setDeleteId(null)}
                  className="px-5 py-2 text-sm font-body rounded-sm glass-panel text-foreground"
                >
                  Cancel
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={() => handleDelete(deleteId)}
                  className="px-5 py-2 text-sm font-body rounded-sm bg-destructive text-destructive-foreground"
                >
                  Delete
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit modal */}
      <AnimatePresence>
        {editPhoto && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm"
            variants={modalOverlay}
            initial="hidden" animate="visible" exit="exit"
            onClick={() => setEditPhoto(null)}
          >
            <motion.div
              className="glass-panel rounded-sm p-8 max-w-lg w-full mx-4"
              variants={modalContent}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-display text-xl font-semibold text-foreground">Edit Photo</h3>
                <button onClick={() => setEditPhoto(null)} className="text-muted-foreground hover:text-foreground">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-4">
                <input
                  type="text" value={editPhoto.title}
                  onChange={(e) => setEditPhoto({ ...editPhoto, title: e.target.value })}
                  className="w-full bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm focus:outline-none focus:border-gold transition-colors"
                  placeholder="Title"
                />
                <textarea
                  value={editPhoto.description}
                  onChange={(e) => setEditPhoto({ ...editPhoto, description: e.target.value })}
                  className="w-full bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm focus:outline-none focus:border-gold transition-colors resize-none"
                  rows={3} placeholder="Description"
                />
                <select
                  value={editPhoto.category}
                  onChange={(e) => setEditPhoto({ ...editPhoto, category: e.target.value as any })}
                  className="w-full bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm focus:outline-none focus:border-gold transition-colors"
                >
                  {categories.filter((c) => c !== "All").map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <div>
                  <label className="text-muted-foreground text-xs font-body flex items-center gap-1 mb-2">
                    <Tag size={12} /> Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    value={editPhoto.tags.join(", ")}
                    onChange={(e) => setEditPhoto({ ...editPhoto, tags: e.target.value.split(",").map((t) => t.trim()).filter(Boolean) })}
                    className="w-full bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm focus:outline-none focus:border-gold transition-colors"
                  />
                </div>
              </div>

              <div className="flex gap-3 justify-end mt-6">
                <motion.button
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={() => setEditPhoto(null)}
                  className="px-5 py-2 text-sm font-body rounded-sm glass-panel text-foreground"
                >
                  Cancel
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={handleEditSave}
                  className="px-5 py-2 text-sm font-body rounded-sm bg-gradient-gold text-primary-foreground shadow-gold"
                >
                  Save Changes
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default AdminManage;
