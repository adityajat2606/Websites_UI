import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { photos } from "@/data/photos";
import { staggerContainer, slideUp } from "@/animations/variants";

const viewsData = photos.map((p) => ({ name: p.title.slice(0, 12), views: p.views, likes: p.likes }));

const categoryData = photos.reduce((acc, p) => {
  const existing = acc.find((a) => a.name === p.category);
  if (existing) existing.value++;
  else acc.push({ name: p.category, value: 1 });
  return acc;
}, [] as { name: string; value: number }[]);

const COLORS = ["#C9A227", "#A07D1C", "#D4AF37", "#8B6914", "#E5C158", "#6B5310"];

const AdminAnalytics = () => {
  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="visible">
      <motion.h2 variants={slideUp} className="font-display text-2xl font-bold text-foreground mb-6">
        Analytics
      </motion.h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Views Chart */}
        <motion.div variants={slideUp} className="glass-panel rounded-sm p-6">
          <h3 className="font-display text-lg font-semibold text-foreground mb-6">Views & Likes by Photo</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={viewsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 20%)" />
                <XAxis dataKey="name" tick={{ fill: "hsl(0 0% 60%)", fontSize: 11 }} />
                <YAxis tick={{ fill: "hsl(0 0% 60%)", fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(0 0% 10%)",
                    border: "1px solid hsl(0 0% 20%)",
                    borderRadius: "4px",
                    color: "hsl(0 0% 97%)",
                    fontFamily: "Inter",
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="views" fill="#C9A227" radius={[4, 4, 0, 0]} />
                <Bar dataKey="likes" fill="#A07D1C" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Category Pie */}
        <motion.div variants={slideUp} className="glass-panel rounded-sm p-6">
          <h3 className="font-display text-lg font-semibold text-foreground mb-6">Photos by Category</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  dataKey="value"
                  label={({ name, value }) => `${name} (${value})`}
                  labelLine={{ stroke: "hsl(0 0% 40%)" }}
                >
                  {categoryData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(0 0% 10%)",
                    border: "1px solid hsl(0 0% 20%)",
                    borderRadius: "4px",
                    color: "hsl(0 0% 97%)",
                    fontFamily: "Inter",
                    fontSize: 12,
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Top photos table */}
        <motion.div variants={slideUp} className="glass-panel rounded-sm p-6 lg:col-span-2">
          <h3 className="font-display text-lg font-semibold text-foreground mb-4">Top Performing Photos</h3>
          <table className="w-full text-sm font-body">
            <thead>
              <tr className="border-b border-border text-left text-muted-foreground text-xs tracking-wider uppercase">
                <th className="pb-3">Photo</th>
                <th className="pb-3">Title</th>
                <th className="pb-3 text-right">Views</th>
                <th className="pb-3 text-right">Likes</th>
                <th className="pb-3 text-right">Engagement</th>
              </tr>
            </thead>
            <tbody>
              {[...photos].sort((a, b) => b.views - a.views).slice(0, 5).map((p) => (
                <tr key={p.id} className="border-b border-border last:border-0">
                  <td className="py-3">
                    <img src={p.url} alt={p.title} className="w-10 h-10 rounded-sm object-cover" />
                  </td>
                  <td className="py-3 text-foreground">{p.title}</td>
                  <td className="py-3 text-right text-muted-foreground">{p.views.toLocaleString()}</td>
                  <td className="py-3 text-right text-muted-foreground">{p.likes.toLocaleString()}</td>
                  <td className="py-3 text-right text-gold">{((p.likes / p.views) * 100).toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default AdminAnalytics;
