import gallery1 from "@/assets/gallery-1.jpg";
import gallery2 from "@/assets/gallery-2.jpg";
import gallery3 from "@/assets/gallery-3.jpg";
import gallery4 from "@/assets/gallery-4.jpg";
import gallery5 from "@/assets/gallery-5.jpg";
import gallery6 from "@/assets/gallery-6.jpg";
import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import hero3 from "@/assets/hero-3.jpg";

export type Category = "All" | "Nature" | "Portrait" | "Wedding" | "Travel" | "Street";

export interface Photo {
  id: string;
  title: string;
  description: string;
  url: string;
  width: number;
  height: number;
  category: Category;
  tags: string[];
  likes: number;
  views: number;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  favorites: string[];
}

export interface Analytics {
  photoId: string;
  views: number;
  likes: number;
}

export const heroImages = [hero1, hero2, hero3];

export const photos: Photo[] = [
  {
    id: "1",
    title: "Morning Dew",
    description: "Golden light catches morning dewdrops on delicate petals",
    url: gallery1,
    width: 1024,
    height: 1024,
    category: "Nature",
    tags: ["macro", "flower", "morning", "dew"],
    likes: 342,
    views: 1520,
    createdAt: "2024-12-01",
  },
  {
    id: "2",
    title: "Tokyo Nights",
    description: "Neon reflections on rain-soaked streets of Shinjuku",
    url: gallery2,
    width: 1024,
    height: 1024,
    category: "Street",
    tags: ["urban", "night", "neon", "rain", "tokyo"],
    likes: 891,
    views: 3200,
    createdAt: "2024-11-15",
  },
  {
    id: "3",
    title: "Eternal Vow",
    description: "Silhouettes at golden hour on a pristine beach",
    url: gallery3,
    width: 1920,
    height: 1080,
    category: "Wedding",
    tags: ["couple", "sunset", "beach", "romantic"],
    likes: 1203,
    views: 4800,
    createdAt: "2024-10-20",
  },
  {
    id: "4",
    title: "Lost Temple",
    description: "Ancient ruins bathed in dramatic golden sunset",
    url: gallery4,
    width: 1024,
    height: 1024,
    category: "Travel",
    tags: ["temple", "ruins", "sunset", "adventure"],
    likes: 567,
    views: 2100,
    createdAt: "2024-09-10",
  },
  {
    id: "5",
    title: "Wisdom",
    description: "A lifetime of stories told through expressive eyes",
    url: gallery5,
    width: 1024,
    height: 1024,
    category: "Portrait",
    tags: ["elderly", "character", "black-and-white", "dramatic"],
    likes: 723,
    views: 2900,
    createdAt: "2024-08-05",
  },
  {
    id: "6",
    title: "Solitude",
    description: "A lone tree standing against vast desert dunes",
    url: gallery6,
    width: 1920,
    height: 1080,
    category: "Nature",
    tags: ["desert", "minimalist", "tree", "sunset"],
    likes: 456,
    views: 1800,
    createdAt: "2024-07-22",
  },
  {
    id: "7",
    title: "Misty Peaks",
    description: "Layers of mountains disappearing into morning mist",
    url: hero1,
    width: 1920,
    height: 1080,
    category: "Nature",
    tags: ["mountains", "mist", "landscape", "dawn"],
    likes: 934,
    views: 3500,
    createdAt: "2024-06-18",
  },
  {
    id: "8",
    title: "Golden Portrait",
    description: "Editorial portrait with warm golden studio lighting",
    url: hero2,
    width: 1920,
    height: 1080,
    category: "Portrait",
    tags: ["fashion", "editorial", "golden", "studio"],
    likes: 1456,
    views: 5200,
    createdAt: "2024-05-30",
  },
];

export const categories: Category[] = ["All", "Nature", "Portrait", "Wedding", "Travel", "Street"];

export const mockUser: User = {
  id: "admin-1",
  name: "Alexander Voss",
  email: "alex@luxephotography.com",
  avatar: "",
  favorites: ["1", "3", "8"],
};
