import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { heroImages } from "@/data/photos";
import { heroText, staggerContainer, blurReveal } from "@/animations/variants";
import ParticleBackground from "./ParticleBackground";

const headlines = [
  { line1: "Capturing", line2: "Moments" },
  { line1: "Through", line2: "The Lens" },
  { line1: "Visual", line2: "Poetry" },
];

const HeroSection = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative h-screen w-full overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          className="absolute inset-0"
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        >
          <img
            src={heroImages[current]}
            alt="Hero"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-background/60" />
        </motion.div>
      </AnimatePresence>

      <ParticleBackground />

      <div className="relative z-10 flex h-full items-center justify-center px-6">
        <div className="text-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              className="mb-8"
              initial="hidden"
              animate="visible"
              exit="exit"
              variants={{
                hidden: {},
                visible: { transition: { staggerChildren: 0.15 } },
                exit: { transition: { staggerChildren: 0.05 } },
              }}
            >
              <motion.h1
                className="font-display text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold leading-[0.9] text-foreground"
                variants={heroText}
              >
                {headlines[current].line1}
              </motion.h1>
              <motion.h1
                className="font-display text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold leading-[0.9] text-gradient-gold italic"
                variants={heroText}
              >
                {headlines[current].line2}
              </motion.h1>
            </motion.div>
          </AnimatePresence>

          <motion.p
            className="mb-10 text-muted-foreground font-body text-lg md:text-xl max-w-md mx-auto tracking-wide"
            variants={blurReveal}
            initial="hidden"
            animate="visible"
          >
            Premium photography that tells extraordinary stories
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.3, duration: 0.6 }}
          >
            <Link
              to="/gallery"
              className="bg-gradient-gold px-8 py-4 text-sm font-body font-semibold tracking-[0.2em] uppercase text-primary-foreground rounded-sm shadow-gold hover:scale-105 transition-transform duration-300"
            >
              View Gallery
            </Link>
            <a
              href="#contact"
              className="glass-panel px-8 py-4 text-sm font-body font-semibold tracking-[0.2em] uppercase text-foreground rounded-sm hover:scale-105 transition-transform duration-300"
            >
              Get In Touch
            </a>
          </motion.div>
        </div>
      </div>

      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
      >
        <div className="w-6 h-10 border-2 border-gold/40 rounded-full flex justify-center pt-2">
          <motion.div
            className="w-1 h-2 bg-gold rounded-full"
            animate={{ y: [0, 12, 0], opacity: [1, 0.3, 1] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          />
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;
