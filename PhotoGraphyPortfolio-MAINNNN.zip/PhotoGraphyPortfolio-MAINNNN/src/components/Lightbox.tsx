import { useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Heart, Share2, Download, Maximize2 } from "lucide-react";
import { Photo } from "@/data/photos";
import { modalOverlay, modalContent } from "@/animations/variants";
import { useAuth } from "@/hooks/useAuth";

interface LightboxProps {
  photos: Photo[];
  currentIndex: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
}

const Lightbox = ({ photos, currentIndex, onClose, onNavigate }: LightboxProps) => {
  const isOpen = currentIndex !== null;
  const photo = isOpen ? photos[currentIndex] : null;
  const { isAuthenticated, user, toggleFavorite } = useAuth();
  const isFav = photo && user ? user.favorites.includes(photo.id) : false;

  const goNext = useCallback(() => {
    if (currentIndex !== null) onNavigate((currentIndex + 1) % photos.length);
  }, [currentIndex, photos.length, onNavigate]);

  const goPrev = useCallback(() => {
    if (currentIndex !== null) onNavigate((currentIndex - 1 + photos.length) % photos.length);
  }, [currentIndex, photos.length, onNavigate]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") goNext();
      if (e.key === "ArrowLeft") goPrev();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, goNext, goPrev, onClose]);

  useEffect(() => {
    if (isOpen) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && photo && (
        <motion.div
          className="fixed inset-0 z-[80] grid place-items-center bg-background/95 backdrop-blur-xl p-4 overflow-y-auto"
          variants={modalOverlay}
          initial="hidden"
          animate="visible"
          exit="exit"
          onClick={onClose}
        >
          <button onClick={onClose} className="absolute top-6 right-6 z-10 text-muted-foreground hover:text-foreground transition-colors">
            <X size={28} />
          </button>

          <button onClick={(e) => { e.stopPropagation(); goPrev(); }} className="absolute left-4 md:left-8 z-10 glass-panel p-3 rounded-full text-foreground hover:text-gold transition-colors">
            <ChevronLeft size={24} />
          </button>

          <button onClick={(e) => { e.stopPropagation(); goNext(); }} className="absolute right-4 md:right-8 z-10 glass-panel p-3 rounded-full text-foreground hover:text-gold transition-colors">
            <ChevronRight size={24} />
          </button>

          <motion.div
            className="relative w-full max-w-5xl max-h-[80vh]"
            onClick={(e) => e.stopPropagation()}
            variants={modalContent}
            initial="hidden"
            animate="visible"
            exit="exit"
            key={photo.id}
          >
            <img
              src={photo.url}
              alt={photo.title}
              className="max-h-[70vh] w-auto mx-auto rounded-sm shadow-premium object-contain"
            />
            <div className="mt-4 flex items-center justify-between px-2">
              <div>
                <h3 className="font-display text-xl font-semibold text-foreground">{photo.title}</h3>
                <p className="text-muted-foreground text-sm font-body">{photo.description}</p>
              </div>
              <div className="flex items-center gap-3">
                {isAuthenticated && (
                  <button
                    onClick={() => toggleFavorite(photo.id)}
                    className={`glass-panel p-2 rounded-full hover:text-gold transition-colors ${isFav ? "text-gold" : ""}`}
                  >
                    <Heart size={18} fill={isFav ? "currentColor" : "none"} />
                  </button>
                )}
                {[Share2, Download, Maximize2].map((Icon, i) => (
                  <button key={i} className="glass-panel p-2 rounded-full hover:text-gold transition-colors">
                    <Icon size={18} />
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Lightbox;
