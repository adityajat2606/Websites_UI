import { motion } from "framer-motion";
import photographerImg from "@/assets/photographer.jpg";
import { slideInLeft, slideInRight } from "@/animations/variants";

const FeaturedSection = () => {
  return (
    <section id="about" className="py-24 px-6">
      <div className="container mx-auto grid md:grid-cols-2 gap-16 items-center">
        <motion.div
          className="relative"
          variants={slideInLeft}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <div className="relative overflow-hidden rounded-sm">
            <img src={photographerImg} alt="Featured Photographer" className="w-full h-[500px] object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
          </div>
          <div className="absolute -top-4 -left-4 w-24 h-24 border-t-2 border-l-2 border-gold/40" />
          <div className="absolute -bottom-4 -right-4 w-24 h-24 border-b-2 border-r-2 border-gold/40" />
        </motion.div>

        <motion.div
          variants={slideInRight}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <span className="text-gold font-body text-xs tracking-[0.3em] uppercase mb-4 block">Featured Photographer</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
            Alexander <span className="text-gradient-gold italic">Voss</span>
          </h2>
          <div className="line-gold w-16 mb-6" />
          <p className="text-muted-foreground font-body leading-relaxed mb-6">
            With over 15 years of experience capturing life's most extraordinary moments,
            Alexander Voss brings a unique perspective to every frame. His work has been
            featured in National Geographic, Vogue, and numerous international exhibitions.
          </p>
          <p className="text-muted-foreground font-body leading-relaxed mb-8">
            "Photography is not about the camera — it's about the connection between
            light, emotion, and the fleeting beauty of the present moment."
          </p>
          <div className="flex gap-8">
            {[
              { value: "15+", label: "Years" },
              { value: "2.4K", label: "Photos" },
              { value: "50+", label: "Awards" },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-gradient-gold font-display text-3xl font-bold">{stat.value}</div>
                <div className="text-muted-foreground text-xs font-body tracking-[0.2em] uppercase mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturedSection;
