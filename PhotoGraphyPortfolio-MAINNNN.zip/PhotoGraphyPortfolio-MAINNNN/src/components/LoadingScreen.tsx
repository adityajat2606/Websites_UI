import { AnimatePresence, motion } from "framer-motion";
import { blurReveal } from "@/animations/variants";

interface LoadingScreenProps {
  isLoading: boolean;
}

const LoadingScreen = ({ isLoading }: LoadingScreenProps) => {
  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-background"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        >
          <div className="flex flex-col items-center gap-8">
            <motion.div
              className="text-gradient-gold font-display text-5xl md:text-7xl font-bold tracking-wider"
              variants={blurReveal}
              initial="hidden"
              animate="visible"
            >
              LUXE
            </motion.div>
            <motion.div
              className="line-gold w-32"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 1.2, delay: 0.3, ease: "easeInOut" }}
            />
            <motion.p
              className="text-muted-foreground font-body text-sm tracking-[0.3em] uppercase"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              Photography Portfolio
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LoadingScreen;
