import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { staggerContainer, slideUp } from "@/animations/variants";

const testimonials = [
  {
    name: "Sarah Mitchell",
    role: "Bride",
    text: "Alexander captured our wedding with such artistry. Every photo tells a story and brings tears of joy. Absolutely world-class.",
    rating: 5,
  },
  {
    name: "James Chen",
    role: "Art Director",
    text: "The most visually stunning portfolio I've ever had the pleasure of working with. His eye for composition is unmatched in the industry.",
    rating: 5,
  },
  {
    name: "Elena Rossi",
    role: "Travel Blogger",
    text: "These travel photographs transport you to another world. The colors, the light, the emotion — pure visual magic in every frame.",
    rating: 5,
  },
];

const TestimonialsSection = () => {
  return (
    <section className="py-24 px-6">
      <div className="container mx-auto">
        <motion.div
          className="text-center mb-16"
          variants={slideUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <span className="text-gold font-body text-xs tracking-[0.3em] uppercase">Testimonials</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mt-4">
            Client <span className="text-gradient-gold italic">Stories</span>
          </h2>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-3 gap-8"
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {testimonials.map((t) => (
            <motion.div
              key={t.name}
              className="glass-panel rounded-sm p-8 relative"
              variants={slideUp}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
            >
              <div className="absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
              <div className="flex gap-1 mb-4 mt-2">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} size={14} className="fill-gold text-gold" />
                ))}
              </div>
              <p className="text-foreground/80 font-body text-sm leading-relaxed mb-6 italic">"{t.text}"</p>
              <div>
                <p className="font-display text-lg font-semibold text-foreground">{t.name}</p>
                <p className="text-muted-foreground text-xs font-body tracking-[0.15em] uppercase">{t.role}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
