import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Camera, Heart, Eye, Award } from "lucide-react";
import { staggerContainer, slideUp } from "@/animations/variants";

const stats = [
  { icon: Camera, value: 2400, suffix: "+", label: "Photos Captured" },
  { icon: Heart, value: 18500, suffix: "+", label: "Total Likes" },
  { icon: Eye, value: 142000, suffix: "+", label: "Gallery Views" },
  { icon: Award, value: 53, suffix: "", label: "Awards Won" },
];

function AnimatedCounter({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView) return;
    let start = 0;
    const duration = 2000;
    const startTime = Date.now();
    const step = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      start = Math.floor(eased * target);
      setCount(start);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [isInView, target]);

  return (
    <div ref={ref} className="text-gradient-gold font-display text-4xl md:text-5xl font-bold">
      {count.toLocaleString()}{suffix}
    </div>
  );
}

const StatsSection = () => {
  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-card/50 to-background" />
      <div className="container mx-auto relative z-10">
        <motion.div
          className="text-center mb-16"
          variants={slideUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <span className="text-gold font-body text-xs tracking-[0.3em] uppercase">By The Numbers</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mt-4">
            Our <span className="text-gradient-gold italic">Impact</span>
          </h2>
        </motion.div>

        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-8"
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {stats.map((stat) => (
            <motion.div
              key={stat.label}
              className="glass-panel rounded-sm p-8 text-center"
              variants={slideUp}
              whileHover={{ scale: 1.05, transition: { duration: 0.2 } }}
            >
              <stat.icon className="mx-auto mb-4 text-gold" size={28} />
              <AnimatedCounter target={stat.value} suffix={stat.suffix} />
              <p className="text-muted-foreground text-xs font-body tracking-[0.15em] uppercase mt-3">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default StatsSection;
