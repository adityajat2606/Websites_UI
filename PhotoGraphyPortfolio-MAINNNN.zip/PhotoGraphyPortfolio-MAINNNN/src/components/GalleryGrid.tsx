import { useState, useMemo, useCallback, useRef } from "react";
import { motion } from "framer-motion";
import { Heart, Eye } from "lucide-react";
import { Photo, Category, categories } from "@/data/photos";
import { staggerContainer, slideUp } from "@/animations/variants";
import { useAuth } from "@/hooks/useAuth";
import Lightbox from "./Lightbox";

interface GalleryGridProps {
  photos: Photo[];
  showFilters?: boolean;
}

// Seeded shuffle for consistent but random-looking layout
function seededShuffle<T>(arr: T[], seed: number): T[] {
  const result = [...arr];
  let s = seed;
  for (let i = result.length - 1; i > 0; i--) {
    s = (s * 16807 + 0) % 2147483647;
    const j = s % (i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

const GalleryGrid = ({ photos, showFilters = true }: GalleryGridProps) => {
  const { isAuthenticated, user, toggleFavorite } = useAuth();
  const [activeCategory, setActiveCategory] = useState<Category>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [visibleCount, setVisibleCount] = useState(8);
  const observerRef = useRef<HTMLDivElement>(null);

  const filtered = useMemo(() => {
    const base = photos.filter((p) => {
      const catMatch = activeCategory === "All" || p.category === activeCategory;
      const searchMatch =
        !searchQuery ||
        p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
        p.title.toLowerCase().includes(searchQuery.toLowerCase());
      return catMatch && searchMatch;
    });
    return seededShuffle(base, 42);
  }, [photos, activeCategory, searchQuery]);

  const visible = filtered.slice(0, visibleCount);

  // Infinite scroll observer
  const lastCardRef = useCallback(
    (node: HTMLDivElement | null) => {
      if (!node) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting && visibleCount < filtered.length) {
            setVisibleCount((c) => Math.min(c + 4, filtered.length));
          }
        },
        { rootMargin: "200px" }
      );
      obs.observe(node);
      return () => obs.disconnect();
    },
    [visibleCount, filtered.length]
  );

  // Dynamic masonry span based on orientation + alternation to avoid clustering
  const getSpan = (photo: Photo, index: number): string => {
    const isLandscape = photo.width > photo.height;
    const isPortrait = photo.height > photo.width;

    // Every 5th is large hero card
    if (index % 5 === 0) return "md:col-span-2 md:row-span-2";
    if (isLandscape) return "md:col-span-2";
    if (isPortrait) return "md:row-span-2";
    return "";
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    e.currentTarget.style.transform = `perspective(800px) rotateY(${x * 5}deg) rotateX(${-y * 5}deg) scale(1.02)`;
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    e.currentTarget.style.transform = "perspective(800px) rotateY(0deg) rotateX(0deg) scale(1)";
  };

  return (
    <section className="py-20 px-6">
      {showFilters && (
        <motion.div
          className="container mx-auto mb-12"
          variants={slideUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <div className="mb-8 flex justify-center">
            <input
              type="text"
              placeholder="Search by tag or title..."
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setVisibleCount(8); }}
              className="w-full max-w-md bg-card border border-border rounded-sm px-6 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
            />
          </div>

          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((cat) => (
              <motion.button
                key={cat}
                onClick={() => { setActiveCategory(cat); setVisibleCount(8); }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-5 py-2 text-xs font-body tracking-[0.2em] uppercase rounded-sm transition-all duration-300 ${
                  activeCategory === cat
                    ? "bg-gradient-gold text-primary-foreground shadow-gold"
                    : "glass-panel text-muted-foreground hover:text-foreground"
                }`}
              >
                {cat}
              </motion.button>
            ))}
          </div>
        </motion.div>
      )}

      {/* Masonry grid with auto-flow dense */}
      <motion.div
        className="container mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 auto-rows-[250px]"
        style={{ gridAutoFlow: "dense" }}
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-50px" }}
      >
        {visible.map((photo, index) => (
          <motion.div
            key={photo.id}
            ref={index === visible.length - 1 ? lastCardRef : undefined}
            className={`relative group cursor-pointer overflow-hidden rounded-sm ${getSpan(photo, index)}`}
            variants={slideUp}
            style={{ transition: "transform 0.3s ease" }}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            onClick={() => setLightboxIndex(index)}
          >
            <img
              src={photo.url}
              alt={photo.title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            {/* Zoom overlay */}
            <div className="absolute inset-0 bg-background/0 group-hover:bg-background/60 transition-all duration-500 flex items-end p-4">
              <div className="w-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 translate-y-4 group-hover:translate-y-0">
                <h3 className="font-display text-lg font-semibold text-foreground mb-1">
                  {photo.title}
                </h3>
                <p className="text-muted-foreground text-xs font-body mb-2 line-clamp-1">
                  {photo.description}
                </p>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Heart size={12} className="text-gold" /> {photo.likes}
                  </span>
                  <span className="flex items-center gap-1">
                    <Eye size={12} /> {photo.views}
                  </span>
                </div>
              </div>
            </div>
            {/* Favorite button */}
            {isAuthenticated && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavorite(photo.id);
                }}
                className="absolute top-3 right-3 glass-panel p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:scale-110 z-10"
              >
                <Heart
                  size={16}
                  className={user?.favorites.includes(photo.id) ? "text-gold fill-gold" : "text-foreground"}
                />
              </button>
            )}
          </motion.div>
        ))}
      </motion.div>

      {visibleCount < filtered.length && (
        <div ref={observerRef} className="flex justify-center mt-12">
          <div className="w-8 h-8 border-2 border-gold/40 border-t-gold rounded-full animate-spin" />
        </div>
      )}

      <Lightbox
        photos={visible}
        currentIndex={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onNavigate={setLightboxIndex}
      />
    </section>
  );
};

export default GalleryGrid;
