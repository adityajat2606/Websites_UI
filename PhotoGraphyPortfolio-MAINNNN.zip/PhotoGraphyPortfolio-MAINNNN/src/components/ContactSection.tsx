import { useState } from "react";
import { motion } from "framer-motion";
import { Send, Mail, MapPin, Phone } from "lucide-react";
import { toast } from "sonner";
import { slideInLeft, slideInRight } from "@/animations/variants";

const ContactSection = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    toast.success("Message sent! We'll get back to you soon.");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <section id="contact" className="py-24 px-6 relative">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-gold font-body text-xs tracking-[0.3em] uppercase">Get In Touch</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mt-4">
            Let's <span className="text-gradient-gold italic">Connect</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            variants={slideInLeft}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="flex flex-col gap-8"
          >
            <p className="text-muted-foreground font-body leading-relaxed">
              Interested in booking a session or purchasing prints? I'd love to hear from you.
              Let's create something extraordinary together.
            </p>
            {[
              { icon: Mail, label: "hello@luxephotography.com" },
              { icon: Phone, label: "+1 (555) 123-4567" },
              { icon: MapPin, label: "New York, NY" },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-4">
                <div className="glass-panel p-3 rounded-sm">
                  <item.icon size={18} className="text-gold" />
                </div>
                <span className="text-foreground font-body text-sm">{item.label}</span>
              </div>
            ))}
          </motion.div>

          <motion.form
            onSubmit={handleSubmit}
            variants={slideInRight}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="glass-panel rounded-sm p-8 flex flex-col gap-5"
          >
            <input
              type="text"
              placeholder="Your Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
            />
            <input
              type="email"
              placeholder="Your Email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
            />
            <textarea
              placeholder="Your Message"
              rows={5}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="bg-card border border-border rounded-sm px-5 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors resize-none"
            />
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="bg-gradient-gold px-8 py-3 text-sm font-body font-semibold tracking-[0.2em] uppercase text-primary-foreground rounded-sm shadow-gold flex items-center justify-center gap-2"
            >
              <Send size={16} /> Send Message
            </motion.button>
          </motion.form>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
