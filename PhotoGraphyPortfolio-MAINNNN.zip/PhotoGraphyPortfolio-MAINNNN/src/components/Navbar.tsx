import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, LogIn, UserPlus, User, Heart, LogOut, LayoutDashboard } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { slideUp, staggerContainer } from "@/animations/variants";
import { useAuth } from "@/hooks/useAuth";

const navLinks = [
  { label: "Home", href: "/" },
  { label: "Gallery", href: "/gallery" },
  { label: "About", href: "/#about" },
  { label: "Contact", href: "/#contact" },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthenticated, user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    setProfileOpen(false);
    navigate("/");
  };

  const handleNavClick = (e: React.MouseEvent, href: string) => {
    if (href.includes("#")) {
      const hash = href.split("#")[1];
      if (location.pathname === "/") {
        e.preventDefault();
        document.getElementById(hash)?.scrollIntoView({ behavior: "smooth" });
      } else {
        // Navigate to home, then scroll after mount
        e.preventDefault();
        navigate("/");
        setTimeout(() => {
          document.getElementById(hash)?.scrollIntoView({ behavior: "smooth" });
        }, 300);
      }
    }
    setIsOpen(false);
  };

  return (
    <motion.nav
      className="fixed top-0 left-0 right-0 z-50 glass-panel"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <div className="container mx-auto flex items-center justify-between px-6 py-4">
        <Link to="/" className="text-gradient-gold font-display text-2xl font-bold tracking-widest">
          LUXE
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              to={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className={`text-sm font-body tracking-[0.15em] uppercase transition-colors duration-300 hover:text-gold ${
                location.pathname === link.href ? "text-gold" : "text-muted-foreground"
              }`}
            >
              {link.label}
            </Link>
          ))}

          <div className="flex items-center gap-3 ml-4 border-l border-border pl-6">
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setProfileOpen(!profileOpen)}
                  className="flex items-center gap-2 group"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-gold flex items-center justify-center shadow-gold group-hover:shadow-[0_0_20px_hsl(var(--gold)/0.3)] transition-shadow">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <User size={14} className="text-primary-foreground" />
                    )}
                  </div>
                  <span className="text-sm font-body text-foreground group-hover:text-gold transition-colors hidden lg:inline">
                    {user?.name?.split(" ")[0]}
                  </span>
                </button>

                <AnimatePresence>
                  {profileOpen && (
                    <motion.div
                      className="absolute right-0 top-12 w-56 glass-panel-strong rounded-sm overflow-hidden shadow-premium"
                      initial={{ opacity: 0, y: -8, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -8, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="p-4 border-b border-border">
                        <p className="font-body text-sm font-semibold text-foreground">{user?.name}</p>
                        <p className="font-body text-xs text-muted-foreground">{user?.email}</p>
                      </div>
                      <div className="p-2">
                        <Link
                          to="/profile"
                          onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm font-body text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors w-full"
                        >
                          <User size={15} /> My Profile
                        </Link>
                        <Link
                          to="/profile"
                          onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm font-body text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors w-full"
                        >
                          <Heart size={15} /> Favorites
                        </Link>
                        <Link
                          to="/admin"
                          onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm font-body text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors w-full"
                        >
                          <LayoutDashboard size={15} /> Dashboard
                        </Link>
                      </div>
                      <div className="p-2 border-t border-border">
                        <button
                          onClick={handleLogout}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm font-body text-muted-foreground hover:text-destructive transition-colors w-full"
                        >
                          <LogOut size={15} /> Sign Out
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <>
                <Link
                  to="/login"
                  className="flex items-center gap-2 text-sm font-body tracking-[0.1em] uppercase text-muted-foreground hover:text-gold transition-colors duration-300"
                >
                  <LogIn size={15} />
                  Sign In
                </Link>
                <Link
                  to="/login?signup=true"
                  className="flex items-center gap-2 bg-gradient-gold px-4 py-2 text-xs font-body font-semibold tracking-[0.15em] uppercase text-primary-foreground rounded-sm shadow-gold hover:opacity-90 transition-opacity"
                >
                  <UserPlus size={14} />
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>

        <button
          className="md:hidden text-foreground"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="md:hidden glass-panel-strong absolute top-full left-0 right-0"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex flex-col items-center gap-6 py-8"
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
            >
              {navLinks.map((link) => (
                <motion.div key={link.label} variants={slideUp}>
                  <Link
                    to={link.href}
                    onClick={(e) => handleNavClick(e, link.href)}
                    className="text-sm font-body tracking-[0.2em] uppercase text-foreground hover:text-gold transition-colors"
                  >
                    {link.label}
                  </Link>
                </motion.div>
              ))}
              <div className="flex flex-col items-center gap-4 mt-4 pt-4 border-t border-border w-full px-8">
                {isAuthenticated ? (
                  <>
                    <Link
                      to="/profile"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center gap-2 text-sm font-body tracking-[0.15em] uppercase text-foreground hover:text-gold transition-colors"
                    >
                      <User size={15} />
                      My Profile
                    </Link>
                    <button
                      onClick={() => { handleLogout(); setIsOpen(false); }}
                      className="flex items-center gap-2 text-sm font-body tracking-[0.15em] uppercase text-muted-foreground hover:text-destructive transition-colors"
                    >
                      <LogOut size={15} />
                      Sign Out
                    </button>
                  </>
                ) : (
                  <>
                    <Link
                      to="/login"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center gap-2 text-sm font-body tracking-[0.15em] uppercase text-muted-foreground hover:text-gold transition-colors"
                    >
                      <LogIn size={15} />
                      Sign In
                    </Link>
                    <Link
                      to="/login?signup=true"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center gap-2 bg-gradient-gold px-6 py-2.5 text-xs font-body font-semibold tracking-[0.15em] uppercase text-primary-foreground rounded-sm shadow-gold"
                    >
                      <UserPlus size={14} />
                      Sign Up
                    </Link>
                  </>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navbar;
