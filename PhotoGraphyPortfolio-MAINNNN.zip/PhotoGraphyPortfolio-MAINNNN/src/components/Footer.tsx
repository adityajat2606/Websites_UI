import { motion } from "framer-motion";
import { Instagram, Twitter, Youtube, Linkedin } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";

const Footer = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const handleFooterLink = (e: React.MouseEvent, href: string) => {
    if (!href.includes("#")) return;
    const hash = href.split("#")[1];
    if (location.pathname === "/") {
      e.preventDefault();
      document.getElementById(hash)?.scrollIntoView({ behavior: "smooth" });
    } else {
      e.preventDefault();
      navigate("/");
      setTimeout(() => {
        document.getElementById(hash)?.scrollIntoView({ behavior: "smooth" });
      }, 300);
    }
  };

  return (
    <footer className="py-16 px-6 border-t border-border">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          <div>
            <h3 className="text-gradient-gold font-display text-2xl font-bold tracking-widest mb-4">LUXE</h3>
            <p className="text-muted-foreground font-body text-sm leading-relaxed">
              Premium photography portfolio showcasing the art of visual storytelling.
            </p>
          </div>
          <div>
            <h4 className="text-foreground font-body text-xs tracking-[0.2em] uppercase font-semibold mb-4">Quick Links</h4>
            <div className="flex flex-col gap-2">
              <Link to="/gallery" className="text-muted-foreground font-body text-sm hover:text-gold transition-colors">
                Gallery
              </Link>
              <Link
                to="/#about"
                onClick={(e) => handleFooterLink(e, "/#about")}
                className="text-muted-foreground font-body text-sm hover:text-gold transition-colors"
              >
                About
              </Link>
              <Link
                to="/#contact"
                onClick={(e) => handleFooterLink(e, "/#contact")}
                className="text-muted-foreground font-body text-sm hover:text-gold transition-colors"
              >
                Contact
              </Link>
              <Link to="/blog" className="text-muted-foreground font-body text-sm hover:text-gold transition-colors">
                Blog
              </Link>
            </div>
          </div>
          <div>
            <h4 className="text-foreground font-body text-xs tracking-[0.2em] uppercase font-semibold mb-4">Newsletter</h4>
            <p className="text-muted-foreground font-body text-sm mb-4">Get updates on new collections and exhibitions.</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 bg-card border border-border rounded-sm px-4 py-2 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-gold transition-colors"
              />
              <button className="bg-gradient-gold px-4 py-2 rounded-sm text-primary-foreground text-xs font-body font-semibold tracking-wider uppercase">
                Join
              </button>
            </div>
          </div>
        </div>
        <div className="line-gold mb-8" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-muted-foreground font-body text-xs">© 2024 LUXE Photography. All rights reserved.</p>
          <div className="flex items-center gap-4">
            {[Instagram, Twitter, Youtube, Linkedin].map((Icon, i) => (
              <motion.a
                key={i}
                href="#"
                onClick={(e) => e.preventDefault()}
                className="text-muted-foreground hover:text-gold transition-colors"
                whileHover={{ scale: 1.2 }}
              >
                <Icon size={18} />
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
