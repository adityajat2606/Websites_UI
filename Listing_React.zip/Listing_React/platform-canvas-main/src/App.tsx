import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { TenantProvider } from "@/context/TenantContext";
import { AuthProvider } from "@/context/AuthContext";
import Index from "./pages/Index";
import PostDetail from "./pages/PostDetail";
import SearchResults from "./pages/SearchResults";
import CategoryPage from "./pages/CategoryPage";
import NotFound from "./pages/NotFound";
import AboutPage from "./pages/AboutPage";
import ContactPage from "./pages/ContactPage";
import InfoPage from "./pages/InfoPage";
import SignInPage from "./pages/SignInPage";
import GetStartedPage from "./pages/GetStartedPage";
import DashboardPage from "./pages/DashboardPage";
import ScrollToTop from "./components/ScrollToTop";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <TenantProvider>
        <AuthProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <ScrollToTop />
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/home" element={<Index />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/company" element={<InfoPage pageKey="company" />} />
              <Route path="/careers" element={<InfoPage pageKey="careers" />} />
              <Route path="/blog" element={<InfoPage pageKey="blog" />} />
              <Route path="/press" element={<InfoPage pageKey="press" />} />
              <Route path="/legal" element={<InfoPage pageKey="legal" />} />
              <Route path="/privacy" element={<InfoPage pageKey="privacy" />} />
              <Route path="/terms" element={<InfoPage pageKey="terms" />} />
              <Route path="/cookies" element={<InfoPage pageKey="cookies" />} />
              <Route path="/sign-in" element={<SignInPage />} />
              <Route path="/get-started" element={<GetStartedPage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/post/:id" element={<PostDetail />} />
              <Route path="/search" element={<SearchResults />} />
              <Route path="/category/:category" element={<CategoryPage />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </TenantProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
