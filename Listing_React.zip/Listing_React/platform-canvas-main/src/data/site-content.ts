export type InfoPageKey =
  | "company"
  | "careers"
  | "blog"
  | "press"
  | "legal"
  | "privacy"
  | "terms"
  | "cookies";

export interface InfoPageSection {
  heading: string;
  text: string;
}

export interface InfoPageContent {
  title: string;
  subtitle: string;
  sections: InfoPageSection[];
}

export const aboutPageContent = {
  title: "About Platform Canvas",
  subtitle:
    "We are a storytelling and discovery platform helping people find trusted local experiences, spaces, and ideas.",
  stats: [
    { label: "Monthly readers", value: "1.2M" },
    { label: "Partner cities", value: "48" },
    { label: "Editorial experts", value: "95" },
    { label: "Published guides", value: "3,400+" },
  ],
  values: [
    {
      title: "Quality Curation",
      description:
        "Every listing and editorial feature is reviewed by our local curation team for relevance, trust, and originality.",
    },
    {
      title: "Human Stories",
      description:
        "We prioritize real operators and creators, with profiles that show the people and context behind every recommendation.",
    },
    {
      title: "Transparent Standards",
      description:
        "Our review rubric, partner guidelines, and publishing ethics are publicly documented for users and contributors.",
    },
  ],
  leadership: [
    {
      name: "Maya Thompson",
      role: "Chief Executive Officer",
      bio: "Former product leader at a global travel marketplace. Maya focuses on trust systems and platform scale.",
    },
    {
      name: "Nikhil Rao",
      role: "VP, Editorial",
      bio: "Award-winning editor and reporter with 14 years covering design, food culture, and city development.",
    },
    {
      name: "Camila Estrada",
      role: "Head of Partnerships",
      bio: "Camila leads our regional partner network, supporting independent businesses and creative communities.",
    },
  ],
};

export const contactPageContent = {
  title: "Contact Our Team",
  subtitle:
    "Tell us what you need and we will route your request to the right team within one business day.",
  offices: [
    {
      city: "New York",
      address: "200 Hudson Street, 5th Floor, New York, NY 10013",
      phone: "+1 (212) 555-0148",
      email: "ny@platformcanvas.co",
    },
    {
      city: "Austin",
      address: "901 East 6th Street, Austin, TX 78702",
      phone: "+1 (512) 555-0136",
      email: "austin@platformcanvas.co",
    },
    {
      city: "London",
      address: "18 Curtain Road, Shoreditch, London EC2A 3NZ",
      phone: "+44 20 7946 0261",
      email: "london@platformcanvas.co",
    },
  ],
};

export const infoPagesContent: Record<InfoPageKey, InfoPageContent> = {
  company: {
    title: "Company",
    subtitle:
      "Platform Canvas combines technology, editorial standards, and local partnerships to help people discover better places and experiences.",
    sections: [
      {
        heading: "What We Build",
        text: "We publish trusted city guides, cultural editorials, and verified listings across food, travel, design, and local commerce.",
      },
      {
        heading: "How We Operate",
        text: "Our product, editorial, and partnerships teams work together with shared quality standards and quarterly audit cycles.",
      },
      {
        heading: "Where We Are Growing",
        text: "In 2026 we are expanding in North America and Europe through city-level partner programs and creator initiatives.",
      },
    ],
  },
  careers: {
    title: "Careers",
    subtitle:
      "Join a distributed team focused on quality content, thoughtful product design, and strong local communities.",
    sections: [
      {
        heading: "Open Roles",
        text: "We are hiring for senior frontend engineers, account managers, city editors, and lifecycle marketers.",
      },
      {
        heading: "Benefits",
        text: "Competitive compensation, flexible PTO, remote-friendly teams, annual learning stipends, and healthcare coverage.",
      },
      {
        heading: "Hiring Process",
        text: "Typical process: recruiter call, skills interview, collaborative case session, and final leadership conversation.",
      },
    ],
  },
  blog: {
    title: "Blog",
    subtitle:
      "Updates from product, editorial, and partnerships teams on how we build, publish, and scale responsibly.",
    sections: [
      {
        heading: "Latest Post",
        text: "How we improved listing verification accuracy by 37% using a new review and enrichment workflow.",
      },
      {
        heading: "Editorial Notes",
        text: "Our editors share what we learned from 400+ interviews with founders, chefs, artists, and local operators.",
      },
      {
        heading: "Product Journal",
        text: "Shipping notes on search relevance, contributor tooling, and performance upgrades in the web app.",
      },
    ],
  },
  press: {
    title: "Press",
    subtitle:
      "Media resources, announcements, and contacts for journalists and industry analysts.",
    sections: [
      {
        heading: "Recent News",
        text: "Platform Canvas announced three new metro launches and a new creator partnership program in Q1 2026.",
      },
      {
        heading: "Press Kit",
        text: "Brand assets, product screenshots, and executive bios are available on request for verified media outlets.",
      },
      {
        heading: "Media Contact",
        text: "For interview requests and statements, contact press@platformcanvas.co and include your deadline.",
      },
    ],
  },
  legal: {
    title: "Legal",
    subtitle:
      "Policies that govern how we protect users, operate our platform, and maintain transparency.",
    sections: [
      {
        heading: "Policy Framework",
        text: "Our legal framework includes privacy, terms of service, and cookie policies with regular compliance updates.",
      },
      {
        heading: "User Rights",
        text: "Users can request access, correction, export, or deletion of personal data through our privacy request workflow.",
      },
      {
        heading: "Business Standards",
        text: "Partners and contributors must comply with authenticity, safety, and advertising disclosure requirements.",
      },
    ],
  },
  privacy: {
    title: "Privacy",
    subtitle:
      "We collect only necessary data to deliver the product, personalize discovery, and maintain platform safety.",
    sections: [
      {
        heading: "Data We Collect",
        text: "Account details, usage events, and optional profile settings used to support recommendations and account security.",
      },
      {
        heading: "How We Use Data",
        text: "Data supports search relevance, fraud prevention, service quality analytics, and customer support operations.",
      },
      {
        heading: "Your Controls",
        text: "Users can update communication preferences, manage personalization settings, and submit deletion requests at any time.",
      },
    ],
  },
  terms: {
    title: "Terms",
    subtitle:
      "By using Platform Canvas, users agree to these service terms, community standards, and account obligations.",
    sections: [
      {
        heading: "Account Responsibility",
        text: "Users are responsible for safeguarding login credentials and maintaining accurate profile information.",
      },
      {
        heading: "Content Rules",
        text: "User submissions must be lawful, non-deceptive, and compliant with our moderation and quality standards.",
      },
      {
        heading: "Service Changes",
        text: "We may update features or terms over time, with material changes announced through in-app notices.",
      },
    ],
  },
  cookies: {
    title: "Cookies",
    subtitle:
      "Cookies help us deliver core functionality, improve performance, and understand aggregate user behavior.",
    sections: [
      {
        heading: "Essential Cookies",
        text: "Required for authentication, session management, and security controls across critical workflows.",
      },
      {
        heading: "Analytics Cookies",
        text: "Used to measure product performance and identify opportunities to improve search and navigation.",
      },
      {
        heading: "Preference Cookies",
        text: "Store language, UI preferences, and consent selections so your experience remains consistent.",
      },
    ],
  },
};
