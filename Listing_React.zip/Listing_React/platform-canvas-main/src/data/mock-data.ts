import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import hero3 from "@/assets/hero-3.jpg";
import card1 from "@/assets/card-1.jpg";
import card2 from "@/assets/card-2.jpg";
import card3 from "@/assets/card-3.jpg";
import card4 from "@/assets/card-4.jpg";
import card5 from "@/assets/card-5.jpg";
import card6 from "@/assets/card-6.jpg";

export type PostType = "article" | "gallery" | "listing";

export interface Post {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  type: PostType;
  author: { name: string; avatar: string };
  date: string;
  readTime?: string;
  price?: string;
  location?: string;
  tags: string[];
}

const avatarUrl = (seed: string) =>
  `https://api.dicebear.com/9.x/notionists/svg?seed=${seed}`;

export const featuredPosts: Post[] = [
  {
    id: "f1",
    title: "The Art of Slow Living in a Fast World",
    excerpt: "Rediscovering what matters most through intentional daily rituals and mindful living.",
    image: hero1,
    type: "article",
    author: { name: "Elena Marsh", avatar: avatarUrl("elena") },
    date: "Mar 5, 2026",
    readTime: "8 min read",
    tags: ["Lifestyle", "Wellness"],
  },
  {
    id: "f2",
    title: "Inside the Studio: Modern Minimalist Spaces",
    excerpt: "A curated gallery of the most inspiring interior designs from around the world.",
    image: hero2,
    type: "gallery",
    author: { name: "James Cole", avatar: avatarUrl("james") },
    date: "Mar 3, 2026",
    tags: ["Design", "Architecture"],
  },
  {
    id: "f3",
    title: "Hidden Gems of the Mediterranean Coast",
    excerpt: "Explore the most breathtaking coastal towns you've never heard of.",
    image: hero3,
    type: "listing",
    author: { name: "Sofia Reyes", avatar: avatarUrl("sofia") },
    date: "Mar 1, 2026",
    price: "From $89/night",
    location: "Amalfi Coast, Italy",
    tags: ["Travel", "Hidden Gems"],
  },
];

export const latestListings: Post[] = [
  {
    id: "l1",
    title: "Artisan Sourdough & Provisions",
    excerpt: "Farm-to-table bakery offering handcrafted breads, pastries, and seasonal provisions.",
    image: card1,
    type: "listing",
    author: { name: "Mia Chen", avatar: avatarUrl("mia") },
    date: "Mar 6, 2026",
    price: "$12–$45",
    location: "Brooklyn, NY",
    tags: ["Food", "Artisan"],
  },
  {
    id: "l2",
    title: "Nordic Loft – Designer Apartment",
    excerpt: "Sunlit Scandinavian retreat in the heart of the city. Monthly and weekly stays.",
    image: card2,
    type: "listing",
    author: { name: "Lukas Berg", avatar: avatarUrl("lukas") },
    date: "Mar 5, 2026",
    price: "$185/night",
    location: "Copenhagen, DK",
    tags: ["Stays", "Design"],
  },
  {
    id: "l3",
    title: "Alpine Trails: Guided Hiking Tours",
    excerpt: "Multi-day guided treks through the most scenic alpine routes with expert naturalists.",
    image: card3,
    type: "listing",
    author: { name: "Anna Müller", avatar: avatarUrl("anna") },
    date: "Mar 4, 2026",
    price: "From $320",
    location: "Swiss Alps",
    tags: ["Adventure", "Nature"],
  },
  {
    id: "l4",
    title: "The Reading Room – Vintage Books",
    excerpt: "Curated collection of rare first editions and beautiful vintage finds.",
    image: card4,
    type: "listing",
    author: { name: "Thomas Wells", avatar: avatarUrl("thomas") },
    date: "Mar 3, 2026",
    price: "$8–$400",
    location: "Portland, OR",
    tags: ["Books", "Vintage"],
  },
];

export const trendingPosts: Post[] = [
  {
    id: "t1",
    title: "Why Handmade Ceramics Are Making a Comeback",
    excerpt: "The resurgence of craft in a digital world — a deep dive into the potter's movement.",
    image: card5,
    type: "article",
    author: { name: "Ava Lin", avatar: avatarUrl("ava") },
    date: "Mar 6, 2026",
    readTime: "6 min read",
    tags: ["Craft", "Culture"],
  },
  {
    id: "t2",
    title: "Curated: The Best Independent Boutiques",
    excerpt: "Our editors' picks for the most inspiring fashion boutiques worth visiting.",
    image: card6,
    type: "gallery",
    author: { name: "Nina Patel", avatar: avatarUrl("nina") },
    date: "Mar 5, 2026",
    tags: ["Fashion", "Curated"],
  },
  {
    id: "t3",
    title: "A Weekend in the Italian Countryside",
    excerpt: "Tuscany beyond the tourist trail — vineyards, village markets, and timeless beauty.",
    image: hero3,
    type: "article",
    author: { name: "Marco Ricci", avatar: avatarUrl("marco") },
    date: "Mar 4, 2026",
    readTime: "10 min read",
    tags: ["Travel", "Italy"],
  },
  {
    id: "t4",
    title: "The Perfect Morning Ritual",
    excerpt: "How top creatives start their day for peak inspiration and focus.",
    image: hero1,
    type: "article",
    author: { name: "Elena Marsh", avatar: avatarUrl("elena") },
    date: "Mar 3, 2026",
    readTime: "5 min read",
    tags: ["Lifestyle", "Productivity"],
  },
  {
    id: "t5",
    title: "Minimalist Kitchen Essentials",
    excerpt: "Everything you need and nothing you don't — the chef's guide to a clean kitchen.",
    image: card1,
    type: "listing",
    author: { name: "Mia Chen", avatar: avatarUrl("mia") },
    date: "Mar 2, 2026",
    price: "$25–$180",
    location: "Online",
    tags: ["Kitchen", "Minimalism"],
  },
  {
    id: "t6",
    title: "Gallery: Light & Shadow in Architecture",
    excerpt: "A photographic exploration of how buildings dance with natural light.",
    image: hero2,
    type: "gallery",
    author: { name: "James Cole", avatar: avatarUrl("james") },
    date: "Mar 1, 2026",
    tags: ["Photography", "Architecture"],
  },
];
