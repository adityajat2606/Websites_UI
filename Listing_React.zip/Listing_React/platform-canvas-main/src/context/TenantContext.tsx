import { createContext, useContext, useEffect, useMemo } from "react";
import { getTenantFromHostname, type TenantConfig } from "@/lib/tenant";

const TenantContext = createContext<TenantConfig | null>(null);

export function TenantProvider({ children }: { children: React.ReactNode }) {
  const tenant = useMemo(() => getTenantFromHostname(window.location.hostname), []);

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--primary", tenant.primaryHsl);
    root.style.setProperty("--ring", tenant.primaryHsl);
    root.style.setProperty("--accent", tenant.accentHsl);
  }, [tenant]);

  return <TenantContext.Provider value={tenant}>{children}</TenantContext.Provider>;
}

export function useTenant(): TenantConfig {
  const ctx = useContext(TenantContext);
  if (!ctx) throw new Error("useTenant must be inside TenantProvider");
  return ctx;
}
