import { createContext, useContext, useEffect, useMemo, useState } from "react";

interface AuthUser {
  fullName: string;
  email: string;
  company?: string;
}

interface StoredAccount extends AuthUser {
  password: string;
  createdAt: string;
}

interface AuthResult {
  ok: boolean;
  error?: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  isAuthenticated: boolean;
  signIn: (email: string, password: string, rememberMe: boolean) => AuthResult;
  signUp: (input: {
    fullName: string;
    email: string;
    company?: string;
    password: string;
    acceptTerms: boolean;
  }) => AuthResult;
  signOut: () => void;
}

const SESSION_KEY = "platform.canvas.auth.session";
const ACCOUNT_KEY = "platform.canvas.auth.accounts";
const MEMORY_KEY = "platform.canvas.auth.remember";

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const isEmail = (value: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

const normalizeEmail = (value: string) => value.trim().toLowerCase();

const getStoredAccounts = (): StoredAccount[] => {
  if (typeof window === "undefined") return [];
  const raw = window.localStorage.getItem(ACCOUNT_KEY);
  if (!raw) return [];

  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const saveStoredAccounts = (accounts: StoredAccount[]) => {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(ACCOUNT_KEY, JSON.stringify(accounts));
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const rawSession = window.localStorage.getItem(SESSION_KEY);
    const fallbackSession = window.sessionStorage.getItem(SESSION_KEY);
    const persisted = rawSession || fallbackSession;
    if (!persisted) return;

    try {
      const session = JSON.parse(persisted) as AuthUser;
      if (session?.email) {
        setUser(session);
      }
    } catch {
      window.localStorage.removeItem(SESSION_KEY);
      window.sessionStorage.removeItem(SESSION_KEY);
    }
  }, []);

  const signIn = (email: string, password: string, rememberMe: boolean): AuthResult => {
    const cleanEmail = normalizeEmail(email);
    if (!cleanEmail || !password.trim()) {
      return { ok: false, error: "Email and password are required." };
    }
    if (!isEmail(cleanEmail)) {
      return { ok: false, error: "Enter a valid email address." };
    }

    const account = getStoredAccounts().find((entry) => entry.email === cleanEmail);
    if (!account || account.password !== password) {
      return { ok: false, error: "Incorrect email or password." };
    }

    const nextUser: AuthUser = {
      fullName: account.fullName,
      email: account.email,
      company: account.company,
    };

    setUser(nextUser);
    if (typeof window !== "undefined") {
      if (rememberMe) {
        window.localStorage.setItem(SESSION_KEY, JSON.stringify(nextUser));
        window.sessionStorage.removeItem(SESSION_KEY);
      } else {
        window.sessionStorage.setItem(SESSION_KEY, JSON.stringify(nextUser));
        window.localStorage.removeItem(SESSION_KEY);
      }
      window.localStorage.setItem(MEMORY_KEY, rememberMe ? "1" : "0");
    }
    return { ok: true };
  };

  const signUp = (input: {
    fullName: string;
    email: string;
    company?: string;
    password: string;
    acceptTerms: boolean;
  }): AuthResult => {
    const fullName = input.fullName.trim();
    const email = normalizeEmail(input.email);
    const company = input.company?.trim();
    const password = input.password;

    if (!fullName || !email || !password) {
      return { ok: false, error: "Name, email, and password are required." };
    }
    if (!isEmail(email)) {
      return { ok: false, error: "Enter a valid email address." };
    }
    if (password.length < 8) {
      return { ok: false, error: "Password must be at least 8 characters." };
    }
    if (!input.acceptTerms) {
      return { ok: false, error: "You must accept terms to continue." };
    }

    const accounts = getStoredAccounts();
    if (accounts.some((entry) => entry.email === email)) {
      return { ok: false, error: "An account with this email already exists." };
    }

    const account: StoredAccount = {
      fullName,
      email,
      company,
      password,
      createdAt: new Date().toISOString(),
    };

    saveStoredAccounts([...accounts, account]);

    const nextUser: AuthUser = { fullName, email, company };
    setUser(nextUser);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(SESSION_KEY, JSON.stringify(nextUser));
      window.sessionStorage.removeItem(SESSION_KEY);
      window.localStorage.setItem(MEMORY_KEY, "1");
    }
    return { ok: true };
  };

  const signOut = () => {
    setUser(null);
    if (typeof window !== "undefined") {
      window.localStorage.removeItem(SESSION_KEY);
      window.sessionStorage.removeItem(SESSION_KEY);
      window.localStorage.removeItem(MEMORY_KEY);
    }
  };

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isAuthenticated: !!user,
      signIn,
      signUp,
      signOut,
    }),
    [user],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used inside AuthProvider");
  }
  return context;
}
