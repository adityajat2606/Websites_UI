export interface TenantConfig {
  id: string;
  name: string;
  brandName: string;
  brandAccent: string; // display name part in accent
  tagline: string;
  primaryHsl: string;
  accentHsl: string;
}

const tenants: Record<string, TenantConfig> = {
  default: {
    id: "default",
    name: "MuseBoard",
    brandName: "Board",
    brandAccent: "Muse",
    tagline: "Articles, galleries, and listings — all in one place.",
    primaryHsl: "12 80% 55%",
    accentHsl: "45 93% 58%",
  },
  artisan: {
    id: "artisan",
    name: "ArtisanHub",
    brandName: "Hub",
    brandAccent: "Artisan",
    tagline: "Handcrafted goods and curated creative spaces.",
    primaryHsl: "160 60% 40%",
    accentHsl: "35 90% 55%",
  },
  wanderlust: {
    id: "wanderlust",
    name: "Wanderlust",
    brandName: "lust",
    brandAccent: "Wander",
    tagline: "Discover breathtaking destinations worldwide.",
    primaryHsl: "210 70% 50%",
    accentHsl: "30 85% 55%",
  },
};

export function getTenantFromHostname(hostname: string): TenantConfig {
  const subdomain = hostname.split(".")[0];
  return tenants[subdomain] || tenants.default;
}

export function getTenantById(id: string): TenantConfig {
  return tenants[id] || tenants.default;
}

export function getAllTenants(): TenantConfig[] {
  return Object.values(tenants);
}
