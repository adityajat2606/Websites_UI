import { useState } from "react";
import { motion } from "framer-motion";
import { Send, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

interface ContactFormProps {
  postTitle: string;
}

export default function ContactForm({ postTitle }: ContactFormProps) {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error("Please fill in all fields.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Please enter a valid email.");
      return;
    }
    setSubmitted(true);
    toast.success("Your inquiry has been sent!");
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-lg border border-border bg-card p-6 text-center"
      >
        <CheckCircle className="mx-auto h-10 w-10 text-primary" />
        <h3 className="mt-3 font-display text-xl text-card-foreground">Inquiry Sent!</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          We'll get back to you about "{postTitle}" soon.
        </p>
        <Button variant="ghost" className="mt-4" onClick={() => setSubmitted(false)}>
          Send another
        </Button>
      </motion.div>
    );
  }

  return (
    <div className="rounded-lg border border-border bg-card p-6">
      <h3 className="font-display text-xl text-card-foreground">Interested?</h3>
      <p className="mt-1 text-sm text-muted-foreground">Send an inquiry about this listing.</p>
      <form onSubmit={handleSubmit} className="mt-4 space-y-3">
        <Input
          placeholder="Your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={100}
        />
        <Input
          type="email"
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          maxLength={255}
        />
        <Textarea
          placeholder={`I'm interested in "${postTitle}"...`}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={4}
          maxLength={1000}
        />
        <Button type="submit" className="w-full">
          <Send className="mr-2 h-4 w-4" /> Send Inquiry
        </Button>
      </form>
    </div>
  );
}
