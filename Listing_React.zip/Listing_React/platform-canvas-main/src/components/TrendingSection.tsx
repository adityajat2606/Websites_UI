import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";
import { trendingPosts } from "@/data/mock-data";
import MasonryCard from "./MasonryCard";

export default function TrendingSection() {
  return (
    <section className="container py-12">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mb-8 flex items-center gap-2"
      >
        <TrendingUp className="h-5 w-5 text-primary" />
        <h2 className="font-display text-3xl text-foreground md:text-4xl">Trending Right Now</h2>
      </motion.div>

      <div className="masonry-grid">
        {trendingPosts.map((post, i) => (
          <MasonryCard key={post.id} post={post} index={i} />
        ))}
      </div>
    </section>
  );
}
