import { useNavigate } from "react-router-dom";
import { useEffect, useCallback, useState } from "react";
import { motion } from "framer-motion";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import type { CarouselApi } from "@/components/ui/carousel";
import { featuredPosts } from "@/data/mock-data";
import PostTypeBadge from "./PostTypeBadge";

export default function FeaturedCarousel() {
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);
  const navigate = useNavigate();

  const onSelect = useCallback(() => {
    if (!api) return;
    setCurrent(api.selectedScrollSnap());
  }, [api]);

  useEffect(() => {
    if (!api) return;
    api.on("select", onSelect);

    const interval = setInterval(() => {
      api.scrollNext();
    }, 5000);

    return () => {
      api.off("select", onSelect);
      clearInterval(interval);
    };
  }, [api, onSelect]);

  return (
    <section className="container py-10">
      <Carousel setApi={setApi} opts={{ loop: true }} className="relative">
        <CarouselContent>
          {featuredPosts.map((post) => (
            <CarouselItem key={post.id}>
              <motion.div
                whileHover={{ scale: 1.005 }}
                onClick={() => navigate(`/post/${post.id}`)}
                className="group relative cursor-pointer overflow-hidden rounded-xl"
              >
                <div className="relative aspect-[21/9] overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/20 to-transparent" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
                  <PostTypeBadge type={post.type} />
                  <h2 className="mt-2 font-display text-2xl font-normal text-primary-foreground md:text-4xl">
                    {post.title}
                  </h2>
                  <p className="mt-2 max-w-lg text-sm text-primary-foreground/80">
                    {post.excerpt}
                  </p>
                  <div className="mt-3 flex items-center gap-3">
                    <img
                      src={post.author.avatar}
                      alt={post.author.name}
                      className="h-8 w-8 rounded-full bg-muted"
                    />
                    <span className="text-sm font-medium text-primary-foreground">
                      {post.author.name}
                    </span>
                    <span className="text-sm text-primary-foreground/60">{post.date}</span>
                  </div>
                </div>
              </motion.div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious className="left-4 bg-card/80 backdrop-blur-sm" />
        <CarouselNext className="right-4 bg-card/80 backdrop-blur-sm" />

        {/* Dots */}
        <div className="mt-4 flex justify-center gap-2">
          {featuredPosts.map((_, i) => (
            <button
              key={i}
              onClick={() => api?.scrollTo(i)}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === current ? "w-6 bg-primary" : "w-2 bg-muted-foreground/30"
              }`}
            />
          ))}
        </div>
      </Carousel>
    </section>
  );
}
