import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function HeroSection() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  return (
    <section
      className="relative flex min-h-[420px] flex-col items-center justify-center px-4 py-20"
      style={{ background: "var(--gradient-hero)" }}
    >
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mx-auto max-w-2xl text-center"
      >
        <h1 className="font-display text-5xl font-normal leading-tight text-foreground md:text-6xl">
          Discover &amp; Share<br />
          <span className="italic text-primary">Beautiful Things</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Articles, galleries, and listings — all in one place.
        </p>
      </motion.div>

      <motion.form
        onSubmit={handleSearch}
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="relative mt-8 w-full max-w-xl"
      >
        <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search articles, galleries, listings…"
          className="h-14 rounded-full border-border bg-card pl-12 pr-6 text-base shadow-card placeholder:text-muted-foreground focus-visible:ring-primary"
        />
      </motion.form>
    </section>
  );
}
