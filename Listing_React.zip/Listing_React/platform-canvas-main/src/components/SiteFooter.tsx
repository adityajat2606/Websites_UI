﻿import { useNavigate } from "react-router-dom";
import { useTenant } from "@/context/TenantContext";

export default function SiteFooter() {
  const tenant = useTenant();
  const navigate = useNavigate();

  const footerLinks = [
    {
      title: "Explore",
      links: [
        { label: "Home", path: "/" },
        { label: "Articles", path: "/category/articles" },
        { label: "Galleries", path: "/category/galleries" },
        { label: "Listings", path: "/category/listings" },
        { label: "Contact", path: "/contact" },
      ],
    },
    {
      title: "Company",
      path: "/company",
      links: [
        { label: "About", path: "/about" },
        { label: "Careers", path: "/careers" },
        { label: "Blog", path: "/blog" },
        { label: "Press", path: "/press" },
      ],
    },
    {
      title: "Legal",
      path: "/legal",
      links: [
        { label: "Privacy", path: "/privacy" },
        { label: "Terms", path: "/terms" },
        { label: "Cookies", path: "/cookies" },
      ],
    },
  ];

  return (
    <footer className="border-t border-border bg-secondary/50 py-12">
      <div className="container">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <button onClick={() => navigate("/")} className="font-display text-xl text-foreground">
              <span className="text-primary">{tenant.brandAccent}</span>
              {tenant.brandName}
            </button>
            <p className="mt-2 text-sm text-muted-foreground">
              Discover, share, and connect through beautiful content.
            </p>
          </div>
          {footerLinks.map((col) => (
            <div key={col.title}>
              <button
                className="text-sm font-semibold text-foreground transition-colors hover:text-primary"
                onClick={() => col.path && navigate(col.path)}
              >
                {col.title}
              </button>
              <ul className="mt-3 space-y-2">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <button
                      onClick={() => navigate(link.path)}
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 border-t border-border pt-6 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} {tenant.name}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
