import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { latestListings } from "@/data/mock-data";
import ListingCard from "./ListingCard";

export default function LatestListings() {
  const navigate = useNavigate();

  return (
    <section className="container py-12">
      <div className="mb-8 flex items-end justify-between">
        <motion.h2
          initial={{ opacity: 0, x: -16 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="font-display text-3xl text-foreground md:text-4xl"
        >
          Latest Listings
        </motion.h2>
        <motion.button
          onClick={() => navigate("/category/listings")}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
        >
          View All <ArrowRight className="h-4 w-4" />
        </motion.button>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {latestListings.map((post, i) => (
          <ListingCard key={post.id} post={post} index={i} />
        ))}
      </div>
    </section>
  );
}
