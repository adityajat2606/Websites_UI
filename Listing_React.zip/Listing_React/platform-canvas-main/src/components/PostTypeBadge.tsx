import { BookOpen, Images, MapPin } from "lucide-react";
import type { PostType } from "@/data/mock-data";

const config: Record<PostType, { label: string; icon: typeof BookOpen; className: string }> = {
  article: { label: "Article", icon: BookOpen, className: "bg-primary/10 text-primary" },
  gallery: { label: "Gallery", icon: Images, className: "bg-accent/30 text-accent-foreground" },
  listing: { label: "Listing", icon: MapPin, className: "bg-secondary text-secondary-foreground" },
};

export default function PostTypeBadge({ type }: { type: PostType }) {
  const { label, icon: Icon, className } = config[type];
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${className}`}>
      <Icon className="h-3 w-3" />
      {label}
    </span>
  );
}
