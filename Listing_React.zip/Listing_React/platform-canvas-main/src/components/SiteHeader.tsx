import { motion } from "framer-motion";
import { LogOut, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTenant } from "@/context/TenantContext";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";

export default function SiteHeader() {
  const tenant = useTenant();
  const navigate = useNavigate();
  const { isAuthenticated, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { label: "Home", path: "/" },
    { label: "Articles", path: "/category/articles" },
    { label: "Galleries", path: "/category/galleries" },
    { label: "Listings", path: "/category/listings" },
    { label: "About", path: "/about" },
    { label: "Contact", path: "/contact" },
  ];

  return (
    <motion.header
      initial={{ opacity: 0, y: -12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-lg"
    >
      <div className="container flex h-16 items-center justify-between">
        <button onClick={() => navigate("/")} className="font-display text-2xl text-foreground">
          <span className="text-primary">{tenant.brandAccent}</span>{tenant.brandName}
        </button>

        <nav className="hidden items-center gap-6 md:flex">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => navigate(item.path)}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <>
              <Button variant="ghost" size="sm" className="hidden md:inline-flex" onClick={() => navigate("/dashboard")}>
                Dashboard
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  signOut();
                  navigate("/");
                }}
              >
                <LogOut className="h-4 w-4" />
                Sign Out
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" className="hidden md:inline-flex" onClick={() => navigate("/sign-in")}>
                Sign In
              </Button>
              <Button size="sm" onClick={() => navigate("/get-started")}>
                Get Started
              </Button>
            </>
          )}
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="border-t border-border bg-background md:hidden"
        >
          <nav className="container flex flex-col gap-2 py-4">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => {
                  navigate(item.path);
                  setMobileOpen(false);
                }}
                className="rounded-md px-3 py-2 text-left text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              >
                {item.label}
              </button>
            ))}
            {isAuthenticated ? (
              <div className="mt-2 grid grid-cols-2 gap-2 px-3">
                <Button variant="outline" size="sm" onClick={() => { navigate("/dashboard"); setMobileOpen(false); }}>
                  Dashboard
                </Button>
                <Button
                  size="sm"
                  onClick={() => {
                    signOut();
                    navigate("/");
                    setMobileOpen(false);
                  }}
                >
                  Sign Out
                </Button>
              </div>
            ) : (
              <div className="mt-2 grid grid-cols-2 gap-2 px-3">
                <Button variant="outline" size="sm" onClick={() => { navigate("/sign-in"); setMobileOpen(false); }}>
                  Sign In
                </Button>
                <Button size="sm" onClick={() => { navigate("/get-started"); setMobileOpen(false); }}>
                  Get Started
                </Button>
              </div>
            )}
          </nav>
        </motion.div>
      )}
    </motion.header>
  );
}
