import { motion } from "framer-motion";
import { MapPin, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Post } from "@/data/mock-data";
import PostTypeBadge from "./PostTypeBadge";

interface ListingCardProps {
  post: Post;
  index?: number;
}

export default function ListingCard({ post, index = 0 }: ListingCardProps) {
  const navigate = useNavigate();

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -4 }}
      onClick={() => navigate(`/post/${post.id}`)}
      className="group cursor-pointer overflow-hidden rounded-lg bg-card shadow-card transition-shadow duration-300 hover:shadow-card-hover"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute left-3 top-3">
          <PostTypeBadge type={post.type} />
        </div>
        {post.price && (
          <div className="absolute bottom-3 right-3 rounded-full bg-card/90 px-3 py-1 text-sm font-semibold text-card-foreground backdrop-blur-sm">
            {post.price}
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-display text-lg font-medium leading-snug text-card-foreground line-clamp-2">
          {post.title}
        </h3>
        <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2">{post.excerpt}</p>

        <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
          {post.location && (
            <span className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              {post.location}
            </span>
          )}
          {post.readTime && (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {post.readTime}
            </span>
          )}
        </div>

        <div className="mt-3 flex items-center gap-2 border-t border-border pt-3">
          <img
            src={post.author.avatar}
            alt={post.author.name}
            className="h-6 w-6 rounded-full bg-muted"
          />
          <span className="text-xs font-medium text-card-foreground">{post.author.name}</span>
          <span className="ml-auto text-xs text-muted-foreground">{post.date}</span>
        </div>
      </div>
    </motion.article>
  );
}
