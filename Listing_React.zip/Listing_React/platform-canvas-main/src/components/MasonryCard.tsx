import { motion } from "framer-motion";
import { Clock, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Post } from "@/data/mock-data";
import PostTypeBadge from "./PostTypeBadge";

export default function MasonryCard({ post, index = 0 }: { post: Post; index?: number }) {
  const navigate = useNavigate();

  return (
    <motion.article
      initial={{ opacity: 0, scale: 0.96 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
      whileHover={{ y: -3 }}
      onClick={() => navigate(`/post/${post.id}`)}
      className="masonry-item group cursor-pointer overflow-hidden rounded-lg bg-card shadow-card transition-shadow duration-300 hover:shadow-card-hover"
    >
      <div className="relative overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute left-3 top-3">
          <PostTypeBadge type={post.type} />
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-display text-base font-medium leading-snug text-card-foreground line-clamp-2">
          {post.title}
        </h3>
        <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{post.excerpt}</p>

        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {post.price && (
            <span className="rounded-full bg-primary/10 px-2 py-0.5 font-medium text-primary">
              {post.price}
            </span>
          )}
          {post.location && (
            <span className="flex items-center gap-1">
              <MapPin className="h-3 w-3" /> {post.location}
            </span>
          )}
          {post.readTime && (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" /> {post.readTime}
            </span>
          )}
        </div>

        <div className="mt-3 flex items-center gap-2">
          <img src={post.author.avatar} alt={post.author.name} className="h-5 w-5 rounded-full bg-muted" />
          <span className="text-xs text-muted-foreground">{post.author.name}</span>
        </div>
      </div>
    </motion.article>
  );
}
