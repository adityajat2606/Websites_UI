import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Navigate, useNavigate } from "react-router-dom";
import { ArrowUpRight, BellRing, CalendarClock, CircleCheckBig, MessageSquare, TrendingUp } from "lucide-react";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { featuredPosts, latestListings, trendingPosts } from "@/data/mock-data";
import type { Post } from "@/data/mock-data";

const metrics = [
  { label: "Profile views", value: "24,891", delta: "+18.2%" },
  { label: "Listing inquiries", value: "1,284", delta: "+9.4%" },
  { label: "Avg. response time", value: "1h 12m", delta: "-22%" },
  { label: "Saved by readers", value: "3,567", delta: "+11.8%" },
];

const activity = [
  { title: "Soho Design Loft", detail: "43 new saves and 12 inquiries in the last 24h", time: "14 min ago" },
  { title: "Summer Retail Spotlight", detail: "Approved by editorial and scheduled for Mar 9", time: "1h ago" },
  { title: "New message from Ava Lin", detail: "Requested collaboration on your listing gallery", time: "2h ago" },
  { title: "Policy update complete", detail: "Cookie consent banner now compliant in all regions", time: "Yesterday" },
];

const tasks = [
  "Reply to 7 unread inquiries from premium listings",
  "Upload 3 missing images for 'Riverside Studio Tour'",
  "Review campaign budget changes for Week 11",
];

const INTERACTION_KEY = "platform.canvas.article.interactions";
const allPosts = [...featuredPosts, ...latestListings, ...trendingPosts];

interface InteractionSummary {
  saved?: boolean;
}

type InteractionStore = Record<string, Record<string, InteractionSummary>>;

export default function DashboardPage() {
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const [savedArticleIds, setSavedArticleIds] = useState<string[]>([]);

  useEffect(() => {
    if (!user?.email) return;
    const raw = window.localStorage.getItem(INTERACTION_KEY);
    if (!raw) {
      setSavedArticleIds([]);
      return;
    }
    try {
      const parsed = JSON.parse(raw) as InteractionStore;
      const interactions = parsed[user.email.toLowerCase()] || {};
      const ids = Object.entries(interactions)
        .filter(([, value]) => value?.saved)
        .map(([postId]) => postId);
      setSavedArticleIds(ids);
    } catch {
      setSavedArticleIds([]);
    }
  }, [user?.email]);

  const savedArticles = useMemo<Post[]>(
    () =>
      allPosts.filter(
        (post) => post.type === "article" && savedArticleIds.includes(post.id),
      ),
    [savedArticleIds],
  );

  if (!isAuthenticated) {
    return <Navigate to="/sign-in" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container py-10">
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-border bg-gradient-to-r from-card via-secondary/30 to-card p-6 md:p-8"
        >
          <p className="text-sm text-muted-foreground">Dashboard</p>
          <h1 className="mt-2 font-display text-4xl text-foreground">Welcome back, {user?.fullName}</h1>
          <p className="mt-3 max-w-3xl text-muted-foreground">
            Your workspace summary for today, including listing performance, team activity, and items that need action.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Button onClick={() => navigate("/category/listings")}>
              Manage Listings <ArrowUpRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" onClick={() => navigate("/contact")}>
              Contact Support
            </Button>
          </div>
        </motion.section>

        <section className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {metrics.map((item) => (
            <article key={item.label} className="rounded-xl border border-border bg-card p-5">
              <p className="text-sm text-muted-foreground">{item.label}</p>
              <p className="mt-1 text-3xl font-semibold text-card-foreground">{item.value}</p>
              <p className="mt-2 inline-flex items-center gap-1 text-sm text-primary">
                <TrendingUp className="h-4 w-4" />
                {item.delta} vs last week
              </p>
            </article>
          ))}
        </section>

        <section className="mt-6 grid gap-4 lg:grid-cols-3">
          <article className="rounded-xl border border-border bg-card p-6 lg:col-span-2">
            <h2 className="font-display text-2xl text-card-foreground">Recent Activity</h2>
            <div className="mt-4 space-y-3">
              {activity.map((entry) => (
                <div key={entry.title} className="rounded-lg border border-border bg-background p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="font-medium text-foreground">{entry.title}</p>
                      <p className="mt-1 text-sm text-muted-foreground">{entry.detail}</p>
                    </div>
                    <p className="whitespace-nowrap text-xs text-muted-foreground">{entry.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </article>

          <article className="rounded-xl border border-border bg-card p-6">
            <h2 className="font-display text-2xl text-card-foreground">Today</h2>
            <div className="mt-4 space-y-3">
              <div className="rounded-lg border border-border bg-background p-4">
                <p className="flex items-center gap-2 font-medium text-foreground">
                  <CalendarClock className="h-4 w-4 text-primary" />
                  2 meetings
                </p>
                <p className="mt-1 text-sm text-muted-foreground">Editorial sync at 11:30 AM, partner check-in at 4:00 PM.</p>
              </div>
              <div className="rounded-lg border border-border bg-background p-4">
                <p className="flex items-center gap-2 font-medium text-foreground">
                  <BellRing className="h-4 w-4 text-primary" />
                  5 new alerts
                </p>
                <p className="mt-1 text-sm text-muted-foreground">3 policy reminders and 2 high-priority listing notifications.</p>
              </div>
              <div className="rounded-lg border border-border bg-background p-4">
                <p className="flex items-center gap-2 font-medium text-foreground">
                  <MessageSquare className="h-4 w-4 text-primary" />
                  11 unread messages
                </p>
                <p className="mt-1 text-sm text-muted-foreground">Respond to inbound partnership and creator requests.</p>
              </div>
            </div>
          </article>
        </section>

        <section className="mt-6 rounded-xl border border-border bg-card p-6">
          <h2 className="font-display text-2xl text-card-foreground">Action Items</h2>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            {tasks.map((task) => (
              <div key={task} className="rounded-lg border border-border bg-background p-4">
                <p className="flex items-start gap-2 text-sm text-foreground">
                  <CircleCheckBig className="mt-0.5 h-4 w-4 text-primary" />
                  {task}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-6 rounded-xl border border-border bg-card p-6">
          <div className="flex items-center justify-between gap-4">
            <h2 className="font-display text-2xl text-card-foreground">Saved Articles</h2>
            <p className="text-sm text-muted-foreground">{savedArticles.length} saved</p>
          </div>

          {savedArticles.length === 0 ? (
            <div className="mt-4 rounded-lg border border-dashed border-border bg-background p-5 text-sm text-muted-foreground">
              No saved articles yet. Open an article and click the Save button.
            </div>
          ) : (
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {savedArticles.map((article) => (
                <article key={article.id} className="rounded-lg border border-border bg-background p-4">
                  <p className="text-xs text-muted-foreground">{article.date}</p>
                  <h3 className="mt-1 text-base font-semibold text-foreground">{article.title}</h3>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{article.excerpt}</p>
                  <div className="mt-3">
                    <Button size="sm" variant="outline" onClick={() => navigate(`/post/${article.id}`)}>
                      Open Article
                    </Button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
