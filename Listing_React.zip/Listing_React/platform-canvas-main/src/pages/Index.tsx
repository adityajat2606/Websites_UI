import SiteHeader from "@/components/SiteHeader";
import HeroSection from "@/components/HeroSection";
import FeaturedCarousel from "@/components/FeaturedCarousel";
import LatestListings from "@/components/LatestListings";
import TrendingSection from "@/components/TrendingSection";
import SiteFooter from "@/components/SiteFooter";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <HeroSection />
        <FeaturedCarousel />
        <LatestListings />
        <TrendingSection />
      </main>
      <SiteFooter />
    </div>
  );
};

export default Index;
