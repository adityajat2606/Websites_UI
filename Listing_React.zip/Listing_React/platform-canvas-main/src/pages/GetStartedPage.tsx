import { FormEvent, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { CheckCircle2, Eye, EyeOff, Rocket, ShieldCheck } from "lucide-react";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";

export default function GetStartedPage() {
  const navigate = useNavigate();
  const { isAuthenticated, signUp } = useAuth();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const canSubmit = useMemo(
    () =>
      !!fullName.trim() &&
      !!email.trim() &&
      !!password.trim() &&
      !!confirmPassword.trim() &&
      acceptTerms,
    [acceptTerms, confirmPassword, email, fullName, password],
  );

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canSubmit) {
      toast.error("Please fill all required fields");
      return;
    }
    if (password !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    if (password.length < 8) {
      toast.error("Password should be at least 8 characters");
      return;
    }

    setIsSubmitting(true);
    const result = signUp({ fullName, email, company, password, acceptTerms });
    if (!result.ok) {
      toast.error(result.error || "Unable to create account");
      setIsSubmitting(false);
      return;
    }

    toast.success("Account created successfully");
    setFullName("");
    setEmail("");
    setCompany("");
    setPassword("");
    setConfirmPassword("");
    setAcceptTerms(false);
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container grid gap-6 py-12 lg:grid-cols-2 lg:py-16">
        <section className="rounded-2xl border border-border bg-gradient-to-br from-primary/10 via-secondary to-background p-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-3 py-1 text-xs text-muted-foreground">
            <Rocket className="h-3.5 w-3.5 text-primary" />
            Setup takes under 2 minutes
          </div>
          <h1 className="mt-5 font-display text-4xl leading-tight text-foreground">
            Launch your creator and listing workspace
          </h1>
          <p className="mt-4 max-w-xl text-muted-foreground">
            Start publishing high-quality listings, collecting inquiries, and growing your audience with built-in tools.
          </p>
          <div className="mt-8 grid gap-3">
            {[
              "Publish listings with structured metadata and image galleries",
              "Track post performance and trending visibility in one dashboard",
              "Collaborate with editors and partnership managers in real time",
            ].map((item) => (
              <div key={item} className="flex items-start gap-3 rounded-lg border border-border bg-card px-4 py-3">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-primary" />
                <p className="text-sm text-card-foreground">{item}</p>
              </div>
            ))}
          </div>
        </section>

        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-border bg-card p-8"
        >
          <h2 className="font-display text-3xl text-card-foreground">Create account</h2>
          <p className="mt-2 text-sm text-muted-foreground">Use your work details to get started.</p>

          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signup-name">Full name</Label>
              <Input
                id="signup-name"
                placeholder="Jane Doe"
                value={fullName}
                onChange={(event) => setFullName(event.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="signup-email">Work email</Label>
              <Input
                id="signup-email"
                type="email"
                placeholder="name@company.com"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="signup-company">Company</Label>
              <Input
                id="signup-company"
                placeholder="Company name (optional)"
                value={company}
                onChange={(event) => setCompany(event.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="signup-password">Password</Label>
              <div className="relative">
                <Input
                  id="signup-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="At least 8 characters"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((value) => !value)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="signup-confirm-password">Confirm password</Label>
              <div className="relative">
                <Input
                  id="signup-confirm-password"
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="Re-enter password"
                  value={confirmPassword}
                  onChange={(event) => setConfirmPassword(event.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((value) => !value)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                >
                  {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-start gap-2 rounded-lg border border-border bg-secondary/40 p-3">
              <Checkbox
                id="signup-terms"
                checked={acceptTerms}
                onCheckedChange={(checked) => setAcceptTerms(checked === true)}
                className="mt-0.5"
              />
              <Label htmlFor="signup-terms" className="text-sm leading-5 text-muted-foreground">
                I agree to the Terms, Privacy Policy, and consent to security checks for account protection.
              </Label>
              <ShieldCheck className="h-4 w-4 text-primary" />
            </div>

            <Button type="submit" className="w-full" disabled={!canSubmit || isSubmitting}>
              {isSubmitting ? "Creating account..." : "Create Account"}
            </Button>
          </form>

          <p className="mt-5 text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link to="/sign-in" className="text-primary hover:underline">
              Sign in
            </Link>
          </p>
        </motion.section>
      </main>
      <SiteFooter />
    </div>
  );
}
