import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Clock,
  MapPin,
  Calendar,
  Share2,
  Heart,
  Bookmark,
  MessageCircle,
  ImagePlus,
  Pencil,
  Trash2,
  Send,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import PostTypeBadge from "@/components/PostTypeBadge";
import ContactForm from "@/components/ContactForm";
import GalleryLightbox from "@/components/GalleryLightbox";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { featuredPosts, latestListings, trendingPosts } from "@/data/mock-data";
import type { Post } from "@/data/mock-data";
import { toast } from "sonner";

const allPosts = [...featuredPosts, ...latestListings, ...trendingPosts];

function getPost(id: string): Post | undefined {
  return allPosts.find((p) => p.id === id);
}

interface ArticleComment {
  id: string;
  name: string;
  email: string;
  text: string;
  date: string;
  imageDataUrl?: string;
  replies: ArticleReply[];
}

interface ArticleReply {
  id: string;
  name: string;
  email: string;
  text: string;
  date: string;
}

interface ArticleInteractions {
  liked: boolean;
  saved: boolean;
  comments: ArticleComment[];
}

type InteractionStore = Record<string, Record<string, ArticleInteractions>>;

const INTERACTION_KEY = "platform.canvas.article.interactions";

const defaultComments: ArticleComment[] = [
  {
    id: "seed-1",
    name: "Mia Chen",
    email: "mia@example.com",
    text: "Great perspective. The ritual section was practical and easy to apply.",
    date: "Mar 6, 2026",
    replies: [],
  },
  {
    id: "seed-2",
    name: "Lukas Berg",
    email: "lukas@example.com",
    text: "Loved this. It reads like a quiet reset for busy days.",
    date: "Mar 5, 2026",
    replies: [],
  },
];

const normalizeComments = (comments: unknown): ArticleComment[] => {
  if (!Array.isArray(comments)) return defaultComments;
  return comments.map((entry, index) => {
    const comment = (entry || {}) as Partial<ArticleComment>;
    const replies = Array.isArray(comment.replies) ? comment.replies : [];
    return {
      id: comment.id || `legacy-${index}`,
      name: comment.name || "Reader",
      email: comment.email || "",
      text: comment.text || "",
      date: comment.date || "Recently",
      imageDataUrl: comment.imageDataUrl,
      replies: replies.map((reply, replyIndex) => {
        const item = (reply || {}) as Partial<ArticleReply>;
        return {
          id: item.id || `legacy-reply-${replyIndex}`,
          name: item.name || "Reader",
          email: item.email || "",
          text: item.text || "",
          date: item.date || "Recently",
        };
      }),
    };
  });
};

// Simulated long-form article content
const articleBody = `
## The Beginning of Something Beautiful

In a world that constantly pushes us toward speed, efficiency, and productivity, there's a quiet revolution brewing — one that asks us to slow down, breathe, and truly see the beauty around us.

This isn't about rejecting modernity. It's about finding balance. It's about choosing quality over quantity, depth over surface, and intention over impulse.

### The Art of Noticing

When we slow down, we begin to notice things we previously overlooked: the way morning light filters through curtains, the texture of handmade bread, the sound of rain on old windows. These small moments, often dismissed as insignificant, are actually the building blocks of a rich and meaningful life.

> "The real voyage of discovery consists not in seeking new landscapes, but in having new eyes." — Marcel Proust

### Building Daily Rituals

The most inspiring creatives throughout history have understood the power of ritual. A morning walk, a cup of carefully brewed tea, an hour of uninterrupted reading — these aren't luxuries, they're necessities for a life well-lived.

Consider starting with just one intentional practice:

- **Morning stillness**: 10 minutes of quiet before reaching for your phone
- **Mindful eating**: One meal per day without screens
- **Evening reflection**: A brief journal entry about what brought you joy
- **Creative time**: 30 minutes of making something with your hands

### The Ripple Effect

When we live with intention, the effect ripples outward. Our relationships deepen. Our work gains clarity. Our creativity flourishes. We become more present, more generous, more alive.

This is the art of slow living — not a destination, but a practice. Not perfection, but presence.
`;

export default function PostDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const post = id ? getPost(id) : undefined;

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="container flex flex-col items-center justify-center py-32">
          <h1 className="font-display text-4xl text-foreground">Post not found</h1>
          <Button variant="ghost" className="mt-4" onClick={() => navigate("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <AnimatePresence mode="wait">
          <motion.div
            key={post.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            {/* Hero image */}
            <div className="relative h-[50vh] min-h-[400px] overflow-hidden">
              <img
                src={post.image}
                alt={post.title}
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12">
                <div className="container">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate("/")}
                    className="mb-4 text-primary-foreground hover:bg-primary-foreground/20"
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back
                  </Button>
                  <PostTypeBadge type={post.type} />
                  <h1 className="mt-3 font-display text-3xl font-normal text-primary-foreground md:text-5xl lg:text-6xl max-w-3xl leading-tight">
                    {post.title}
                  </h1>
                  <p className="mt-3 max-w-2xl text-base text-primary-foreground/80 md:text-lg">
                    {post.excerpt}
                  </p>
                </div>
              </div>
            </div>

            {/* Meta bar */}
            <div className="border-b border-border">
              <div className="container flex flex-wrap items-center gap-4 py-4 md:gap-6">
                <div className="flex items-center gap-3">
                  <img
                    src={post.author.avatar}
                    alt={post.author.name}
                    className="h-10 w-10 rounded-full bg-muted"
                  />
                  <div>
                    <p className="text-sm font-semibold text-foreground">{post.author.name}</p>
                    <p className="text-xs text-muted-foreground">{post.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  {post.readTime && (
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" /> {post.readTime}
                    </span>
                  )}
                  {post.location && (
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" /> {post.location}
                    </span>
                  )}
                  {post.price && (
                    <span className="rounded-full bg-primary/10 px-3 py-1 font-medium text-primary">
                      {post.price}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="container py-10">
              {post.type === "article" && (
                <div className="mx-auto max-w-3xl space-y-10">
                  <ArticleContent post={post} />
                  <ArticleEngagement
                    post={post}
                    isAuthenticated={isAuthenticated}
                    userName={user?.fullName || "Reader"}
                    onRequireLogin={() => {
                      toast.info("Sign in to like, save, share, and comment.");
                      navigate("/sign-in");
                    }}
                  />
                </div>
              )}
              {post.type === "gallery" && <GalleryContent post={post} />}
              {post.type === "listing" && <ListingContent post={post} />}
            </div>

            {/* Tags */}
            <div className="container pb-10">
              <div className="flex flex-wrap gap-2">
                {post.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </main>
      <SiteFooter />
    </div>
  );
}

function ArticleContent({ post }: { post: Post }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="prose prose-lg"
    >
      <div className="space-y-6 text-foreground/90">
        {articleBody.split("\n\n").map((block, i) => {
          if (block.startsWith("## ")) {
            return (
              <h2 key={i} className="font-display text-3xl text-foreground mt-10">
                {block.replace("## ", "")}
              </h2>
            );
          }
          if (block.startsWith("### ")) {
            return (
              <h3 key={i} className="font-display text-2xl text-foreground mt-8">
                {block.replace("### ", "")}
              </h3>
            );
          }
          if (block.startsWith("> ")) {
            return (
              <blockquote
                key={i}
                className="border-l-4 border-primary pl-6 italic text-muted-foreground text-lg my-8"
              >
                {block.replace("> ", "")}
              </blockquote>
            );
          }
          if (block.startsWith("- ")) {
            return (
              <ul key={i} className="list-disc space-y-2 pl-6 text-foreground/80">
                {block.split("\n").map((item, j) => (
                  <li key={j} dangerouslySetInnerHTML={{ __html: item.replace(/^- /, "").replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>") }} />
                ))}
              </ul>
            );
          }
          if (block.trim()) {
            return (
              <p key={i} className="leading-relaxed text-foreground/80">
                {block.trim()}
              </p>
            );
          }
          return null;
        })}
      </div>
    </motion.article>
  );
}

function ArticleEngagement({
  post,
  isAuthenticated,
  userName,
  onRequireLogin,
}: {
  post: Post;
  isAuthenticated: boolean;
  userName: string;
  onRequireLogin: () => void;
}) {
  const { user } = useAuth();
  const identity = user?.email?.toLowerCase() || "";
  const [draftComment, setDraftComment] = useState("");
  const [draftImageDataUrl, setDraftImageDataUrl] = useState<string | undefined>(undefined);
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [activeReplyForComment, setActiveReplyForComment] = useState<string | null>(null);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editingCommentText, setEditingCommentText] = useState("");
  const [editingReplyKey, setEditingReplyKey] = useState<string | null>(null);
  const [editingReplyText, setEditingReplyText] = useState("");
  const [state, setState] = useState<ArticleInteractions>({
    liked: false,
    saved: false,
    comments: defaultComments,
  });

  useEffect(() => {
    if (!isAuthenticated || !identity) {
      setState({ liked: false, saved: false, comments: defaultComments });
      return;
    }

    const raw = window.localStorage.getItem(INTERACTION_KEY);
    if (!raw) {
      setState({ liked: false, saved: false, comments: defaultComments });
      return;
    }

    try {
      const parsed = JSON.parse(raw) as InteractionStore;
      const next = parsed?.[identity]?.[post.id];
      setState(
        next
          ? { liked: !!next.liked, saved: !!next.saved, comments: normalizeComments(next.comments) }
          : { liked: false, saved: false, comments: defaultComments },
      );
    } catch {
      setState({ liked: false, saved: false, comments: defaultComments });
    }
  }, [identity, isAuthenticated, post.id]);

  const persist = (next: ArticleInteractions) => {
    if (!isAuthenticated || !identity) return;

    const raw = window.localStorage.getItem(INTERACTION_KEY);
    let parsed: InteractionStore = {};
    if (raw) {
      try {
        parsed = JSON.parse(raw) as InteractionStore;
      } catch {
        parsed = {};
      }
    }

    parsed[identity] = parsed[identity] || {};
    parsed[identity][post.id] = next;
    window.localStorage.setItem(INTERACTION_KEY, JSON.stringify(parsed));
  };

  const likeCount = useMemo(() => 126 + (state.liked ? 1 : 0), [state.liked]);
  const saveCount = useMemo(() => 42 + (state.saved ? 1 : 0), [state.saved]);

  const guard = () => {
    if (!isAuthenticated) {
      onRequireLogin();
      return false;
    }
    return true;
  };

  const handleLike = () => {
    if (!guard()) return;
    const next = { ...state, liked: !state.liked };
    setState(next);
    persist(next);
  };

  const handleSave = () => {
    if (!guard()) return;
    const next = { ...state, saved: !state.saved };
    setState(next);
    persist(next);
  };

  const handleShare = async () => {
    if (!guard()) return;
    const shareUrl = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: post.title, text: post.excerpt, url: shareUrl });
      } else {
        await navigator.clipboard.writeText(shareUrl);
      }
      toast.success("Article shared successfully.");
    } catch {
      toast.error("Unable to share right now.");
    }
  };

  const handleComment = () => {
    if (!guard()) return;
    const text = draftComment.trim();
    if (!text) {
      toast.error("Write a comment before posting.");
      return;
    }
    const nextComment: ArticleComment = {
      id: `${Date.now()}`,
      name: userName,
      email: identity,
      text,
      date: "Just now",
      imageDataUrl: draftImageDataUrl,
      replies: [],
    };
    const next = { ...state, comments: [nextComment, ...state.comments] };
    setState(next);
    setDraftComment("");
    setDraftImageDataUrl(undefined);
    persist(next);
    toast.success("Comment posted.");
  };

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (!guard()) return;
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload an image file.");
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      toast.error("Image size should be under 4MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setDraftImageDataUrl(typeof reader.result === "string" ? reader.result : undefined);
    };
    reader.readAsDataURL(file);
  };

  const updateComments = (updater: (comments: ArticleComment[]) => ArticleComment[]) => {
    const next = { ...state, comments: updater(state.comments) };
    setState(next);
    persist(next);
  };

  const deleteComment = (commentId: string) => {
    if (!guard()) return;
    updateComments((comments) => comments.filter((comment) => comment.id !== commentId));
    toast.success("Comment deleted.");
  };

  const startEditComment = (comment: ArticleComment) => {
    if (!guard()) return;
    setEditingCommentId(comment.id);
    setEditingCommentText(comment.text);
  };

  const saveEditComment = () => {
    if (!editingCommentId) return;
    const text = editingCommentText.trim();
    if (!text) {
      toast.error("Comment cannot be empty.");
      return;
    }
    updateComments((comments) =>
      comments.map((comment) =>
        comment.id === editingCommentId ? { ...comment, text, date: "Edited just now" } : comment,
      ),
    );
    setEditingCommentId(null);
    setEditingCommentText("");
    toast.success("Comment updated.");
  };

  const postReply = (commentId: string) => {
    if (!guard()) return;
    const text = (replyDrafts[commentId] || "").trim();
    if (!text) {
      toast.error("Write a reply first.");
      return;
    }
    const reply: ArticleReply = {
      id: `reply-${Date.now()}`,
      name: userName,
      email: identity,
      text,
      date: "Just now",
    };
    updateComments((comments) =>
      comments.map((comment) =>
        comment.id === commentId ? { ...comment, replies: [...comment.replies, reply] } : comment,
      ),
    );
    setReplyDrafts((prev) => ({ ...prev, [commentId]: "" }));
    setActiveReplyForComment(null);
    toast.success("Reply posted.");
  };

  const deleteReply = (commentId: string, replyId: string) => {
    if (!guard()) return;
    updateComments((comments) =>
      comments.map((comment) =>
        comment.id === commentId
          ? { ...comment, replies: comment.replies.filter((reply) => reply.id !== replyId) }
          : comment,
      ),
    );
    toast.success("Reply deleted.");
  };

  const startEditReply = (commentId: string, reply: ArticleReply) => {
    if (!guard()) return;
    setEditingReplyKey(`${commentId}:${reply.id}`);
    setEditingReplyText(reply.text);
  };

  const saveEditReply = () => {
    if (!editingReplyKey) return;
    const text = editingReplyText.trim();
    if (!text) {
      toast.error("Reply cannot be empty.");
      return;
    }
    const [commentId, replyId] = editingReplyKey.split(":");
    updateComments((comments) =>
      comments.map((comment) =>
        comment.id === commentId
          ? {
              ...comment,
              replies: comment.replies.map((reply) =>
                reply.id === replyId ? { ...reply, text, date: "Edited just now" } : reply,
              ),
            }
          : comment,
      ),
    );
    setEditingReplyKey(null);
    setEditingReplyText("");
    toast.success("Reply updated.");
  };

  return (
    <div className="rounded-lg border border-border bg-card p-4 md:p-5">
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        <Button variant={state.liked ? "default" : "outline"} onClick={handleLike} className="justify-start gap-2">
          <Heart className="h-4 w-4" /> Like ({likeCount})
        </Button>
        <Button variant={state.saved ? "default" : "outline"} onClick={handleSave} className="justify-start gap-2">
          <Bookmark className="h-4 w-4" /> Save ({saveCount})
        </Button>
        <Button variant="outline" onClick={handleShare} className="justify-start gap-2">
          <Share2 className="h-4 w-4" /> Share
        </Button>
        <Button variant="outline" onClick={() => {
          if (!guard()) return;
          const box = document.getElementById("comment-box");
          box?.scrollIntoView({ behavior: "smooth", block: "center" });
        }} className="justify-start gap-2">
          <MessageCircle className="h-4 w-4" /> Comment ({state.comments.length})
        </Button>
      </div>

      <div id="comment-box" className="mt-4">
        {isAuthenticated ? (
          <div className="flex flex-col gap-3">
            <Textarea
              placeholder="Write a comment..."
              value={draftComment}
              onChange={(event) => setDraftComment(event.target.value)}
              rows={3}
              maxLength={280}
            />
            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground hover:bg-secondary">
                <ImagePlus className="h-4 w-4" />
                Upload image
                <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
              </label>
              {draftImageDataUrl && (
                <button
                  type="button"
                  className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
                  onClick={() => setDraftImageDataUrl(undefined)}
                >
                  <X className="h-4 w-4" /> Remove image
                </button>
              )}
            </div>
            {draftImageDataUrl && (
              <img
                src={draftImageDataUrl}
                alt="Comment upload preview"
                className="h-32 w-32 rounded-md border border-border object-cover"
              />
            )}
            <div>
              <Button onClick={handleComment}>Post Comment</Button>
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">
            Sign in to comment, like, save, and share this article.
          </p>
        )}

        <div className="mt-4 space-y-2">
          {state.comments.map((comment) => (
            <div key={comment.id} className="rounded-md border border-border bg-background p-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-foreground">{comment.name}</p>
                  <p className="text-xs text-muted-foreground">{comment.date}</p>
                </div>
                <div className="flex items-center gap-1">
                  {isAuthenticated && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() =>
                        setActiveReplyForComment((current) => (current === comment.id ? null : comment.id))
                      }
                    >
                      Reply
                    </Button>
                  )}
                  {identity && comment.email.toLowerCase() === identity && (
                    <>
                      <Button variant="ghost" size="sm" onClick={() => startEditComment(comment)}>
                        <Pencil className="h-4 w-4" />
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => deleteComment(comment.id)}>
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    </>
                  )}
                </div>
              </div>
              {editingCommentId === comment.id ? (
                <div className="mt-2 space-y-2">
                  <Textarea
                    value={editingCommentText}
                    onChange={(event) => setEditingCommentText(event.target.value)}
                    rows={2}
                    maxLength={280}
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={saveEditComment}>
                      Save
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingCommentId(null);
                        setEditingCommentText("");
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="mt-1 text-sm text-muted-foreground">{comment.text}</p>
              )}

              {comment.imageDataUrl && (
                <img
                  src={comment.imageDataUrl}
                  alt="Comment attachment"
                  className="mt-3 h-32 w-32 rounded-md border border-border object-cover"
                />
              )}

              {activeReplyForComment === comment.id && isAuthenticated && (
                <div className="mt-3 rounded-md border border-border bg-card p-3">
                  <Textarea
                    placeholder={`Reply to ${comment.name}...`}
                    value={replyDrafts[comment.id] || ""}
                    onChange={(event) =>
                      setReplyDrafts((prev) => ({ ...prev, [comment.id]: event.target.value }))
                    }
                    rows={2}
                    maxLength={280}
                  />
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" onClick={() => postReply(comment.id)}>
                      <Send className="h-4 w-4" /> Post Reply
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setActiveReplyForComment(null)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              {comment.replies.length > 0 && (
                <div className="mt-3 space-y-2 border-l border-border pl-3">
                  {comment.replies.map((reply) => {
                    const replyKey = `${comment.id}:${reply.id}`;
                    const isOwner = identity && reply.email.toLowerCase() === identity;
                    return (
                      <div key={reply.id} className="rounded-md border border-border bg-card p-2">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-xs font-medium text-foreground">{reply.name}</p>
                            <p className="text-[11px] text-muted-foreground">{reply.date}</p>
                          </div>
                          {isOwner && (
                            <div className="flex items-center gap-1">
                              <Button variant="ghost" size="icon" onClick={() => startEditReply(comment.id, reply)}>
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => deleteReply(comment.id, reply.id)}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          )}
                        </div>
                        {editingReplyKey === replyKey ? (
                          <div className="mt-2 space-y-2">
                            <Textarea
                              value={editingReplyText}
                              onChange={(event) => setEditingReplyText(event.target.value)}
                              rows={2}
                              maxLength={280}
                            />
                            <div className="flex gap-2">
                              <Button size="sm" onClick={saveEditReply}>
                                Save
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingReplyKey(null);
                                  setEditingReplyText("");
                                }}
                              >
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <p className="mt-1 text-xs text-muted-foreground">{reply.text}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function GalleryContent({ post }: { post: Post }) {
  // Simulate gallery with related images
  const images = [post.image, ...allPosts.filter(p => p.id !== post.id).slice(0, 5).map(p => p.image)];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <p className="mx-auto max-w-3xl text-lg text-muted-foreground mb-8">{post.excerpt}</p>
      <GalleryLightbox images={images} />
    </motion.div>
  );
}

function ListingContent({ post }: { post: Post }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="grid gap-10 lg:grid-cols-3"
    >
      <div className="lg:col-span-2 space-y-6">
        <div>
          <h2 className="font-display text-2xl text-foreground">About this listing</h2>
          <p className="mt-3 text-foreground/80 leading-relaxed">{post.excerpt}</p>
          <p className="mt-4 text-foreground/80 leading-relaxed">
            This is a premium listing curated by our editorial team. Each listing is hand-picked
            to ensure quality, authenticity, and an exceptional experience. Whether you're a
            seasoned explorer or discovering something new, this offering represents the best
            in its category.
          </p>
        </div>

        {post.price && (
          <div className="rounded-lg border border-border bg-secondary/50 p-6">
            <h3 className="font-display text-xl text-foreground">Pricing</h3>
            <p className="mt-2 text-3xl font-semibold text-primary">{post.price}</p>
            <p className="mt-1 text-sm text-muted-foreground">Prices may vary by season and availability.</p>
          </div>
        )}

        {post.location && (
          <div className="rounded-lg border border-border p-6">
            <h3 className="font-display text-xl text-foreground flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" /> Location
            </h3>
            <p className="mt-2 text-foreground/80">{post.location}</p>
            <div className="mt-4 h-48 rounded-lg bg-muted flex items-center justify-center text-muted-foreground">
              <Calendar className="mr-2 h-5 w-5" /> Map coming soon
            </div>
          </div>
        )}

        <div className="rounded-lg border border-border p-6">
          <h3 className="font-display text-xl text-foreground">Highlights</h3>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {["Curated by editors", "Verified listing", "Premium quality", "Fast response"].map((item) => (
              <li key={item} className="flex items-center gap-2 text-sm text-foreground/80">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="lg:col-span-1">
        <div className="sticky top-20">
          <ContactForm postTitle={post.title} />
        </div>
      </div>
    </motion.div>
  );
}
