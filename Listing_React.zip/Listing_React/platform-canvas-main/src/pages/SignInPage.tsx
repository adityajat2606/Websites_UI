import { FormEvent, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { Eye, EyeOff, ShieldCheck, Sparkles } from "lucide-react";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";

export default function SignInPage() {
  const navigate = useNavigate();
  const { signIn, isAuthenticated } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const canSubmit = useMemo(() => !!email.trim() && !!password.trim(), [email, password]);

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canSubmit) {
      toast.error("Please enter your email and password");
      return;
    }

    setIsSubmitting(true);
    const result = signIn(email, password, rememberMe);
    if (!result.ok) {
      toast.error(result.error || "Unable to sign in");
      setIsSubmitting(false);
      return;
    }

    toast.success("Welcome back");
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container grid gap-6 py-12 lg:grid-cols-2 lg:py-16">
        <section className="rounded-2xl border border-border bg-gradient-to-br from-secondary via-card to-background p-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-3 py-1 text-xs text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Trusted by 1.2M monthly readers
          </div>
          <h1 className="mt-5 font-display text-4xl leading-tight text-foreground">
            Sign in to manage your listings and editorial workspace
          </h1>
          <p className="mt-4 max-w-xl text-muted-foreground">
            Keep your dashboard, inquiries, and campaigns in one place with secure account access.
          </p>
          <div className="mt-8 space-y-3">
            {[
              "Real-time listing performance and audience engagement",
              "Saved drafts, scheduled posts, and editorial approvals",
              "Secure access with remembered sessions on trusted devices",
            ].map((item) => (
              <div key={item} className="flex items-start gap-3 rounded-lg border border-border bg-card px-4 py-3">
                <ShieldCheck className="mt-0.5 h-4 w-4 text-primary" />
                <p className="text-sm text-card-foreground">{item}</p>
              </div>
            ))}
          </div>
        </section>

        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-border bg-card p-8"
        >
          <h2 className="font-display text-3xl text-card-foreground">Welcome back</h2>
          <p className="mt-2 text-sm text-muted-foreground">Use your work account to continue.</p>

          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signin-email">Email</Label>
              <Input
                id="signin-email"
                type="email"
                placeholder="name@company.com"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="signin-password">Password</Label>
              <div className="relative">
                <Input
                  id="signin-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((value) => !value)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="remember-me"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked === true)}
                />
                <Label htmlFor="remember-me" className="text-sm text-muted-foreground">
                  Keep me signed in
                </Label>
              </div>
              <Link className="text-sm text-primary hover:underline" to="/contact">
                Forgot password?
              </Link>
            </div>

            <Button type="submit" className="w-full" disabled={!canSubmit || isSubmitting}>
              {isSubmitting ? "Signing in..." : "Sign In"}
            </Button>
          </form>

          <p className="mt-5 text-sm text-muted-foreground">
            New to Platform Canvas?{" "}
            <Link to="/get-started" className="text-primary hover:underline">
              Create an account
            </Link>
          </p>
        </motion.section>
      </main>
      <SiteFooter />
    </div>
  );
}
