import { motion } from "framer-motion";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { infoPagesContent, type InfoPageKey } from "@/data/site-content";

interface InfoPageProps {
  pageKey: InfoPageKey;
}

export default function InfoPage({ pageKey }: InfoPageProps) {
  const content = infoPagesContent[pageKey];

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container py-10">
        <motion.h1
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-4xl text-foreground md:text-5xl"
        >
          {content.title}
        </motion.h1>
        <p className="mt-3 max-w-3xl text-muted-foreground">{content.subtitle}</p>

        <section className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {content.sections.map((section) => (
            <article key={section.heading} className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-card-foreground">{section.heading}</h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{section.text}</p>
            </article>
          ))}
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
