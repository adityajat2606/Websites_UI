import { FormEvent, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { contactPageContent } from "@/data/site-content";

export default function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [message, setMessage] = useState("");

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error("Please complete name, email, and message.");
      return;
    }

    toast.success("Thanks. Our team will contact you shortly.");
    setName("");
    setEmail("");
    setCompany("");
    setMessage("");
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container py-10">
        <motion.h1
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-4xl text-foreground md:text-5xl"
        >
          {contactPageContent.title}
        </motion.h1>
        <p className="mt-3 max-w-3xl text-muted-foreground">{contactPageContent.subtitle}</p>

        <section className="mt-8 grid gap-4 md:grid-cols-3">
          {contactPageContent.offices.map((office) => (
            <article key={office.city} className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-card-foreground">{office.city}</h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{office.address}</p>
              <p className="mt-3 text-sm text-muted-foreground">{office.phone}</p>
              <p className="text-sm text-primary">{office.email}</p>
            </article>
          ))}
        </section>

        <section className="mt-10 rounded-xl border border-border bg-card p-6 md:p-8">
          <h2 className="font-display text-2xl text-card-foreground">Send Us a Message</h2>
          <form className="mt-5 grid gap-4" onSubmit={onSubmit}>
            <div className="grid gap-4 md:grid-cols-2">
              <Input placeholder="Full name" value={name} onChange={(event) => setName(event.target.value)} />
              <Input
                type="email"
                placeholder="Work email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>
            <Input
              placeholder="Company (optional)"
              value={company}
              onChange={(event) => setCompany(event.target.value)}
            />
            <Textarea
              rows={6}
              placeholder="How can we help?"
              value={message}
              onChange={(event) => setMessage(event.target.value)}
            />
            <div>
              <Button type="submit">Submit Inquiry</Button>
            </div>
          </form>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
