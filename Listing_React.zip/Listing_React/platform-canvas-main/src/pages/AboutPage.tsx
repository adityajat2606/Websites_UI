import { motion } from "framer-motion";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { aboutPageContent } from "@/data/site-content";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container py-10">
        <motion.h1
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-4xl text-foreground md:text-5xl"
        >
          {aboutPageContent.title}
        </motion.h1>
        <p className="mt-3 max-w-3xl text-muted-foreground">{aboutPageContent.subtitle}</p>

        <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {aboutPageContent.stats.map((stat) => (
            <article key={stat.label} className="rounded-xl border border-border bg-card p-5">
              <p className="text-2xl font-semibold text-card-foreground">{stat.value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
            </article>
          ))}
        </section>

        <section className="mt-10">
          <h2 className="font-display text-2xl text-foreground">Our Values</h2>
          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            {aboutPageContent.values.map((value) => (
              <article key={value.title} className="rounded-xl border border-border bg-card p-6">
                <h3 className="text-lg font-semibold text-card-foreground">{value.title}</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{value.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="mt-10">
          <h2 className="font-display text-2xl text-foreground">Leadership</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {aboutPageContent.leadership.map((leader) => (
              <article key={leader.name} className="rounded-xl border border-border bg-card p-6">
                <h3 className="text-lg font-semibold text-card-foreground">{leader.name}</h3>
                <p className="text-sm text-primary">{leader.role}</p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{leader.bio}</p>
              </article>
            ))}
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
