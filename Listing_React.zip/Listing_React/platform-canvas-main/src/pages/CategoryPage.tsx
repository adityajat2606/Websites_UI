import { useParams, useNavigate, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import ListingCard from "@/components/ListingCard";
import { featuredPosts, latestListings, trendingPosts } from "@/data/mock-data";
import type { PostType } from "@/data/mock-data";

const allPosts = [...featuredPosts, ...latestListings, ...trendingPosts];

const categoryLabels: Record<string, string> = {
  articles: "Articles",
  galleries: "Galleries",
  listings: "Listings",
};

const categoryToType: Record<string, PostType | undefined> = {
  articles: "article",
  galleries: "gallery",
  listings: "listing",
};

export default function CategoryPage() {
  const { category } = useParams<{ category: string }>();
  const navigate = useNavigate();
  const cat = category?.toLowerCase() || "articles";
  if (cat === "trending" || cat === "discover") {
    return <Navigate to="/" replace />;
  }
  const label = categoryLabels[cat] || "Category";
  const type = categoryToType[cat];

  let filtered = type ? allPosts.filter((p) => p.type === type) : allPosts;
  // deduplicate
  filtered = Array.from(new Map(filtered.map((p) => [p.id, p])).values());

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container py-10">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>

        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-4xl text-foreground md:text-5xl"
        >
          {label}
        </motion.h1>
        <p className="mt-2 text-muted-foreground">{filtered.length} posts</p>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((post, i) => (
            <ListingCard key={post.id} post={post} index={i} />
          ))}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
