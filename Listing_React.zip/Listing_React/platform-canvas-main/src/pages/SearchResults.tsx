import { useSearchParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Search } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import ListingCard from "@/components/ListingCard";
import { featuredPosts, latestListings, trendingPosts } from "@/data/mock-data";

const allPosts = [...featuredPosts, ...latestListings, ...trendingPosts];

export default function SearchResults() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const q = params.get("q") || "";
  const [query, setQuery] = useState(q);

  const results = allPosts.filter(
    (p) =>
      p.title.toLowerCase().includes(q.toLowerCase()) ||
      p.excerpt.toLowerCase().includes(q.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(q.toLowerCase()))
  );

  // Remove duplicates by id
  const unique = Array.from(new Map(results.map((p) => [p.id, p])).values());

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container py-10">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Button>

        <form onSubmit={handleSearch} className="relative mb-8 max-w-xl">
          <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search…"
            className="h-12 rounded-full pl-12 pr-6"
          />
        </form>

        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-3xl text-foreground md:text-4xl"
        >
          {q ? `Results for "${q}"` : "All Posts"}
        </motion.h1>
        <p className="mt-2 text-muted-foreground">
          {unique.length} {unique.length === 1 ? "result" : "results"} found
        </p>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {unique.map((post, i) => (
            <ListingCard key={post.id} post={post} index={i} />
          ))}
        </div>

        {unique.length === 0 && (
          <div className="py-20 text-center">
            <p className="text-lg text-muted-foreground">No results found. Try a different search term.</p>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
