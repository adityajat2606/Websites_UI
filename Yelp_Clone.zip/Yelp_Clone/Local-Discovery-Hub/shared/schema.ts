import { z } from "zod";

export const userSchema = z.object({
  id: z.number().int(),
  username: z.string(),
  avatar: z.string().nullable().optional(),
  bio: z.string().nullable().optional(),
});
export type User = z.infer<typeof userSchema>;

export const categorySchema = z.object({
  id: z.number().int(),
  name: z.string(),
  icon: z.string(),
});
export type Category = z.infer<typeof categorySchema>;

export const businessSchema = z.object({
  id: z.number().int(),
  name: z.string(),
  image: z.string(),
  rating: z.number().min(0).max(5),
  reviewCount: z.number().int().min(0),
  priceRange: z.string(),
  categoryId: z.number().int(),
  location: z.string(),
  address: z.string(),
  hours: z.string(),
  contact: z.string(),
  description: z.string().nullable().optional(),
  images: z.array(z.string()).nullable().optional(),
});
export type Business = z.infer<typeof businessSchema>;

export const reviewSchema = z.object({
  id: z.number().int(),
  businessId: z.number().int(),
  userId: z.number().int(),
  rating: z.number().min(1).max(5),
  text: z.string(),
  images: z.array(z.string()).nullable().optional(),
  date: z.union([z.string(), z.date()]).nullable().optional(),
});
export type Review = z.infer<typeof reviewSchema>;

export const savedBusinessSchema = z.object({
  id: z.number().int(),
  userId: z.number().int(),
  businessId: z.number().int(),
});
export type SavedBusiness = z.infer<typeof savedBusinessSchema>;

export const insertReviewSchema = z.object({
  businessId: z.number().int(),
  userId: z.number().int(),
  rating: z.number().min(1).max(5),
  text: z.string().min(1),
  images: z.array(z.string()).optional(),
});
export type InsertReview = z.infer<typeof insertReviewSchema>;

export const insertSavedBusinessSchema = z.object({
  userId: z.number().int(),
  businessId: z.number().int(),
});
export type InsertSavedBusiness = z.infer<typeof insertSavedBusinessSchema>;
