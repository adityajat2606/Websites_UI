import { z } from "zod";
import {
  businessSchema,
  categorySchema,
  reviewSchema,
  savedBusinessSchema,
  userSchema,
  insertReviewSchema,
  insertSavedBusinessSchema,
} from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  businesses: {
    list: {
      method: 'GET' as const,
      path: '/api/businesses' as const,
      input: z.object({
        query: z.string().optional(),
        location: z.string().optional(),
        categoryId: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(businessSchema),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/businesses/:id' as const,
      responses: {
        200: businessSchema,
        404: errorSchemas.notFound,
      },
    },
    reviews: {
      method: 'GET' as const,
      path: '/api/businesses/:id/reviews' as const,
      responses: {
        200: z.array(
          z.object({
            review: reviewSchema,
            user: userSchema,
          }),
        ),
        404: errorSchemas.notFound,
      },
    }
  },
  categories: {
    list: {
      method: 'GET' as const,
      path: '/api/categories' as const,
      responses: {
        200: z.array(categorySchema),
      },
    }
  },
  users: {
    get: {
      method: 'GET' as const,
      path: '/api/users/:id' as const,
      responses: {
        200: userSchema,
        404: errorSchemas.notFound,
      },
    }
  },
  reviews: {
    create: {
      method: 'POST' as const,
      path: '/api/reviews' as const,
      input: insertReviewSchema,
      responses: {
        201: reviewSchema,
        400: errorSchemas.validation,
      },
    },
  },
  saved: {
    list: {
      method: 'GET' as const,
      path: '/api/users/:userId/saved' as const,
      responses: {
        200: z.array(businessSchema),
      },
    },
    add: {
      method: 'POST' as const,
      path: '/api/saved' as const,
      input: insertSavedBusinessSchema,
      responses: {
        201: savedBusinessSchema,
        400: errorSchemas.validation,
      },
    },
    remove: {
      method: 'DELETE' as const,
      path: '/api/saved/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
