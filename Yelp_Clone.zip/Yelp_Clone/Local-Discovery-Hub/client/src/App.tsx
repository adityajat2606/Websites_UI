import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

// Pages
import Home from "./pages/Home";
import SearchResults from "./pages/SearchResults";
import BusinessDetails from "./pages/BusinessDetails";
import WriteReview from "./pages/WriteReview";
import UserProfile from "./pages/UserProfile";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/search" component={SearchResults} />
      <Route path="/business/:id" component={BusinessDetails} />
      <Route path="/write-review" component={WriteReview} />
      <Route path="/user/:id" component={UserProfile} />
      {/* Alias for current user profile */}
      <Route path="/saved" component={UserProfile} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
