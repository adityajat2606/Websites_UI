import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { getBusiness, getBusinessReviews, listBusinesses } from "@/lib/mockApi";

export function useBusinesses(params?: { query?: string; location?: string; categoryId?: string }) {
  return useQuery({
    queryKey: [api.businesses.list.path, params],
    queryFn: async () => {
      return api.businesses.list.responses[200].parse(await listBusinesses(params));
    },
  });
}

export function useBusiness(id: number) {
  return useQuery({
    queryKey: [api.businesses.get.path, id],
    queryFn: async () => {
      const business = await getBusiness(id);
      if (!business) return null;
      return api.businesses.get.responses[200].parse(business);
    },
    enabled: !!id,
  });
}

export function useBusinessReviews(id: number) {
  return useQuery({
    queryKey: [api.businesses.reviews.path, id],
    queryFn: async () => {
      return api.businesses.reviews.responses[200].parse(await getBusinessReviews(id));
    },
    enabled: !!id,
  });
}
