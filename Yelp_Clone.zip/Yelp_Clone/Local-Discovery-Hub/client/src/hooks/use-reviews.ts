import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import type { InsertReview } from "@shared/schema";
import { createReview } from "@/lib/mockApi";

export function useCreateReview() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: InsertReview) => {
      return api.reviews.create.responses[201].parse(await createReview(data));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.businesses.reviews.path, variables.businessId] });
      queryClient.invalidateQueries({ queryKey: [api.businesses.get.path, variables.businessId] });
    },
  });
}
