import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertSavedBusiness } from "@shared/schema";
import {
  addSavedBusiness,
  getUser,
  listSavedBusinessesByUser,
  removeSavedBusiness,
} from "@/lib/mockApi";

export function useUser(id: number) {
  return useQuery({
    queryKey: [api.users.get.path, id],
    queryFn: async () => {
      const user = await getUser(id);
      if (!user) return null;
      return api.users.get.responses[200].parse(user);
    },
    enabled: !!id,
  });
}

export function useSavedBusinesses(userId: number) {
  return useQuery({
    queryKey: [api.saved.list.path, userId],
    queryFn: async () => {
      return api.saved.list.responses[200].parse(await listSavedBusinessesByUser(userId));
    },
    enabled: !!userId,
  });
}

export function useToggleSavedBusiness() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ businessId, userId, isSaved, savedId }: { businessId: number, userId: number, isSaved: boolean, savedId?: number }) => {
      if (isSaved && savedId) {
        await removeSavedBusiness(savedId);
        return null;
      } else {
        const data: InsertSavedBusiness = { businessId, userId };
        return api.saved.add.responses[201].parse(await addSavedBusiness(data));
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.saved.list.path, variables.userId] });
    },
  });
}
