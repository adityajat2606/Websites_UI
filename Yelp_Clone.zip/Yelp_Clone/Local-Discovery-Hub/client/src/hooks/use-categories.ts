import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { listCategories } from "@/lib/mockApi";

export function useCategories() {
  return useQuery({
    queryKey: [api.categories.list.path],
    queryFn: async () => {
      return api.categories.list.responses[200].parse(await listCategories());
    },
  });
}
