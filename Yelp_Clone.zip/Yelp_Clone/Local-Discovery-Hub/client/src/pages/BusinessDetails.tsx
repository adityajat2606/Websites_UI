import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useBusiness, useBusinessReviews } from "@/hooks/use-businesses";
import { useParams, Link } from "wouter";
import { RatingStars } from "@/components/RatingStars";
import { ReviewCard } from "@/components/ReviewCard";
import { 
  MapPin, Clock, Phone, Globe, Star, FolderHeart, 
  Share, Image as ImageIcon, Camera, ArrowRight, CheckCircle2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

export default function BusinessDetails() {
  const { id } = useParams<{ id: string }>();
  const businessId = parseInt(id, 10);
  
  const { data: business, isLoading: loadingBiz } = useBusiness(businessId);
  const { data: reviewsData, isLoading: loadingReviews } = useBusinessReviews(businessId);

  if (loadingBiz) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <div className="pt-20"><Skeleton className="w-full h-[400px]" /></div>
        <div className="max-w-6xl mx-auto w-full p-8"><Skeleton className="w-1/2 h-12 mb-4" /></div>
      </div>
    );
  }

  if (!business) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <div className="flex-1 flex items-center justify-center flex-col pt-20">
          <h1 className="text-4xl font-bold mb-4">Business Not Found</h1>
          <Button asChild><Link href="/">Go Home</Link></Button>
        </div>
      </div>
    );
  }

  const galleryImages = business.images && business.images.length > 0 
    ? business.images 
    : [business.image, "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800", "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800"];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      {/* Photo Gallery Header */}
      <div className="pt-20 bg-secondary relative">
        <div className="grid grid-cols-4 grid-rows-2 h-[40vh] min-h-[300px] max-h-[500px] gap-1 max-w-[1920px] mx-auto p-1">
          <div className="col-span-2 row-span-2 relative overflow-hidden rounded-l-2xl group cursor-pointer">
            <img src={galleryImages[0]} alt={business.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
            <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors"></div>
          </div>
          <div className="col-span-1 row-span-1 relative overflow-hidden group cursor-pointer">
            <img src={galleryImages[1]} alt="Gallery" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
          </div>
          <div className="col-span-1 row-span-1 relative overflow-hidden rounded-tr-2xl group cursor-pointer">
            <img src={galleryImages[2] || galleryImages[0]} alt="Gallery" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
          </div>
          <div className="col-span-2 row-span-1 relative overflow-hidden rounded-br-2xl group cursor-pointer">
            <img src={galleryImages[1] || galleryImages[0]} alt="Gallery" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
            <div className="absolute bottom-4 right-4">
              <Button variant="secondary" className="rounded-full bg-white/90 backdrop-blur hover:bg-white text-foreground shadow-lg">
                <ImageIcon className="w-4 h-4 mr-2" /> View All Photos
              </Button>
            </div>
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <div className="flex flex-col lg:flex-row gap-12">
          
          {/* Main Content Column */}
          <div className="flex-1">
            <div className="mb-8">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h1 className="text-4xl sm:text-5xl font-display font-bold text-foreground mb-3">{business.name}</h1>
                  <div className="flex flex-wrap items-center gap-4 text-lg">
                    <div className="flex items-center">
                      <RatingStars rating={business.rating} size="lg" className="mr-2" />
                      <span className="font-bold">{business.rating.toFixed(1)}</span>
                      <span className="text-muted-foreground ml-1">({business.reviewCount} reviews)</span>
                    </div>
                    <span className="text-muted-foreground">•</span>
                    <span className="font-medium text-green-600 flex items-center bg-green-50 px-2 py-0.5 rounded-md"><CheckCircle2 className="w-4 h-4 mr-1" /> Claimed</span>
                    <span className="text-muted-foreground">•</span>
                    <span className="font-medium">{business.priceRange}</span>
                  </div>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                <Button size="lg" className="rounded-full px-8 shadow-md hover:shadow-lg shadow-primary/20 text-md font-semibold" asChild>
                  <Link href={`/write-review?businessId=${business.id}`}>
                    <Star className="w-5 h-5 mr-2 fill-current" /> Write a Review
                  </Link>
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="rounded-full px-6 font-medium"
                  onClick={() => window.location.href = `/write-review?businessId=${business.id}`}
                >
                  <Camera className="w-5 h-5 mr-2" /> Add Photo
                </Button>
                <div className="flex gap-2 ml-auto">
                  <Button 
                    size="icon" 
                    variant="outline" 
                    className="rounded-full w-12 h-12"
                    onClick={() => {
                      const { useToast } = require("@/hooks/use-toast");
                      const { toast } = useToast();
                      toast({ title: "Saved!", description: `${business.name} has been added to your favorites.` });
                    }}
                  >
                    <FolderHeart className="w-5 h-5" />
                  </Button>
                  <Button 
                    size="icon" 
                    variant="outline" 
                    className="rounded-full w-12 h-12"
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.href);
                      alert("Link copied to clipboard!");
                    }}
                  >
                    <Share className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </div>

            <hr className="border-border my-8" />

            <div className="space-y-12">
              {business.description && (
                <section>
                  <h2 className="text-2xl font-display font-bold mb-4">About the Business</h2>
                  <p className="text-muted-foreground text-lg leading-relaxed whitespace-pre-wrap">
                    {business.description}
                  </p>
                </section>
              )}

              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-display font-bold">Recommended Reviews</h2>
                  <SelectSort />
                </div>
                
                {loadingReviews ? (
                  <div className="space-y-8">
                    {[1,2,3].map(i => <div key={i} className="h-40 bg-muted animate-pulse rounded-xl"></div>)}
                  </div>
                ) : reviewsData && reviewsData.length > 0 ? (
                  <div className="space-y-2">
                    {reviewsData.map((item, i) => (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        key={item.review.id}
                      >
                        <ReviewCard review={item.review} user={item.user} />
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-secondary/30 rounded-2xl border border-border border-dashed">
                    <Star className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-semibold text-foreground mb-1">No reviews yet</h3>
                    <p className="text-muted-foreground mb-4">Be the first to share your experience!</p>
                    <Button variant="outline" asChild>
                      <Link href={`/write-review?businessId=${business.id}`}>Write a Review</Link>
                    </Button>
                  </div>
                )}
              </section>
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-full lg:w-[380px] flex-shrink-0">
            <div className="sticky top-24 space-y-6">
              
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                <h3 className="font-display font-bold text-xl mb-6">Info & Location</h3>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <MapPin className="w-6 h-6 text-primary mt-0.5 mr-4 shrink-0" />
                    <div>
                      <p className="font-medium text-foreground">{business.address}</p>
                      <p className="text-muted-foreground">{business.location}</p>
                      <button className="text-primary hover:underline text-sm font-medium mt-1">Get Directions</button>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Clock className="w-6 h-6 text-muted-foreground mt-0.5 mr-4 shrink-0" />
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-1">
                        <p className="font-medium text-foreground">Hours</p>
                        <Badge variant="outline" className="text-green-600 bg-green-50 border-green-200">Open Now</Badge>
                      </div>
                      <p className="text-muted-foreground">{business.hours}</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Phone className="w-6 h-6 text-muted-foreground mr-4 shrink-0" />
                    <p className="font-medium text-foreground">{business.contact}</p>
                  </div>

                  <div className="flex items-center">
                    <Globe className="w-6 h-6 text-muted-foreground mr-4 shrink-0" />
                    <a href="#" className="font-medium text-primary hover:underline truncate">
                      {business.name.toLowerCase().replace(/\s+/g, '')}.com
                    </a>
                  </div>
                </div>
              </div>

              {/* Mini Map Placeholder */}
              <div className="bg-secondary rounded-2xl h-48 border border-border overflow-hidden relative flex items-center justify-center group cursor-pointer">
                <div className="absolute inset-0 opacity-50" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(0,0,0,0.1) 1px, transparent 0)', backgroundSize: '16px 16px' }}></div>
                <div className="text-center relative z-10">
                  <div className="w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-2 shadow-lg group-hover:scale-110 transition-transform">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <span className="font-semibold text-sm bg-background/90 px-3 py-1.5 rounded-full shadow-sm">View on Map</span>
                </div>
              </div>
              
            </div>
          </div>

        </div>
      </main>
      
      <Footer />
    </div>
  );
}

// Simple internal component for the dropdown to avoid breaking file structure
function SelectSort() {
  return (
    <select className="bg-background border border-border rounded-lg px-3 py-2 text-sm font-medium outline-none focus:ring-2 focus:ring-primary/20">
      <option>Sort by: Newest</option>
      <option>Sort by: Highest Rated</option>
      <option>Sort by: Lowest Rated</option>
    </select>
  )
}
