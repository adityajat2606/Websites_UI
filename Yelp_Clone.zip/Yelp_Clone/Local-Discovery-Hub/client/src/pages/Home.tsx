import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { SearchBar } from "@/components/SearchBar";
import { BusinessCard } from "@/components/BusinessCard";
import { useBusinesses, useCategories } from "@/hooks/use-businesses";
import { useCategories as useCats } from "@/hooks/use-categories";
import { motion } from "framer-motion";
import { Link } from "wouter";
import * as Icons from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { data: businesses, isLoading: loadingBiz } = useBusinesses();
  const { data: categories, isLoading: loadingCats } = useCats();

  // Pick top 4 for featured
  const featured = businesses?.slice(0, 4) || [];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative h-[65vh] min-h-[500px] flex items-center justify-center pt-20 overflow-hidden">
        {/* landing page hero bustling city street at night */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1449844908441-8829872d2607?w=1920&q=80" 
            alt="City lifestyle" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-background"></div>
        </div>
        
        <div className="relative z-10 w-full max-w-5xl mx-auto px-4 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-6 drop-shadow-lg"
          >
            Discover your next <span className="text-primary italic px-2">favorite</span> place.
          </motion.h1>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <SearchBar variant="hero" />
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-8 flex flex-wrap justify-center gap-3"
          >
            <span className="text-white/80 font-medium">Trending:</span>
            {['Sushi', 'Cocktails', 'Plumbers', 'Delivery'].map((term) => (
              <Link key={term} href={`/search?query=${term.toLowerCase()}`} className="text-white hover:text-primary font-medium hover:underline transition-colors">
                {term}
              </Link>
            ))}
          </motion.div>
        </div>
      </section>

      <main className="flex-1 bg-background relative z-20">
        {/* Categories Section */}
        <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-display font-bold text-foreground mb-4">Browse by Category</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">Explore the best local businesses in your area, categorized for your convenience.</p>
          </div>
          
          {loadingCats ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-32 rounded-2xl bg-muted animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {categories?.slice(0, 6).map((category, i) => {
                const IconComponent = (Icons as any)[category.icon] || Icons.MapPin;
                return (
                  <motion.div
                    key={category.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.05 }}
                  >
                    <Link 
                      href={`/search?categoryId=${category.id}`}
                      className="group flex flex-col items-center justify-center p-6 bg-card rounded-2xl border border-border hover:border-primary hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer h-full"
                    >
                      <div className="w-14 h-14 bg-secondary group-hover:bg-primary/10 rounded-full flex items-center justify-center mb-3 transition-colors">
                        <IconComponent className="w-7 h-7 text-foreground group-hover:text-primary transition-colors" />
                      </div>
                      <span className="font-semibold text-foreground group-hover:text-primary text-center">
                        {category.name}
                      </span>
                    </Link>
                  </motion.div>
                );
              })}
            </div>
          )}
        </section>

        {/* Featured Section */}
        <section className="py-16 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-end mb-10">
              <div>
                <h2 className="text-3xl font-display font-bold text-foreground mb-2">Featured Businesses</h2>
                <p className="text-muted-foreground text-lg">Hand-picked spots we think you'll love.</p>
              </div>
              <Button variant="ghost" className="hidden sm:flex hover:bg-primary/5 hover:text-primary" asChild>
                <Link href="/search">See all <Icons.ArrowRight className="w-4 h-4 ml-2" /></Link>
              </Button>
            </div>

            {loadingBiz ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-80 rounded-2xl bg-muted animate-pulse"></div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {featured.map((biz, i) => (
                  <BusinessCard key={biz.id} business={biz} index={i} featured={i === 0} />
                ))}
              </div>
            )}
            
            <Button variant="outline" className="w-full mt-8 sm:hidden py-6 rounded-xl" asChild>
              <Link href="/search">See all businesses</Link>
            </Button>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary rounded-[2.5rem] overflow-hidden relative shadow-2xl">
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent mix-blend-overlay"></div>
            <div className="relative z-10 px-6 py-16 md:py-20 md:px-16 lg:px-24 flex flex-col md:flex-row items-center gap-12">
              <div className="flex-1 text-center md:text-left">
                <h2 className="text-3xl md:text-5xl font-display font-bold text-primary-foreground mb-6">
                  Own a local business?
                </h2>
                <p className="text-primary-foreground/90 text-lg md:text-xl mb-8 max-w-xl">
                  Claim your free Discover page today to connect with millions of potential customers searching for your services.
                </p>
                <Button 
                  size="lg" 
                  variant="secondary" 
                  className="rounded-full px-8 py-6 text-lg font-bold text-primary hover:bg-white hover:scale-105 transition-transform shadow-xl"
                  onClick={() => window.location.href = "/search"}
                >
                  Claim Your Business
                </Button>
              </div>
              <div className="flex-1 w-full max-w-md relative">
                {/* placeholder for an app mockup or illustration */}
                <div className="aspect-square bg-white/20 rounded-full blur-3xl absolute inset-0 transform -translate-y-10 translate-x-10"></div>
                <img 
                  src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80" 
                  alt="Business Owner" 
                  className="rounded-3xl shadow-2xl relative z-10 border-4 border-white/20 -rotate-3 hover:rotate-0 transition-transform duration-500 object-cover aspect-square"
                />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
