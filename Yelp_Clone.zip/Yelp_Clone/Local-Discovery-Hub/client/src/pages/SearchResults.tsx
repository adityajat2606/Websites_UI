import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { BusinessCard } from "@/components/BusinessCard";
import { useBusinesses } from "@/hooks/use-businesses";
import { useSearch } from "wouter";
import { useState, useMemo } from "react";
import { Map, SlidersHorizontal, Filter, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

export default function SearchResults() {
  const searchString = useSearch();
  const searchParams = useMemo(() => new URLSearchParams(searchString), [searchString]);
  
  const query = searchParams.get("query") || "";
  const location = searchParams.get("location") || "";
  const categoryId = searchParams.get("categoryId") || "";

  const { data: businesses, isLoading } = useBusinesses({ query, location, categoryId });
  const [showMap, setShowMap] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 pt-24 max-w-[1600px] mx-auto w-full px-4 sm:px-6 lg:px-8 flex flex-col h-full">
        {/* Header Area */}
        <div className="py-6 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-display font-bold text-foreground">
              {query ? `Results for "${query}"` : "Best Local Businesses"}
              {location && <span className="text-muted-foreground font-normal"> in {location}</span>}
            </h1>
            <p className="text-muted-foreground mt-1">
              Showing {businesses?.length || 0} results
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="outline" className="rounded-full shadow-sm">
              <Filter className="w-4 h-4 mr-2" /> Filters
            </Button>
            <Select defaultValue="recommended">
              <SelectTrigger className="w-[160px] rounded-full shadow-sm">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recommended">Recommended</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="reviews">Most Reviewed</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant={showMap ? "default" : "outline"} 
              className="rounded-full shadow-sm lg:hidden"
              onClick={() => setShowMap(!showMap)}
            >
              <Map className="w-4 h-4 mr-2" /> {showMap ? "List" : "Map"}
            </Button>
          </div>
        </div>

        <div className="flex-1 flex gap-8 py-8 relative">
          {/* Filters Sidebar (Desktop) */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-32 space-y-8">
              <div>
                <h3 className="font-bold text-lg mb-4 flex items-center"><SlidersHorizontal className="w-5 h-5 mr-2" /> Filters</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-sm text-foreground mb-3">Price</h4>
                    <div className="flex rounded-lg overflow-hidden border border-border">
                      {['$', '$$', '$$$', '$$$$'].map((price, i) => (
                        <button key={price} className={`flex-1 py-2 text-sm font-medium border-r border-border last:border-0 hover:bg-secondary transition-colors ${i === 1 ? 'bg-secondary text-primary' : 'bg-background text-muted-foreground'}`}>
                          {price}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="pt-4 border-t border-border">
                    <h4 className="font-medium text-sm text-foreground mb-3">Features</h4>
                    <div className="space-y-2">
                      {['Open Now', 'Offers Delivery', 'Good for Groups', 'Outdoor Seating'].map(f => (
                        <label key={f} className="flex items-center gap-3 cursor-pointer group">
                          <input type="checkbox" className="w-4 h-4 rounded border-border text-primary focus:ring-primary/20 cursor-pointer" />
                          <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">{f}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <div className={`flex-1 ${showMap ? 'hidden lg:block' : 'block'}`}>
            {isLoading ? (
              <div className="space-y-6">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-48 rounded-2xl bg-muted animate-pulse"></div>
                ))}
              </div>
            ) : businesses?.length === 0 ? (
              <div className="text-center py-20 bg-secondary/30 rounded-3xl border border-border border-dashed">
                <div className="w-20 h-20 bg-background rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                  <Map className="w-10 h-10 text-muted-foreground" />
                </div>
                <h3 className="text-2xl font-display font-bold text-foreground mb-2">No results found</h3>
                <p className="text-muted-foreground max-w-md mx-auto">Try adjusting your search or filters to find what you're looking for.</p>
                <Button className="mt-6 rounded-full" onClick={() => window.history.back()}>Go Back</Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {businesses?.map((biz, i) => (
                  <BusinessCard key={biz.id} business={biz} index={i} />
                ))}
              </div>
            )}
          </div>

          {/* Map (Desktop fixed right, Mobile toggled) */}
          <div className={`lg:w-[400px] xl:w-[500px] flex-shrink-0 ${showMap ? 'block w-full h-[600px]' : 'hidden lg:block'}`}>
            <div className="sticky top-24 w-full h-[calc(100vh-8rem)] bg-secondary rounded-3xl overflow-hidden border border-border shadow-inner relative">
              {/* Fake Map Background */}
              <div className="absolute inset-0 opacity-50" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(0,0,0,0.1) 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
              <div className="absolute inset-0 flex items-center justify-center text-muted-foreground flex-col bg-card/40 backdrop-blur-[2px]">
                <Map className="w-12 h-12 mb-3 opacity-20" />
                <span className="font-medium text-sm bg-background/80 px-4 py-2 rounded-full shadow-sm">Interactive Map</span>
              </div>
              
              {/* Fake Map Pins */}
              {!isLoading && businesses?.map((biz, i) => (
                <div 
                  key={biz.id} 
                  className="absolute w-8 h-8 -ml-4 -mt-8 flex items-center justify-center transform hover:scale-125 transition-transform cursor-pointer group"
                  style={{ top: `${20 + (i * 15) % 60}%`, left: `${20 + (i * 25) % 60}%` }}
                >
                  <MapPin className="w-8 h-8 text-primary fill-primary/20 drop-shadow-md" />
                  <div className="absolute bottom-full mb-1 bg-foreground text-background text-xs font-bold px-2 py-1 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                    {biz.name}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
