import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useUser, useSavedBusinesses } from "@/hooks/use-users";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BusinessCard } from "@/components/BusinessCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Calendar, Edit3, Camera, Settings, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function UserProfile() {
  // Hardcode user ID 1 for mock purposes
  const userId = 1;
  const { data: user, isLoading: loadingUser } = useUser(userId);
  const { data: savedBiz, isLoading: loadingSaved } = useSavedBusinesses(userId);

  if (loadingUser) {
    return <div className="min-h-screen bg-background"><Navbar /><div className="pt-32 text-center">Loading...</div></div>;
  }

  if (!user) return <div className="min-h-screen bg-background"><Navbar /><div className="pt-32 text-center">User not found</div></div>;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      {/* Profile Header */}
      <div className="bg-secondary/50 pt-28 pb-12 border-b border-border relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-48 bg-primary/10 rounded-b-[100%] scale-150 blur-3xl transform -translate-y-1/2"></div>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 sm:gap-10 text-center sm:text-left">
            <Avatar className="w-32 h-32 sm:w-40 sm:h-40 border-4 border-background shadow-xl">
              {user.avatar ? <AvatarImage src={user.avatar} /> : null}
              <AvatarFallback className="text-4xl bg-primary text-primary-foreground font-display font-bold">
                {user.username.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 mt-2">
              <h1 className="text-3xl sm:text-4xl font-display font-bold text-foreground mb-2">{user.username}</h1>
              <p className="text-muted-foreground flex items-center justify-center sm:justify-start gap-2 mb-4">
                <MapPin className="w-4 h-4" /> San Francisco, CA
                <span className="mx-2">•</span>
                <Calendar className="w-4 h-4" /> Joined Oct 2023
              </p>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-6">
                <div className="text-center sm:text-left">
                  <div className="flex items-center gap-1.5 text-orange-500 font-bold text-lg"><Star className="w-5 h-5 fill-current" /> 12</div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Reviews</div>
                </div>
                <div className="text-center sm:text-left">
                  <div className="flex items-center gap-1.5 text-blue-500 font-bold text-lg"><Camera className="w-5 h-5" /> 45</div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Photos</div>
                </div>
              </div>
            </div>

            <div className="flex sm:flex-col gap-3">
              <Button 
                className="rounded-full shadow-sm"
                onClick={() => alert("Profile editing coming soon!")}
              >
                <Edit3 className="w-4 h-4 mr-2" /> Edit Profile
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="rounded-full w-10 h-10 shrink-0"
                onClick={() => alert("Settings coming soon!")}
              >
                <Settings className="w-5 h-5 text-muted-foreground" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 py-10">
        <Tabs defaultValue="saved" className="w-full">
          <TabsList className="w-full sm:w-auto flex bg-transparent border-b border-border rounded-none h-auto p-0 mb-8 space-x-8">
            <TabsTrigger 
              value="reviews" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-0 py-3 text-base"
            >
              Recent Reviews
            </TabsTrigger>
            <TabsTrigger 
              value="saved" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-0 py-3 text-base"
            >
              Saved Collections
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="reviews" className="animate-in fade-in slide-in-from-bottom-4">
            <div className="text-center py-20 bg-secondary/30 rounded-3xl border border-border">
              <h3 className="text-xl font-bold mb-2">You haven't reviewed anything yet.</h3>
              <p className="text-muted-foreground mb-6">Your reviews help others make better decisions.</p>
              <Button asChild><a href="/">Find a business to review</a></Button>
            </div>
          </TabsContent>
          
          <TabsContent value="saved" className="animate-in fade-in slide-in-from-bottom-4">
            {loadingSaved ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1,2,3].map(i => <div key={i} className="h-64 bg-muted animate-pulse rounded-2xl"></div>)}
              </div>
            ) : savedBiz && savedBiz.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {savedBiz.map((biz, i) => (
                  <BusinessCard key={biz.id} business={biz} index={i} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-secondary/30 rounded-3xl border border-border">
                <h3 className="text-xl font-bold mb-2">No saved businesses.</h3>
                <p className="text-muted-foreground mb-6">Save businesses to build your collection.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  );
}
