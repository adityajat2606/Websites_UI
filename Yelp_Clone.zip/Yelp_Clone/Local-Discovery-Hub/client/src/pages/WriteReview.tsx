import { useState } from "react";
import { useLocation, useSearch } from "wouter";
import { Navbar } from "@/components/Navbar";
import { useBusiness } from "@/hooks/use-businesses";
import { useCreateReview } from "@/hooks/use-reviews";
import { RatingStars } from "@/components/RatingStars";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ImagePlus, X, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function WriteReview() {
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const businessIdParam = searchParams.get("businessId");
  const businessId = businessIdParam ? parseInt(businessIdParam, 10) : null;

  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const { data: business, isLoading: loadingBiz } = useBusiness(businessId || 0);
  const createReview = useCreateReview();

  const [rating, setRating] = useState(0);
  const [text, setText] = useState("");
  const [images, setImages] = useState<string[]>([]);
  
  // Mock adding images
  const handleAddImage = () => {
    const mockImages = [
      "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400",
      "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400"
    ];
    setImages([...images, mockImages[images.length % mockImages.length]]);
  };

  const handleRemoveImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessId) return;
    if (rating === 0) {
      toast({ title: "Rating required", description: "Please select a star rating.", variant: "destructive" });
      return;
    }
    if (text.length < 10) {
      toast({ title: "Review too short", description: "Please write at least 10 characters.", variant: "destructive" });
      return;
    }

    createReview.mutate({
      businessId,
      userId: 1, // Mock user ID
      rating,
      text,
      images: images.length > 0 ? images : undefined
    }, {
      onSuccess: () => {
        toast({ title: "Review posted!", description: "Thank you for your feedback." });
        setLocation(`/business/${businessId}`);
      }
    });
  };

  if (!businessId) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <div className="flex-1 flex items-center justify-center pt-20 text-center px-4">
          <div>
            <h1 className="text-3xl font-display font-bold mb-4">Select a Business to Review</h1>
            <p className="text-muted-foreground mb-6">You must select a business before writing a review.</p>
            <Button asChild><Link href="/">Go Home</Link></Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 pt-24 pb-12 max-w-3xl mx-auto w-full px-4 sm:px-6">
        {loadingBiz ? (
          <div className="h-20 bg-muted animate-pulse rounded-xl mb-8"></div>
        ) : business ? (
          <div className="mb-8">
            <h1 className="text-3xl sm:text-4xl font-display font-bold text-foreground mb-2">
              <span className="text-primary">{business.name}</span>
            </h1>
            <p className="text-muted-foreground text-lg">Read our review guidelines before posting.</p>
          </div>
        ) : null}

        <form onSubmit={handleSubmit} className="space-y-8 bg-card border border-border p-6 sm:p-10 rounded-3xl shadow-sm">
          
          <div>
            <label className="block text-xl font-semibold mb-4 text-center sm:text-left">Overall Rating</label>
            <div className="flex justify-center sm:justify-start">
              <RatingStars 
                rating={rating} 
                interactive 
                size="xl" 
                onRatingChange={setRating} 
                className="scale-125 origin-left"
              />
            </div>
            {rating > 0 && (
              <motion.p 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 text-primary font-medium text-center sm:text-left"
              >
                {['Not good', "Could've been better", "OK", "Good", "Great!"][rating - 1]}
              </motion.p>
            )}
          </div>

          <div>
            <label className="block text-xl font-semibold mb-4">Your Review</label>
            <div className="relative group">
              <Textarea 
                placeholder="Doesn't look like much from the outside but it's totally worth it. The food was incredible and the service was top notch..."
                className="min-h-[200px] text-base p-5 rounded-2xl resize-y border-2 focus-visible:ring-0 focus-visible:border-primary transition-colors bg-secondary/30 focus:bg-background"
                value={text}
                onChange={(e) => setText(e.target.value)}
              />
            </div>
            <div className="flex justify-between items-center mt-2 text-sm text-muted-foreground">
              <span>{text.length} characters</span>
              {text.length > 0 && text.length < 10 && <span className="text-destructive">Keep going!</span>}
            </div>
          </div>

          <div>
            <label className="block text-xl font-semibold mb-4">Attach Photos <span className="text-muted-foreground text-base font-normal">(Optional)</span></label>
            
            <div className="flex flex-wrap gap-4">
              <AnimatePresence>
                {images.map((img, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="relative w-32 h-32 rounded-xl overflow-hidden group border border-border"
                  >
                    <img src={img} alt="Upload" className="w-full h-full object-cover" />
                    <button 
                      type="button"
                      onClick={() => handleRemoveImage(i)}
                      className="absolute top-2 right-2 w-7 h-7 bg-black/50 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 hover:bg-destructive transition-all"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              <button
                type="button"
                onClick={handleAddImage}
                className="w-32 h-32 rounded-xl border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 flex flex-col items-center justify-center text-muted-foreground hover:text-primary transition-colors"
              >
                <ImagePlus className="w-8 h-8 mb-2" />
                <span className="text-xs font-medium">Add Photo</span>
              </button>
            </div>
          </div>

          <div className="pt-6 border-t border-border">
            <Button 
              type="submit" 
              size="lg" 
              className="w-full sm:w-auto rounded-full px-12 py-6 text-lg font-bold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 active:scale-95 transition-all"
              disabled={createReview.isPending}
            >
              {createReview.isPending ? (
                <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Posting...</>
              ) : "Post Review"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  );
}

// Ensure Link is imported correctly
import { Link } from "wouter";
