import type {
  Business,
  Category,
  InsertReview,
  InsertSavedBusiness,
  Review,
  SavedBusiness,
  User,
} from "@shared/schema";

type BusinessReviewBundle = { review: Review; user: User };

const categories: Category[] = [
  { id: 1, name: "Restaurants", icon: "Utensils" },
  { id: 2, name: "Coffee & Tea", icon: "Coffee" },
  { id: 3, name: "Home Services", icon: "Wrench" },
  { id: 4, name: "Shopping", icon: "ShoppingBag" },
  { id: 5, name: "Fitness", icon: "Dumbbell" },
  { id: 6, name: "Nightlife", icon: "Martini" },
];

const users: User[] = [
  {
    id: 1,
    username: "Alex Chen",
    avatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
    bio: "Always chasing the next great meal.",
  },
  {
    id: 2,
    username: "Maya Patel",
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
    bio: "Coffee, city walks, and hidden gems.",
  },
  { id: 3, username: "Jordan Kim", avatar: null, bio: "Local guide." },
];

let businesses: Business[] = [
  {
    id: 1,
    name: "Sora Sushi Bar",
    image:
      "https://images.unsplash.com/photo-1553621042-f6e147245754?w=1200&q=80",
    rating: 4.7,
    reviewCount: 128,
    priceRange: "$$$",
    categoryId: 1,
    location: "San Francisco, CA",
    address: "55 Market St, San Francisco, CA",
    hours: "Mon–Sun 11:30am – 10:00pm",
    contact: "(415) 555-0110",
    description:
      "Modern omakase and creative rolls in a warm, minimalist space.",
    images: [
      "https://images.unsplash.com/photo-1541544181051-e46601bd5a2a?w=1200&q=80",
      "https://images.unsplash.com/photo-1563612116625-3012372fccce?w=1200&q=80",
    ],
  },
  {
    id: 2,
    name: "Golden Hour Cafe",
    image:
      "https://images.unsplash.com/photo-1517705008128-361805f42e86?w=1200&q=80",
    rating: 4.5,
    reviewCount: 86,
    priceRange: "$$",
    categoryId: 2,
    location: "San Francisco, CA",
    address: "120 Valencia St, San Francisco, CA",
    hours: "Daily 7:00am – 5:00pm",
    contact: "(415) 555-0124",
    description: "Small-batch coffee, flaky pastries, and sunny window seats.",
    images: null,
  },
  {
    id: 3,
    name: "Mission Tacos & Tequila",
    image:
      "https://images.unsplash.com/photo-1552332386-f8dd00dc2f85?w=1200&q=80",
    rating: 4.3,
    reviewCount: 242,
    priceRange: "$$",
    categoryId: 1,
    location: "San Francisco, CA",
    address: "88 Mission St, San Francisco, CA",
    hours: "Mon–Thu 12:00pm – 9:00pm, Fri–Sun 12:00pm – 11:00pm",
    contact: "(415) 555-0199",
    description:
      "Street-style tacos, spicy salsas, and a tequila list that means business.",
    images: null,
  },
  {
    id: 4,
    name: "Sparkle Clean Co.",
    image:
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=1200&q=80",
    rating: 4.8,
    reviewCount: 59,
    priceRange: "$$",
    categoryId: 3,
    location: "Oakland, CA",
    address: "Service Area - Oakland, CA",
    hours: "Mon–Sat 8:00am – 6:00pm",
    contact: "(510) 555-0102",
    description: "Fast, friendly home cleaning with transparent pricing.",
    images: null,
  },
  {
    id: 5,
    name: "North Beach Vintage",
    image:
      "https://images.unsplash.com/photo-1521335629791-ce4aec67dd47?w=1200&q=80",
    rating: 4.2,
    reviewCount: 31,
    priceRange: "$$",
    categoryId: 4,
    location: "San Francisco, CA",
    address: "14 Columbus Ave, San Francisco, CA",
    hours: "Tue–Sun 11:00am – 7:00pm",
    contact: "(415) 555-0175",
    description: "Curated vintage clothing and accessories with weekly drops.",
    images: null,
  },
  {
    id: 6,
    name: "Pulse Fitness Studio",
    image:
      "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&q=80",
    rating: 4.6,
    reviewCount: 104,
    priceRange: "$$$",
    categoryId: 5,
    location: "Berkeley, CA",
    address: "9 Shattuck Sq, Berkeley, CA",
    hours: "Daily 6:00am – 9:00pm",
    contact: "(510) 555-0158",
    description: "HIIT, strength, and mobility classes for all levels.",
    images: null,
  },
];

let reviews: Review[] = [
  {
    id: 1,
    businessId: 1,
    userId: 1,
    rating: 5,
    text: "Incredible omakase. Every bite felt intentional. The toro was unreal.",
    images: null,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
  },
  {
    id: 2,
    businessId: 1,
    userId: 2,
    rating: 4,
    text: "Beautiful space and great service. Slight wait but worth it.",
    images: null,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(),
  },
  {
    id: 3,
    businessId: 2,
    userId: 3,
    rating: 5,
    text: "Best cappuccino I’ve had in the city. Pastries are legit too.",
    images: null,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
  },
];

let savedBusinesses: SavedBusiness[] = [
  { id: 1, userId: 1, businessId: 2 },
  { id: 2, userId: 1, businessId: 1 },
];

function nextId(items: Array<{ id: number }>) {
  return items.reduce((max, x) => Math.max(max, x.id), 0) + 1;
}

function normalize(s: string) {
  return s.trim().toLowerCase();
}

export async function listCategories(): Promise<Category[]> {
  return categories;
}

export async function listBusinesses(params?: {
  query?: string;
  location?: string;
  categoryId?: string;
}): Promise<Business[]> {
  let out = businesses.slice();

  if (params?.categoryId) {
    const categoryId = Number(params.categoryId);
    if (!Number.isNaN(categoryId)) {
      out = out.filter((b) => b.categoryId === categoryId);
    }
  }

  if (params?.location) {
    const loc = normalize(params.location);
    out = out.filter((b) => normalize(b.location).includes(loc));
  }

  if (params?.query) {
    const q = normalize(params.query);
    out = out.filter((b) => {
      const haystack = normalize(
        `${b.name} ${b.description ?? ""} ${b.location} ${b.address}`,
      );
      return haystack.includes(q);
    });
  }

  return out;
}

export async function getBusiness(id: number): Promise<Business | null> {
  return businesses.find((b) => b.id === id) ?? null;
}

export async function getBusinessReviews(
  businessId: number,
): Promise<BusinessReviewBundle[]> {
  const bundles: BusinessReviewBundle[] = reviews
    .filter((r) => r.businessId === businessId)
    .sort((a, b) => {
      const ad = a.date ? new Date(a.date).getTime() : 0;
      const bd = b.date ? new Date(b.date).getTime() : 0;
      return bd - ad;
    })
    .map((review) => {
      const user = users.find((u) => u.id === review.userId);
      if (!user) {
        return null;
      }
      return { review, user };
    })
    .filter((x): x is BusinessReviewBundle => x !== null);

  return bundles;
}

export async function getUser(id: number): Promise<User | null> {
  return users.find((u) => u.id === id) ?? null;
}

export async function listSavedBusinessesByUser(
  userId: number,
): Promise<Business[]> {
  const ids = new Set(
    savedBusinesses.filter((s) => s.userId === userId).map((s) => s.businessId),
  );
  return businesses.filter((b) => ids.has(b.id));
}

export async function addSavedBusiness(
  data: InsertSavedBusiness,
): Promise<SavedBusiness> {
  const exists = savedBusinesses.find(
    (s) => s.userId === data.userId && s.businessId === data.businessId,
  );
  if (exists) return exists;

  const saved: SavedBusiness = { id: nextId(savedBusinesses), ...data };
  savedBusinesses = [...savedBusinesses, saved];
  return saved;
}

export async function removeSavedBusiness(id: number): Promise<void> {
  savedBusinesses = savedBusinesses.filter((s) => s.id !== id);
}

export async function createReview(data: InsertReview): Promise<Review> {
  const review: Review = {
    id: nextId(reviews),
    businessId: data.businessId,
    userId: data.userId,
    rating: data.rating,
    text: data.text,
    images: data.images ?? null,
    date: new Date().toISOString(),
  };

  reviews = [review, ...reviews];

  const biz = businesses.find((b) => b.id === data.businessId);
  if (biz) {
    const oldCount = biz.reviewCount;
    const newCount = oldCount + 1;
    const newRating = (biz.rating * oldCount + data.rating) / newCount;
    businesses = businesses.map((b) =>
      b.id === biz.id
        ? {
            ...b,
            reviewCount: newCount,
            rating: Math.round(newRating * 10) / 10,
          }
        : b,
    );
  }

  return review;
}

