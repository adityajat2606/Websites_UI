import { type Review, type User } from "@shared/schema";
import { RatingStars } from "./RatingStars";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";
import { ThumbsUp, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ReviewCardProps {
  review: Review;
  user: User;
}

export function ReviewCard({ review, user }: ReviewCardProps) {
  const date = review.date ? new Date(review.date) : new Date();
  
  return (
    <div className="py-6 border-b border-border last:border-0 group">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="w-12 h-12 border-2 border-background shadow-sm">
            {user.avatar ? (
              <AvatarImage src={user.avatar} alt={user.username} />
            ) : null}
            <AvatarFallback className="bg-primary/10 text-primary font-display font-bold">
              {user.username.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <h4 className="font-bold text-foreground hover:underline cursor-pointer">
              {user.username}
            </h4>
            <div className="flex items-center text-xs text-muted-foreground mt-0.5">
              <span>San Francisco, CA</span>
              <span className="mx-1.5">•</span>
              <span>12 reviews</span>
            </div>
          </div>
        </div>
        
        <Button variant="ghost" size="icon" className="text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
          <MoreHorizontal className="w-5 h-5" />
        </Button>
      </div>

      <div className="mt-4">
        <div className="flex items-center gap-3 mb-3">
          <RatingStars rating={review.rating} />
          <span className="text-sm text-muted-foreground">
            {formatDistanceToNow(date, { addSuffix: true })}
          </span>
        </div>
        
        <p className="text-foreground/90 leading-relaxed whitespace-pre-wrap text-[15px]">
          {review.text}
        </p>

        {review.images && review.images.length > 0 && (
          <div className="flex gap-2 mt-4 overflow-x-auto pb-2 -mx-2 px-2 snap-x">
            {review.images.map((img, i) => (
              <img 
                key={i} 
                src={img} 
                alt={`Review image ${i + 1}`} 
                className="w-32 h-32 object-cover rounded-xl snap-center border border-border/50 shadow-sm hover:opacity-90 transition-opacity cursor-pointer"
              />
            ))}
          </div>
        )}
      </div>

      <div className="mt-5 flex items-center gap-4">
        <Button variant="outline" size="sm" className="rounded-full text-xs font-medium hover:bg-primary/5 hover:text-primary hover:border-primary/30 transition-colors">
          <ThumbsUp className="w-3.5 h-3.5 mr-1.5" />
          Helpful
        </Button>
      </div>
    </div>
  );
}
