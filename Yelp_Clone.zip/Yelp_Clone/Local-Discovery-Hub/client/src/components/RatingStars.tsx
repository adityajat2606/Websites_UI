import { Star, StarHalf } from "lucide-react";
import { cn } from "@/lib/utils";

interface RatingStarsProps {
  rating: number;
  max?: number;
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
}

export function RatingStars({ 
  rating, 
  max = 5, 
  className, 
  size = "md",
  interactive = false,
  onRatingChange
}: RatingStarsProps) {
  const sizeClasses = {
    sm: "w-3.5 h-3.5",
    md: "w-5 h-5",
    lg: "w-6 h-6",
    xl: "w-8 h-8",
  };

  const handleHover = (idx: number) => {
    if (interactive && onRatingChange) {
      // Logic for hover state could go here if we had internal state
    }
  };

  const handleClick = (idx: number) => {
    if (interactive && onRatingChange) {
      onRatingChange(idx + 1);
    }
  };

  return (
    <div className={cn("flex items-center gap-0.5", className)}>
      {Array.from({ length: max }).map((_, i) => {
        const isFilled = rating >= i + 1;
        const isHalf = rating > i && rating < i + 1;
        
        return (
          <button
            key={i}
            type={interactive ? "button" : "button"}
            disabled={!interactive}
            onClick={() => handleClick(i)}
            onMouseEnter={() => handleHover(i)}
            className={cn(
              "focus:outline-none transition-transform",
              interactive ? "hover:scale-110 active:scale-95 cursor-pointer" : "cursor-default"
            )}
            aria-label={`Rate ${i + 1} stars`}
          >
            {isHalf ? (
              <div className="relative">
                <Star className={cn(sizeClasses[size], "text-muted stroke-muted-foreground/30")} />
                <div className="absolute inset-0 overflow-hidden w-[50%]">
                  <Star className={cn(sizeClasses[size], "fill-primary text-primary")} />
                </div>
              </div>
            ) : (
              <Star 
                className={cn(
                  sizeClasses[size], 
                  isFilled 
                    ? "fill-primary text-primary" 
                    : "fill-transparent text-muted-foreground/30",
                  interactive && !isFilled && "hover:text-primary/50"
                )} 
              />
            )}
          </button>
        );
      })}
    </div>
  );
}
