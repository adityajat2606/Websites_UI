import { Link, useLocation } from "wouter";
import { SearchBar } from "./SearchBar";
import { Button } from "@/components/ui/button";
import { Menu, User, FolderHeart, LogOut } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const [location] = useLocation();
  const isHome = location === "/";
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Use a mock user for now as we don't have full auth setup
  const mockUser = { id: 1, username: "AlexD" };

  return (
    <header 
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300",
        isHome 
          ? scrolled ? "glass-nav py-3" : "bg-transparent py-5"
          : "glass-nav py-3"
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
        <div className="flex-shrink-0">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-primary text-primary-foreground rounded-xl flex items-center justify-center font-display font-bold text-2xl shadow-lg shadow-primary/20 group-hover:scale-105 transition-transform">
              d.
            </div>
            <span className={cn(
              "font-display font-bold text-2xl tracking-tight hidden sm:block",
              isHome && !scrolled ? "text-white" : "text-foreground"
            )}>
              discover
            </span>
          </Link>
        </div>

        {(!isHome || scrolled) && (
          <div className="flex-1 max-w-2xl hidden md:flex animate-in fade-in slide-in-from-top-4">
            <SearchBar variant="navbar" />
          </div>
        )}

        <div className="flex items-center gap-2 sm:gap-4">
          <Link 
            href="/write-review" 
            className={cn(
              "hidden lg:block font-medium text-sm hover:underline transition-colors",
              isHome && !scrolled ? "text-white/90 hover:text-white" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Write a Review
          </Link>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant={isHome && !scrolled ? "outline" : "ghost"} 
                size="icon"
                className={cn(
                  "rounded-full border-2",
                  isHome && !scrolled 
                    ? "bg-white/10 border-white/20 text-white hover:bg-white/20" 
                    : "border-transparent"
                )}
              >
                <User className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 rounded-xl">
              <div className="p-3">
                <p className="font-semibold">{mockUser.username}</p>
                <p className="text-xs text-muted-foreground">San Francisco, CA</p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href={`/user/${mockUser.id}`} className="cursor-pointer flex w-full">
                  <User className="w-4 h-4 mr-2" /> Profile
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/saved" className="cursor-pointer flex w-full">
                  <FolderHeart className="w-4 h-4 mr-2" /> Saved Businesses
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive cursor-pointer">
                <LogOut className="w-4 h-4 mr-2" /> Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button 
            variant={isHome && !scrolled ? "outline" : "default"}
            className={cn(
              "hidden sm:flex rounded-full font-semibold px-6",
              isHome && !scrolled 
                ? "bg-transparent border-white/30 text-white hover:bg-white hover:text-black" 
                : "shadow-md hover:shadow-lg transition-all"
            )}
            onClick={() => window.location.href = "/"}
          >
            Sign Up
          </Button>

          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className={cn("w-6 h-6", isHome && !scrolled ? "text-white" : "text-foreground")} />
          </Button>
        </div>
      </div>
    </header>
  );
}
