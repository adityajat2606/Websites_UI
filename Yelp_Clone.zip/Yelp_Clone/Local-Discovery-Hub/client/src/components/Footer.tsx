import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-secondary pt-16 pb-8 border-t border-border mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="font-display font-bold text-lg mb-4 text-foreground">About Discover</h3>
            <ul className="space-y-3">
              <li><Link href="/about" className="text-muted-foreground hover:text-primary transition-colors text-sm">About Us</Link></li>
              <li><Link href="/careers" className="text-muted-foreground hover:text-primary transition-colors text-sm">Careers</Link></li>
              <li><Link href="/press" className="text-muted-foreground hover:text-primary transition-colors text-sm">Press</Link></li>
              <li><Link href="/investors" className="text-muted-foreground hover:text-primary transition-colors text-sm">Investor Relations</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-display font-bold text-lg mb-4 text-foreground">Discover</h3>
            <ul className="space-y-3">
              <li><Link href="/collections" className="text-muted-foreground hover:text-primary transition-colors text-sm">Collections</Link></li>
              <li><Link href="/talk" className="text-muted-foreground hover:text-primary transition-colors text-sm">Talk</Link></li>
              <li><Link href="/events" className="text-muted-foreground hover:text-primary transition-colors text-sm">Events</Link></li>
              <li><Link href="/blog" className="text-muted-foreground hover:text-primary transition-colors text-sm">The Local Blog</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-display font-bold text-lg mb-4 text-foreground">For Businesses</h3>
            <ul className="space-y-3">
              <li><Link href="/claim" className="text-muted-foreground hover:text-primary transition-colors text-sm">Claim your Business</Link></li>
              <li><Link href="/advertise" className="text-muted-foreground hover:text-primary transition-colors text-sm">Advertise on Discover</Link></li>
              <li><Link href="/success" className="text-muted-foreground hover:text-primary transition-colors text-sm">Success Stories</Link></li>
              <li><Link href="/support" className="text-muted-foreground hover:text-primary transition-colors text-sm">Business Support</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-display font-bold text-lg mb-4 text-foreground">Languages</h3>
            <ul className="space-y-3">
              <li><button className="text-muted-foreground hover:text-primary transition-colors text-sm">English (US)</button></li>
              <li><button className="text-muted-foreground hover:text-primary transition-colors text-sm">Español</button></li>
              <li><button className="text-muted-foreground hover:text-primary transition-colors text-sm">Français</button></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary text-primary-foreground rounded-lg flex items-center justify-center font-display font-bold text-xl">
              d.
            </div>
            <span className="font-semibold text-foreground">Discover Inc. © 2025</span>
          </div>
          <div className="flex gap-6 text-sm text-muted-foreground">
            <Link href="/terms" className="hover:text-primary transition-colors">Terms of Service</Link>
            <Link href="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link>
            <Link href="/cookies" className="hover:text-primary transition-colors">Cookie Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
