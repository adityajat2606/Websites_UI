import { Search, MapPin } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  className?: string;
  variant?: "hero" | "navbar";
  initialQuery?: string;
  initialLocation?: string;
}

export function SearchBar({ 
  className, 
  variant = "navbar",
  initialQuery = "",
  initialLocation = ""
}: SearchBarProps) {
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState(initialQuery);
  const [loc, setLoc] = useState(initialLocation);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (query) params.append("query", query);
    if (loc) params.append("location", loc);
    setLocation(`/search${params.toString() ? `?${params.toString()}` : ''}`);
  };

  if (variant === "hero") {
    return (
      <form 
        onSubmit={handleSubmit}
        className={cn(
          "flex flex-col sm:flex-row w-full max-w-4xl mx-auto bg-background rounded-2xl sm:rounded-full shadow-2xl overflow-hidden p-2 gap-2",
          className
        )}
      >
        <div className="flex-1 flex items-center px-4 bg-secondary/50 rounded-xl sm:rounded-full border border-transparent focus-within:border-primary/30 focus-within:bg-background transition-colors">
          <Search className="w-5 h-5 text-muted-foreground mr-2" />
          <input 
            type="text" 
            placeholder="tacos, cheap dinner, Max's" 
            className="w-full py-4 bg-transparent outline-none text-foreground placeholder:text-muted-foreground text-lg"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        
        <div className="w-full sm:w-px h-[1px] sm:h-auto bg-border my-2 sm:my-0 mx-2" />
        
        <div className="flex-1 flex items-center px-4 bg-secondary/50 rounded-xl sm:rounded-full border border-transparent focus-within:border-primary/30 focus-within:bg-background transition-colors">
          <MapPin className="w-5 h-5 text-muted-foreground mr-2" />
          <input 
            type="text" 
            placeholder="San Francisco, CA" 
            className="w-full py-4 bg-transparent outline-none text-foreground placeholder:text-muted-foreground text-lg"
            value={loc}
            onChange={(e) => setLoc(e.target.value)}
          />
        </div>
        
        <button 
          type="submit"
          className="bg-primary hover:bg-primary/90 text-primary-foreground p-4 rounded-xl sm:rounded-full font-bold text-lg shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all active:scale-[0.98]"
        >
          <Search className="w-6 h-6 hidden sm:block" />
          <span className="sm:hidden">Search</span>
        </button>
      </form>
    );
  }

  return (
    <form 
      onSubmit={handleSubmit}
      className={cn(
        "flex w-full max-w-xl bg-secondary/50 hover:bg-secondary rounded-full overflow-hidden border border-border/50 focus-within:border-primary/50 focus-within:bg-background transition-all shadow-sm focus-within:shadow-md",
        className
      )}
    >
      <div className="flex-1 flex items-center pl-4 pr-2">
        <input 
          type="text" 
          placeholder="tacos, cheap dinner..." 
          className="w-full py-2.5 bg-transparent outline-none text-sm text-foreground placeholder:text-muted-foreground"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>
      
      <div className="w-px h-6 bg-border self-center" />
      
      <div className="flex-1 flex items-center px-2">
        <input 
          type="text" 
          placeholder="Location" 
          className="w-full py-2.5 bg-transparent outline-none text-sm text-foreground placeholder:text-muted-foreground"
          value={loc}
          onChange={(e) => setLoc(e.target.value)}
        />
      </div>
      
      <button 
        type="submit"
        className="bg-primary hover:bg-primary/90 text-primary-foreground px-5 rounded-r-full transition-colors flex items-center justify-center"
      >
        <Search className="w-4 h-4" />
      </button>
    </form>
  );
}
