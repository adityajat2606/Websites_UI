import { Link } from "wouter";
import { type Business } from "@shared/schema";
import { RatingStars } from "./RatingStars";
import { MapPin, MessageSquare, FolderHeart } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface BusinessCardProps {
  business: Business;
  index?: number;
  featured?: boolean;
}

export function BusinessCard({ business, index = 0, featured = false }: BusinessCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      whileHover={{ y: -6 }}
      className="group bg-card rounded-2xl overflow-hidden shadow-sm border border-border hover:shadow-xl hover:border-primary/20 transition-all duration-300 flex flex-col h-full"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <Link href={`/business/${business.id}`}>
          <img 
            src={business.image} 
            alt={business.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        </Link>
        <Button 
          variant="secondary" 
          size="icon" 
          className="absolute top-3 right-3 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white text-muted-foreground hover:text-primary border-none shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <FolderHeart className="w-4 h-4" />
        </Button>
        {featured && (
          <Badge className="absolute top-3 left-3 bg-accent text-accent-foreground border-none px-3 py-1 text-xs font-semibold shadow-md">
            Featured
          </Badge>
        )}
      </div>

      <div className="p-5 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-2">
          <Link href={`/business/${business.id}`} className="block group/title flex-1 pr-2">
            <h3 className="font-display font-bold text-xl text-foreground group-hover/title:text-primary transition-colors line-clamp-1">
              {business.name}
            </h3>
          </Link>
        </div>

        <div className="flex items-center gap-2 mb-3">
          <RatingStars rating={business.rating} size="sm" />
          <span className="text-sm font-medium text-foreground">{business.rating.toFixed(1)}</span>
          <span className="text-sm text-muted-foreground">({business.reviewCount} reviews)</span>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <span className="font-medium text-foreground">{business.priceRange}</span>
          <span>•</span>
          <span>Restaurants</span> {/* Would use category map in real app */}
        </div>

        <div className="mt-auto space-y-2">
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPin className="w-4 h-4 mr-2 text-primary/70 shrink-0" />
            <span className="line-clamp-1">{business.location}</span>
          </div>
          
          {business.description && (
            <div className="flex items-start text-sm text-muted-foreground bg-secondary/50 p-3 rounded-xl">
              <MessageSquare className="w-4 h-4 mr-2 text-primary/70 shrink-0 mt-0.5" />
              <p className="line-clamp-2 italic">"{business.description}"</p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
