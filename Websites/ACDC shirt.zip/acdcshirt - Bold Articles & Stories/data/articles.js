// Generated static data file (no fetch needed).
// This keeps the site fully static (HTML/CSS/JS only).
window.ACDC_ARTICLES_DATA = {
  "articles": [
    {
      "id": 1,
      "title": "The Evolution of Street Fashion: From Underground to Mainstream",
      "slug": "evolution-street-fashion",
      "excerpt": "Explore how street fashion transformed from a countercultural movement to a billion-dollar industry shaping global trends.",
      "content": "Street fashion has undergone a remarkable transformation over the past few decades.\n\nWhat began as a form of self-expression among urban youth has evolved into a dominant force in the global fashion industry.\n\nIn this story, we trace the major shifts: the rise of subcultures, the influence of music scenes, the role of social media, and how luxury brands embraced what they once ignored.\n\nAlong the way, you’ll see how authenticity became a commodity—and why the next wave of street style may be more local, more sustainable, and more community-driven than ever.",
      "category": "Culture",
      "image": "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=500&fit=crop",
      "author": {
        "name": "Alex Rivera",
        "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
        "bio": "Fashion writer and cultural critic"
      },
      "date": "2024-12-15",
      "readingTime": 8,
      "featured": true,
      "trending": true
    },
    {
      "id": 2,
      "title": "How Minimalism Changed My Approach to Life",
      "slug": "minimalism-life-approach",
      "excerpt": "A personal journey through embracing less to discover more meaning and purpose in everyday living.",
      "content": "Three years ago, I looked around my apartment and felt overwhelmed.\n\nNot by the space itself, but by everything in it.\n\nMinimalism wasn’t a rulebook—it was permission to choose. To keep what supports your life, and let go of what only fills it.\n\nThis is what changed when I simplified: my schedule, my spending, my focus, and the way I define “enough.”",
      "category": "Lifestyle",
      "image": "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?w=800&h=500&fit=crop",
      "author": {
        "name": "Sarah Chen",
        "avatar": "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
        "bio": "Lifestyle blogger and minimalist advocate"
      },
      "date": "2024-12-14",
      "readingTime": 6,
      "featured": false,
      "trending": true
    },
    {
      "id": 3,
      "title": "The Rise of AI in Creative Industries",
      "slug": "ai-creative-industries",
      "excerpt": "Examining how artificial intelligence is reshaping art, music, design, and the future of human creativity.",
      "content": "Artificial intelligence is no longer confined to tech labs and research papers.\n\nIt’s actively creating art, composing music, and designing products.\n\nThe big question isn’t whether AI can create—it’s how we’ll define originality, ownership, and taste when tools can generate infinite variations.\n\nHere’s what’s happening now, and what creators should pay attention to next.",
      "category": "Tech",
      "image": "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=500&fit=crop",
      "author": {
        "name": "Marcus Johnson",
        "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
        "bio": "Tech journalist and AI researcher"
      },
      "date": "2024-12-13",
      "readingTime": 10,
      "featured": false,
      "trending": true
    },
    {
      "id": 4,
      "title": "Sustainable Fashion: Beyond the Buzzword",
      "slug": "sustainable-fashion-reality",
      "excerpt": "What does sustainable fashion really mean, and how can consumers make informed choices?",
      "content": "Sustainability has become fashion’s favorite word, but beneath the marketing lies a complex reality.\n\nFrom materials and manufacturing to labor practices and logistics, “better” is rarely simple.\n\nWe break down what to look for, which questions matter, and how to shop with fewer regrets—without expecting perfection.",
      "category": "Fashion",
      "image": "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=800&h=500&fit=crop",
      "author": {
        "name": "Emma Watson",
        "avatar": "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face",
        "bio": "Sustainable fashion advocate"
      },
      "date": "2024-12-12",
      "readingTime": 7,
      "featured": false,
      "trending": false
    },
    {
      "id": 5,
      "title": "The Psychology Behind Vinyl's Comeback",
      "slug": "vinyl-comeback-psychology",
      "excerpt": "Why are millennials and Gen Z turning to a 75-year-old music format in the streaming age?",
      "content": "In an era of instant digital access, something curious is happening.\n\nVinyl record sales have been climbing steadily for over a decade.\n\nThis isn’t just nostalgia—it’s ritual, identity, and the desire for tangible meaning.\n\nLet’s explore why physical formats still matter when everything else is frictionless.",
      "category": "Culture",
      "image": "https://images.unsplash.com/photo-1535925191244-17536ca4523b?w=800&h=500&fit=crop",
      "author": {
        "name": "David Park",
        "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
        "bio": "Music critic and cultural analyst"
      },
      "date": "2024-12-11",
      "readingTime": 5,
      "featured": false,
      "trending": true
    },
    {
      "id": 6,
      "title": "Remote Work: Two Years Later",
      "slug": "remote-work-two-years",
      "excerpt": "How the work-from-home revolution has permanently changed our relationship with the office.",
      "content": "The great remote work experiment didn’t just change where we work—it altered how we think about work.\n\nWe look at the habits that stuck, the tools that became essential, and the cultural shifts companies are still catching up to.\n\nFor many, the future is neither fully remote nor fully in-office, but something more intentional in between.",
      "category": "Lifestyle",
      "image": "https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=800&h=500&fit=crop",
      "author": {
        "name": "Jennifer Liu",
        "avatar": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face",
        "bio": "Workplace culture writer"
      },
      "date": "2024-12-10",
      "readingTime": 8,
      "featured": false,
      "trending": false
    },
    {
      "id": 7,
      "title": "The New Wave of Japanese Denim",
      "slug": "japanese-denim-wave",
      "excerpt": "Inside the artisan workshops crafting the world's most coveted jeans.",
      "content": "In the small town of Kojima, Japan, looms older than most of their operators continue to weave stories into fabric.\n\nThis new wave is about patience: raw denim, careful dyeing, and craft that shows up over time.\n\nHere’s why Japanese denim remains the gold standard—and what to look for if you’re buying your first pair.",
      "category": "Fashion",
      "image": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&h=500&fit=crop",
      "author": {
        "name": "Yuki Tanaka",
        "avatar": "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=face",
        "bio": "Fashion historian and denim enthusiast"
      },
      "date": "2024-12-09",
      "readingTime": 9,
      "featured": false,
      "trending": true
    },
    {
      "id": 8,
      "title": "Understanding Blockchain Beyond Crypto",
      "slug": "blockchain-beyond-crypto",
      "excerpt": "The technology behind cryptocurrencies has applications far beyond digital currencies.",
      "content": "When most people hear “blockchain,” they think of Bitcoin.\n\nBut the underlying idea—shared ledgers, verifiable history, and distributed trust—can show up in supply chains, identity, and record keeping.\n\nThis is blockchain without the hype: where it helps, where it doesn’t, and what to watch next.",
      "category": "Tech",
      "image": "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&h=500&fit=crop",
      "author": {
        "name": "Robert Chen",
        "avatar": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop&crop=face",
        "bio": "Blockchain consultant and tech writer"
      },
      "date": "2024-12-08",
      "readingTime": 11,
      "featured": false,
      "trending": false
    },
    {
      "id": 9,
      "title": "The Art of the Perfect Playlist",
      "slug": "perfect-playlist-art",
      "excerpt": "How to curate music that sets the mood, tells a story, and connects with listeners.",
      "content": "Creating a great playlist is an underrated art form.\n\nIt’s not just about collecting good songs—it’s about crafting an experience.\n\nWe’ll walk through flow, energy, transitions, and a few reliable structures you can reuse for different moods.",
      "category": "Culture",
      "image": "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&h=500&fit=crop",
      "author": {
        "name": "Maya Williams",
        "avatar": "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop&crop=face",
        "bio": "DJ and music curator"
      },
      "date": "2024-12-07",
      "readingTime": 6,
      "featured": false,
      "trending": false
    },
    {
      "id": 10,
      "title": "Digital Detox: A Week Without Screens",
      "slug": "digital-detox-week",
      "excerpt": "What happens when you disconnect from technology for seven days? One writer finds out.",
      "content": "Day one began with phantom vibrations.\n\nBy day three, boredom became creativity.\n\nBy day seven, I noticed how much of my life had been filled with noise.\n\nHere’s what I learned from stepping away—and how to do a detox without turning it into a performance.",
      "category": "Lifestyle",
      "image": "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=500&fit=crop",
      "author": {
        "name": "Tom Bradley",
        "avatar": "https://images.unsplash.com/photo-1463453091185-61582044d556?w=100&h=100&fit=crop&crop=face",
        "bio": "Wellness writer and outdoor enthusiast"
      },
      "date": "2024-12-06",
      "readingTime": 7,
      "featured": false,
      "trending": false
    },
    {
      "id": 11,
      "title": "The Sneaker Resale Market Explained",
      "slug": "sneaker-resale-market",
      "excerpt": "How limited-edition sneakers became investment assets worth thousands of dollars.",
      "content": "The sneaker resale market is now a multi-billion dollar ecosystem.\n\nScarcity, community, and speculation combine into price tags that can exceed luxury goods.\n\nWe explain how it works, what drives prices, and how newcomers can avoid the most common mistakes.",
      "category": "Fashion",
      "image": "https://images.unsplash.com/photo-1552346154-21d32810aba3?w=800&h=500&fit=crop",
      "author": {
        "name": "Chris Martinez",
        "avatar": "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=100&h=100&fit=crop&crop=face",
        "bio": "Sneaker collector and market analyst"
      },
      "date": "2024-12-05",
      "readingTime": 8,
      "featured": false,
      "trending": false
    },
    {
      "id": 12,
      "title": "The Future of Electric Vehicles",
      "slug": "future-electric-vehicles",
      "excerpt": "What to expect from EVs in the next decade as technology advances and adoption accelerates.",
      "content": "Electric vehicles are no longer a niche product.\n\nBattery tech, charging networks, policy, and design are moving fast.\n\nWe look at the next decade: range, cost curves, grid impact, and the real reasons adoption may accelerate quicker than expected.",
      "category": "Tech",
      "image": "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800&h=500&fit=crop",
      "author": {
        "name": "Lisa Park",
        "avatar": "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop&crop=face",
        "bio": "Automotive journalist"
      },
      "date": "2024-12-04",
      "readingTime": 9,
      "featured": false,
      "trending": false
    }
  ]
};

