# Todo
- #3: Create article detail page with table of contents and related articles
- #4: Build category, about, and contact pages
