/**
 * acdcshirt - Main JavaScript
 * Handles all dynamic functionality for the website
 */

// =====================================================
// Configuration & State
// =====================================================
const CONFIG = {
  articlesPerPage: 6,
  dataPath: 'data/articles.json'
};

let state = {
  articles: [],
  filteredArticles: [],
  currentPage: 1,
  currentCategory: 'all',
  searchQuery: ''
};

// =====================================================
// DOM Elements
// =====================================================
const DOM = {
  // Header
  header: document.getElementById('header'),
  mobileMenuToggle: document.getElementById('mobile-menu-toggle'),
  navMobile: document.getElementById('nav-mobile'),
  themeToggle: document.getElementById('theme-toggle'),
  searchToggle: document.getElementById('search-toggle'),
  searchOverlay: document.getElementById('search-overlay'),
  searchInput: document.getElementById('search-input'),
  searchClose: document.getElementById('search-close'),
  searchResults: document.getElementById('search-results'),
  
  // Main content
  articlesGrid: document.getElementById('articles-grid'),
  trendingArticles: document.getElementById('trending-articles'),
  categoryFilter: document.getElementById('category-filter'),
  
  // Pagination
  pagination: document.getElementById('pagination'),
  prevPage: document.getElementById('prev-page'),
  nextPage: document.getElementById('next-page'),
  pageNumbers: document.getElementById('page-numbers'),
  
  // Newsletter
  newsletterForm: document.getElementById('newsletter-form')
};

function getPageType() {
  return document.body?.dataset?.page || 'home';
}

// =====================================================
// Utility Functions
// =====================================================

/**
 * Format date to readable string
 */
function formatDate(dateString) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString('en-US', options);
}

/**
 * Calculate reading time from content
 */
function calculateReadingTime(content) {
  const wordsPerMinute = 200;
  const wordCount = content.split(/\s+/).length;
  return Math.ceil(wordCount / wordsPerMinute);
}

/**
 * Show toast notification
 */
function showToast(message) {
  // Remove existing toast if any
  const existingToast = document.querySelector('.toast');
  if (existingToast) existingToast.remove();
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  
  // Trigger animation
  setTimeout(() => toast.classList.add('show'), 10);
  
  // Remove after 3 seconds
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/**
 * Debounce function for search
 */
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function slugify(str) {
  return String(str)
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

// =====================================================
// Theme Management
// =====================================================

function initTheme() {
  // Check localStorage or system preference
  const savedTheme = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
}

function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
}

// =====================================================
// Header & Navigation
// =====================================================

function initHeader() {
  if (!DOM.header) return;

  // Sticky header on scroll
  let lastScroll = 0;
  
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 50) {
      DOM.header.classList.add('scrolled');
    } else {
      DOM.header.classList.remove('scrolled');
    }
    
    lastScroll = currentScroll;
  });
  
  // Mobile menu toggle
  if (DOM.mobileMenuToggle) {
    DOM.mobileMenuToggle.addEventListener('click', () => {
      DOM.mobileMenuToggle.classList.toggle('active');
      DOM.navMobile.classList.toggle('active');
    });
  }
  
  // Theme toggle
  if (DOM.themeToggle) {
    DOM.themeToggle.addEventListener('click', toggleTheme);
  }
  
  // Search functionality
  if (DOM.searchToggle) {
    DOM.searchToggle.addEventListener('click', () => {
      if (!DOM.searchOverlay || !DOM.searchInput) return;
      DOM.searchOverlay.classList.add('active');
      DOM.searchInput.focus();
    });
  }
  
  if (DOM.searchClose) {
    DOM.searchClose.addEventListener('click', () => {
      if (!DOM.searchOverlay || !DOM.searchInput || !DOM.searchResults) return;
      DOM.searchOverlay.classList.remove('active');
      DOM.searchInput.value = '';
      DOM.searchResults.innerHTML = '';
    });
  }
  
  // Search input
  if (DOM.searchInput) {
    DOM.searchInput.addEventListener('input', debounce((e) => {
      performSearch(e.target.value);
    }, 300));
  }
  
  // Close search on escape
  document.addEventListener('keydown', (e) => {
    if (!DOM.searchOverlay) return;
    if (e.key === 'Escape' && DOM.searchOverlay.classList.contains('active')) {
      DOM.searchOverlay.classList.remove('active');
    }
  });
}

// =====================================================
// Search Functionality
// =====================================================

function performSearch(query) {
  if (!DOM.searchResults) return;
  if (!query.trim()) {
    DOM.searchResults.innerHTML = '';
    return;
  }
  
  const results = state.articles.filter(article => {
    const searchableText = `${article.title} ${article.excerpt} ${article.category}`.toLowerCase();
    return searchableText.includes(query.toLowerCase());
  });
  
  renderSearchResults(results);
}

function renderSearchResults(results) {
  if (!DOM.searchResults) return;
  if (results.length === 0) {
    DOM.searchResults.innerHTML = '<p class="search-no-results" style="color: var(--text-muted); text-align: center; padding: 20px;">No articles found</p>';
    return;
  }
  
  DOM.searchResults.innerHTML = results.slice(0, 5).map(article => `
    <a href="article.html?id=${article.id}" class="search-result-item">
      <strong>${article.title}</strong>
      <span style="display: block; font-size: 13px; color: var(--text-muted); margin-top: 4px;">${article.category} • ${formatDate(article.date)}</span>
    </a>
  `).join('');
}

// =====================================================
// Data Loading
// =====================================================

async function loadArticles() {
  try {
    let data = null;

    // Prefer embedded data for fully-static usage (works on file://)
    if (window.ACDC_ARTICLES_DATA && Array.isArray(window.ACDC_ARTICLES_DATA.articles)) {
      data = window.ACDC_ARTICLES_DATA;
    } else {
      // Fallback: fetch JSON when served via HTTP
      const response = await fetch(CONFIG.dataPath);
      if (!response.ok) throw new Error('Failed to load articles');
      data = await response.json();
    }

    state.articles = (data.articles || []).map(a => ({
      ...a,
      readingTime: a.readingTime ?? calculateReadingTime(a.content || '')
    }));
    state.filteredArticles = [...state.articles];

    // Page-specific initialization that depends on articles
    initCategoryPageFromUrl();
    initArticlePageFromUrl();
    
    // Render content
    renderArticles();
    renderTrending();
    renderPagination();
    
  } catch (error) {
    console.error('Error loading articles:', error);
    if (DOM.articlesGrid) {
      DOM.articlesGrid.innerHTML = '<p style="text-align: center; color: var(--text-muted); grid-column: 1 / -1;">Failed to load articles. Please try again later.</p>';
    }
  }
}

// =====================================================
// Article Rendering
// =====================================================

function articleCardHTML(article, index = 0) {
  return `
    <article class="article-card fade-in" style="animation-delay: ${index * 0.1}s">
      <a href="article.html?id=${article.id}" class="article-card-image">
        <img 
          src="${article.image}" 
          alt="${escapeHtml(article.title)}"
          loading="lazy"
        >
        <span class="category-badge">${escapeHtml(article.category)}</span>
      </a>
      <div class="article-card-content">
        <a href="article.html?id=${article.id}">
          <h3 class="article-card-title">${escapeHtml(article.title)}</h3>
        </a>
        <p class="article-card-excerpt">${escapeHtml(article.excerpt)}</p>
        <div class="article-card-meta">
          <div class="article-card-author">
            <img src="${article.author.avatar}" alt="${escapeHtml(article.author.name)}">
            <span>${escapeHtml(article.author.name)}</span>
          </div>
          <div class="article-card-details">
            <span>${formatDate(article.date)}</span>
            <span>•</span>
            <span>${article.readingTime} min</span>
          </div>
        </div>
      </div>
    </article>
  `;
}

function renderArticles() {
  if (!DOM.articlesGrid) return;
  
  const startIndex = (state.currentPage - 1) * CONFIG.articlesPerPage;
  const endIndex = startIndex + CONFIG.articlesPerPage;
  const articlesToShow = state.filteredArticles.slice(startIndex, endIndex);
  
  if (articlesToShow.length === 0) {
    DOM.articlesGrid.innerHTML = '<p style="text-align: center; color: var(--text-muted); grid-column: 1 / -1; padding: 40px;">No articles found in this category.</p>';
    return;
  }
  
  DOM.articlesGrid.innerHTML = articlesToShow.map((article, index) => articleCardHTML(article, index)).join('');
}

function renderTrending() {
  if (!DOM.trendingArticles) return;
  
  const trendingItems = state.articles.filter(article => article.trending);
  
  DOM.trendingArticles.innerHTML = trendingItems.map(article => `
    <article class="trending-card">
      <a href="article.html?id=${article.id}" class="trending-card-image">
        <img src="${article.image}" alt="${article.title}" loading="lazy">
      </a>
      <div class="trending-card-content">
        <span class="trending-card-category">${article.category}</span>
        <a href="article.html?id=${article.id}">
          <h3 class="trending-card-title">${article.title}</h3>
        </a>
        <span class="trending-card-meta">${formatDate(article.date)} • ${article.readingTime} min read</span>
      </div>
    </article>
  `).join('');
}

// =====================================================
// Category Filtering
// =====================================================

function initCategoryFilter() {
  if (!DOM.categoryFilter) return;
  
  DOM.categoryFilter.addEventListener('click', (e) => {
    if (!e.target.classList.contains('filter-btn')) return;
    
    // Update active state
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    e.target.classList.add('active');
    
    // Filter articles
    state.currentCategory = e.target.dataset.category;
    state.currentPage = 1;
    
    applyCategory(state.currentCategory);
    
    renderArticles();
    renderPagination();
  });
}

function applyCategory(category) {
  state.currentCategory = category || 'all';
  if (state.currentCategory === 'all') {
    state.filteredArticles = [...state.articles];
  } else {
    state.filteredArticles = state.articles.filter(
      article => article.category.toLowerCase() === state.currentCategory.toLowerCase()
    );
  }

  // Update category page title if present
  const categorySectionTitle = document.getElementById('category-section-title');
  if (categorySectionTitle) {
    categorySectionTitle.textContent = state.currentCategory === 'all'
      ? 'All Articles'
      : `${state.currentCategory.charAt(0).toUpperCase()}${state.currentCategory.slice(1)} Articles`;
  }

  // Sync filter button states
  if (DOM.categoryFilter) {
    DOM.categoryFilter.querySelectorAll('.filter-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.category === state.currentCategory);
    });
  }
}

// =====================================================
// Pagination
// =====================================================

function renderPagination() {
  if (!DOM.pagination) return;
  
  const totalPages = Math.ceil(state.filteredArticles.length / CONFIG.articlesPerPage);
  
  if (totalPages <= 1) {
    DOM.pagination.style.display = 'none';
    return;
  }
  
  DOM.pagination.style.display = 'flex';
  
  // Update button states
  DOM.prevPage.disabled = state.currentPage === 1;
  DOM.nextPage.disabled = state.currentPage === totalPages;
  
  // Render page numbers
  let pageNumbersHTML = '';
  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || (i >= state.currentPage - 1 && i <= state.currentPage + 1)) {
      pageNumbersHTML += `<button class="page-number ${i === state.currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
    } else if (i === state.currentPage - 2 || i === state.currentPage + 2) {
      pageNumbersHTML += '<span style="color: var(--text-muted);">...</span>';
    }
  }
  
  DOM.pageNumbers.innerHTML = pageNumbersHTML;
}

function initPagination() {
  if (!DOM.pagination) return;
  
  DOM.prevPage.addEventListener('click', () => {
    if (state.currentPage > 1) {
      state.currentPage--;
      renderArticles();
      renderPagination();
      scrollToArticles();
    }
  });
  
  DOM.nextPage.addEventListener('click', () => {
    const totalPages = Math.ceil(state.filteredArticles.length / CONFIG.articlesPerPage);
    if (state.currentPage < totalPages) {
      state.currentPage++;
      renderArticles();
      renderPagination();
      scrollToArticles();
    }
  });
  
  DOM.pageNumbers.addEventListener('click', (e) => {
    if (e.target.classList.contains('page-number')) {
      state.currentPage = parseInt(e.target.dataset.page);
      renderArticles();
      renderPagination();
      scrollToArticles();
    }
  });
}

function scrollToArticles() {
  const section = document.querySelector('.articles-section');
  if (section) {
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

// =====================================================
// Newsletter
// =====================================================

function initNewsletter() {
  if (!DOM.newsletterForm) return;
  
  DOM.newsletterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = DOM.newsletterForm.querySelector('input[type="email"]').value;
    
    if (email) {
      showToast('Thanks for subscribing! Check your inbox soon.');
      DOM.newsletterForm.reset();
    }
  });
}

// =====================================================
// Category Page Initialization
// =====================================================

function initCategoryPageFromUrl() {
  if (getPageType() !== 'category') return;
  const params = new URLSearchParams(window.location.search);
  const cat = params.get('cat');
  if (cat) {
    state.currentPage = 1;
    applyCategory(cat.toLowerCase());
  } else {
    applyCategory('all');
  }
}

// =====================================================
// Article Page Rendering
// =====================================================

function initArticlePageFromUrl() {
  if (getPageType() !== 'article') return;

  const titleEl = document.getElementById('article-title');
  const excerptEl = document.getElementById('article-excerpt');
  const categoryEl = document.getElementById('article-category');
  const authorNameEl = document.getElementById('article-author-name');
  const authorAvatarEl = document.getElementById('article-author-avatar');
  const dateEl = document.getElementById('article-date');
  const readingTimeEl = document.getElementById('article-reading-time');
  const coverEl = document.getElementById('article-cover');
  const contentEl = document.getElementById('article-content');
  const tocEl = document.getElementById('article-toc');
  const asideEl = document.getElementById('article-aside');
  const relatedEl = document.getElementById('related-articles');

  if (!titleEl || !contentEl) return;

  const params = new URLSearchParams(window.location.search);
  const idParam = params.get('id');
  const slugParam = params.get('slug');
  const id = idParam ? Number(idParam) : null;

  let article = null;
  if (id) article = state.articles.find(a => a.id === id) || null;
  if (!article && slugParam) article = state.articles.find(a => a.slug === slugParam) || null;

  if (!article) {
    document.title = 'Article not found • acdcshirt';
    titleEl.textContent = 'Article not found';
    if (excerptEl) excerptEl.textContent = 'The link may be broken, or the article may have been moved.';
    contentEl.innerHTML = '<p>Try browsing from <a href="category.html">Categories</a>.</p>';
    if (asideEl) asideEl.style.display = 'none';
    return;
  }

  document.title = `${article.title} • acdcshirt`;

  if (categoryEl) categoryEl.textContent = article.category;
  titleEl.textContent = article.title;
  if (excerptEl) excerptEl.textContent = article.excerpt;
  if (authorNameEl) authorNameEl.textContent = article.author?.name || '';
  if (authorAvatarEl) {
    authorAvatarEl.src = article.author?.avatar || '';
    authorAvatarEl.alt = article.author?.name || '';
  }
  if (dateEl) dateEl.textContent = formatDate(article.date);
  if (readingTimeEl) readingTimeEl.textContent = `${article.readingTime} min read`;

  if (coverEl) {
    coverEl.innerHTML = `
      <img class="article-cover-image" src="${article.image}" alt="${escapeHtml(article.title)}" loading="eager">
    `;
  }

  const paragraphs = String(article.content || '')
    .split(/\n\s*\n/g)
    .map(p => p.trim())
    .filter(Boolean);

  // Create lightweight sections for TOC
  const sections = paragraphs.map((p, idx) => {
    const isFirst = idx === 0;
    const heading = isFirst ? 'Overview' : `Section ${idx + 1}`;
    const anchor = `sec-${idx + 1}-${slugify(heading)}`;
    return { heading, anchor, text: p };
  });

  contentEl.innerHTML = sections.map(s => `
    <section class="prose-section" id="${s.anchor}">
      <h2>${escapeHtml(s.heading)}</h2>
      <p>${escapeHtml(s.text)}</p>
    </section>
  `).join('');

  if (tocEl && asideEl && sections.length > 1) {
    tocEl.innerHTML = sections.map(s => `
      <a class="toc-link" href="#${s.anchor}">${escapeHtml(s.heading)}</a>
    `).join('');
  } else if (asideEl) {
    asideEl.style.display = 'none';
  }

  if (relatedEl) {
    const sameCategory = state.articles.filter(a => a.id !== article.id && a.category === article.category);
    const fallback = state.articles.filter(a => a.id !== article.id && a.trending);
    const related = (sameCategory.length ? sameCategory : fallback).slice(0, 3);
    relatedEl.innerHTML = related.map((a, idx) => articleCardHTML(a, idx)).join('');
  }
}

// =====================================================
// Contact Page Forms
// =====================================================

function initContactForms() {
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('Message received! (Demo form)');
      contactForm.reset();
    });
  }

  const pitchForm = document.getElementById('pitch-form');
  if (pitchForm) {
    pitchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('Pitch submitted! (Demo form)');
      pitchForm.reset();
    });
  }
}

// =====================================================
// Lazy Loading Images
// =====================================================

function initLazyLoad() {
  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          if (img.dataset.src) {
            img.src = img.dataset.src;
            img.classList.add('loaded');
            observer.unobserve(img);
          }
        }
      });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
      imageObserver.observe(img);
    });
  }
}

// =====================================================
// Smooth Scroll for Anchor Links
// =====================================================

function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
}

// =====================================================
// Initialize Application
// =====================================================

document.addEventListener('DOMContentLoaded', () => {
  // Initialize theme first
  initTheme();
  
  // Initialize components
  initHeader();
  initCategoryFilter();
  initPagination();
  initNewsletter();
  initLazyLoad();
  initSmoothScroll();
  initContactForms();
  
  // Load articles
  loadArticles();
});

// Handle visibility change for better performance
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') {
    // Pause animations or heavy operations
  }
});
