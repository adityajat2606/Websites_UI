/* ═══════════════════════════════════════════════
   utils.js — Shared helpers, storage, dark mode
   ═══════════════════════════════════════════════ */

// local storage keys – change when rebranding to avoid clashes
const STORAGE_KEY = 'ferrolith_articles';
// dark mode has been removed; previous key was 'ferrolith_dark'

// ── Storage ───────────────────────────────────
function getArticles() {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveArticles(articles) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
}

// dark mode functions removed; UI no longer supports theme toggling

// ── Helpers ───────────────────────────────────
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function readingTime(text) {
  const words = text.trim().split(/\s+/).length;
  return Math.max(1, Math.ceil(words / 200)) + ' min read';
}

function formatDate(ts) {
  return new Date(ts).toLocaleDateString('en-US', {
    month: 'long', day: 'numeric', year: 'numeric'
  });
}

function catClass(cat) {
  return 'cat-' + (cat || 'other');
}

function excerpt(body, len = 160) {
  const plain = body.replace(/[#>*_`\-]+/g, '').replace(/\n+/g, ' ').trim();
  return plain.length > len ? plain.slice(0, len) + '…' : plain;
}

function toast(msg) {
  let t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Markdown Renderer ─────────────────────────
function renderMarkdown(md) {
  return md
    .replace(/\r\n/g, '\n')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^### (.+)$/gm,
      '<h3 style="font-family:\'Playfair Display\',serif;font-size:1.2rem;font-weight:700;margin:1.5em 0 .5em">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
    .replace(/^- (.+)$/gm, '<li style="margin-bottom:.4em">$1</li>')
    .replace(/(<li[^>]*>.*<\/li>\n?)+/g,
      m => `<ul style="margin:1em 0 1em 1.5em;list-style-type:disc">${m}</ul>`)
    .replace(/^---$/gm,
      '<hr style="border:none;border-top:1px solid #e3d9c8;margin:2em 0">')
    .split(/\n\n+/)
    .map(block => {
      if (/^<(h[23]|ul|blockquote|hr)/.test(block.trim())) return block;
      const inner = block.replace(/\n/g, ' ').trim();
      return inner ? `<p>${inner}</p>` : '';
    })
    .join('\n');
}

// ── Authentication helpers ───────────────────
const USER_KEY  = 'ferrolith_user';
const USERS_KEY = 'ferrolith_users';

function getCurrentUser() {
  const raw = localStorage.getItem(USER_KEY);
  return raw ? JSON.parse(raw) : null;
}

function setCurrentUser(user) {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

function logout() {
  localStorage.removeItem(USER_KEY);
  toast('👋 Logged out');
  // refresh after brief delay so user sees toast
  setTimeout(() => location.reload(), 500);
}

function getUsers() {
  const raw = localStorage.getItem(USERS_KEY);
  return raw ? JSON.parse(raw) : {};
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function registerUser(name, password) {
  const users = getUsers();
  if (users[name]) return false; // already exists
  users[name] = { password };
  saveUsers(users);
  return true;
}

function validateUser(name, password) {
  const users = getUsers();
  return users[name] && users[name].password === password;
}

// ── Seed Data ─────────────────────────────────
function seedIfEmpty() {
  if (getArticles().length > 0) return;
  const seed = [
    {
      id: uid(),
      comments: [],
      body: `In an age where scrolling has become the default mode of consumption, the act of sitting down with a book — really *sitting down*, without a phone nearby — feels almost transgressive.

## The Tyranny of Throughput

We measure everything in output. Books read per year. Articles consumed. Podcasts completed at 2x speed. The metric of quantity has quietly colonized our relationship with ideas.

> "The best books are those that require the most of you — not the ones you finish fastest."

There's something deeply at odds between the pace of modern information and the pace at which genuine understanding forms. Understanding is slow. It needs incubation. It needs the idle hours between reading sessions when your subconscious is quietly assembling the pieces.

## What We Lose in the Rush

Speed-reading advocates will tell you that comprehension doesn't suffer at higher rates. But that misses the point entirely. The goal of reading isn't comprehension alone — it's transformation. And transformation, by its nature, takes time.

A single paragraph, read slowly and returned to, can change how you see the world. A hundred books skimmed cannot.

## A Practice, Not a Protest

This isn't a manifesto against technology. It's a quiet suggestion: give one hour a week to a book you read at the pace the words deserve. Notice what changes.`,
      author: "Eleanor Marsh", category: "culture",
      tags: ["books","reading","culture"], emoji: "📚",
      likes: 24, liked: false, created: Date.now() - 86400000 * 5, draft: false
    },
    {
      id: uid(),
      comments: [],
      title: "Why Boredom Is the Mother of Invention",
      subtitle: "The neuroscience of idle minds and creative breakthroughs.",
      body: `Ask any scientist, writer, or entrepreneur where their best ideas came from and you'll rarely hear "in a meeting." More often: in the shower. On a walk. Staring out a train window.

## The Default Mode Network

When your brain is "doing nothing," it's actually doing something remarkable. The default mode network — a cluster of regions active during rest — is deeply involved in imagination, planning, and self-reflection. It's where the future gets rehearsed and where disparate ideas form unexpected connections.

> "Boredom is the dream bird that hatches the egg of experience." — Walter Benjamin

The tragedy of perpetual stimulation is that we never give this network time to run. We fill every gap — every waiting room, every commute, every moment between tasks — with input. And in doing so, we starve the very faculty that makes us creative.

## Scheduling Emptiness

Some of the most productive people deliberately schedule "nothing time." Not meditation (though that helps too). Simply unstructured time with no agenda, no device, no podcast. Just themselves and their wandering mind.

This is uncomfortable at first. We're trained to feel guilty about stillness, to equate it with laziness. But comfort with boredom is, increasingly, a competitive advantage.`,
      author: "James Follett", category: "science",
      tags: ["creativity","neuroscience","productivity"], emoji: "🧠",
      likes: 41, liked: false, created: Date.now() - 86400000 * 3, draft: false
    },
    {
      id: uid(),
      comments: [],
      title: "The Hidden Costs of Free Software",
      subtitle: "Nothing on the internet is truly free — the question is what you're paying with.",
      body: `The phrase "if you're not paying for the product, you are the product" has become so familiar it's lost its bite. But consider what it actually describes.

## Attention as Currency

Every free service you use is financed by someone. And the most common financier is the advertiser. Advertisers pay for your attention. Your attention is directed toward things that make you want to buy things. And to maximize the value of your attention, platforms are engineered to capture as much of it as possible.

## The Design of Addiction

This isn't conspiracy — it's publicly documented. Former employees of major platforms have described rooms full of engineers whose sole job is to increase "engagement." Engagement is the sanitized word for compulsion.

> "The technologies we use have turned into compulsions, if not full-fledged addictions."

The notification dot. The infinite scroll. The variable-ratio reward schedule (the same mechanism that makes slot machines addictive) — these are deliberate design choices, not accidents.

## Toward a Healthier Relationship

None of this means you must delete every free service. But literacy about these mechanisms changes how you engage with them. You can use tools intentionally rather than being used by them.`,
      author: "Priya Nair", category: "technology",
      tags: ["tech","privacy","attention"], emoji: "💡",
      likes: 33, liked: false, created: Date.now() - 86400000, draft: false
    }
  ];
  saveArticles(seed);
}

// ── Highlight search match ────────────────────
function highlight(text, q) {
  if (!q) return text;
  const re = new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
  return text.replace(re,
    '<mark style="background:#fef3c7;color:#92400e;border-radius:2px;padding:0 2px">$1</mark>');
}

// ── Shared init (runs on every page) ─────────
document.addEventListener('DOMContentLoaded', () => {
  seedIfEmpty();
  // dark mode removed
  highlightActiveNav();
});

function highlightActiveNav() {
  const page = document.body.dataset.page;
  document.querySelectorAll('.nav-btn[data-page]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.page === page);
  });
}
