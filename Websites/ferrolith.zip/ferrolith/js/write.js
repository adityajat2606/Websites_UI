/* ═══════════════════════════════════════════════
   write.js — Write & Edit article page logic
   ═══════════════════════════════════════════════ */

let currentTags   = [];
let selectedEmoji = '📝';
let editingId     = null;

// ── Read URL to detect edit mode ──────────────
function initWritePage() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');

  if (id) {
    const articles = getArticles();
    const a = articles.find(x => x.id === id);
    const user = getCurrentUser && getCurrentUser();
    if (a) {
      if (!user || user.name !== a.author) {
        toast('⚠️ Only the author may edit this article');
        setTimeout(() => { window.location.href = `article.html?id=${id}`; }, 800);
        return;
      }
      editingId = id;
      document.getElementById('writePageTitle').textContent = 'Edit Article';
      document.title = 'Ferrolith — Edit Article';
      document.getElementById('articleTitle').value    = a.title;
      document.getElementById('articleSubtitle').value = a.subtitle || '';
      document.getElementById('articleBody').value     = a.body;
      document.getElementById('articleAuthor').value   = a.author || '';
      document.getElementById('articleCategory').value = a.category || 'other';
      currentTags   = [...(a.tags || [])];
      selectedEmoji = a.emoji || '📝';
      renderTagChips();
      document.querySelectorAll('.emoji-opt').forEach(el => {
        el.classList.toggle('selected', el.dataset.e === selectedEmoji);
      });
    }
  }
  // if logged in we lock author field to the username
  const user = getCurrentUser && getCurrentUser();
  if (user && user.name) {
    const authorEl = document.getElementById('articleAuthor');
    if (authorEl) {
      authorEl.value = user.name;
      authorEl.disabled = true;
      authorEl.style.opacity = '0.6';
    }
  }
}

// ── Collect Form Data ─────────────────────────
function getFormData() {
  const user = getCurrentUser && getCurrentUser();
  return {
    title:    document.getElementById('articleTitle').value.trim(),
    subtitle: document.getElementById('articleSubtitle').value.trim(),
    body:     document.getElementById('articleBody').value.trim(),
    author:   user && user.name ? user.name : document.getElementById('articleAuthor').value.trim(),
    category: document.getElementById('articleCategory').value,
    tags:     [...currentTags],
    emoji:    selectedEmoji,
  };
}

// ── Publish ───────────────────────────────────
function publishArticle() {
  const d = getFormData();
  if (!d.title) { toast('⚠️ Please add a title');    return; }
  if (!d.body)  { toast('⚠️ Please write something'); return; }

  const articles = getArticles();

  if (editingId) {
    const idx = articles.findIndex(a => a.id === editingId);
    if (idx !== -1) {
      articles[idx] = { ...articles[idx], ...d, draft: false };
      saveArticles(articles);
      toast('✅ Article updated!');
      setTimeout(() => { window.location.href = `article.html?id=${editingId}`; }, 800);
    }
  } else {
    const newArticle = {
      id: uid(), ...d,
      comments: [],
      likes: 0, liked: false,
      created: Date.now(), draft: false
    };
    articles.unshift(newArticle);
    saveArticles(articles);
    toast('🎉 Article published!');
    setTimeout(() => { window.location.href = `article.html?id=${newArticle.id}`; }, 800);
  }
}

// ── Save Draft ────────────────────────────────
function saveDraft() {
  const d = getFormData();
  if (!d.title && !d.body) { toast('⚠️ Nothing to save'); return; }

  const articles = getArticles();

  if (editingId) {
    const idx = articles.findIndex(a => a.id === editingId);
    if (idx !== -1) articles[idx] = { ...articles[idx], ...d };
  } else {
    const existing = articles.find(a => a.draft && a.title === d.title);
    if (existing) {
      Object.assign(existing, d);
    } else {
      articles.unshift({
        id: uid(), ...d,
        likes: 0, liked: false,
        created: Date.now(), draft: true
      });
    }
  }

  saveArticles(articles);
  const info = document.getElementById('draftInfo');
  info.style.display = 'block';
  info.textContent   = '💾 Draft saved at ' + new Date().toLocaleTimeString();
  toast('💾 Draft saved');
}

// ── Toolbar Format Insert ─────────────────────
function insertFormat(before, after) {
  const ta = document.getElementById('articleBody');
  const s  = ta.selectionStart;
  const e  = ta.selectionEnd;
  const sel = ta.value.slice(s, e);
  ta.value  = ta.value.slice(0, s) + before + sel + after + ta.value.slice(e);
  ta.focus();
  ta.selectionStart = s + before.length;
  ta.selectionEnd   = s + before.length + sel.length;
}

// ── Tags ──────────────────────────────────────
function initTagInput() {
  document.getElementById('tagInput').addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const val = e.target.value.trim().replace(/,/g, '');
      if (val && !currentTags.includes(val) && currentTags.length < 5) {
        currentTags.push(val);
        renderTagChips();
      }
      e.target.value = '';
    } else if (e.key === 'Backspace' && e.target.value === '' && currentTags.length > 0) {
      currentTags.pop();
      renderTagChips();
    }
  });
}

function renderTagChips() {
  document.getElementById('tagChips').innerHTML = currentTags.map((t, i) => `
    <span class="tag-chip">
      ${t}
      <span class="remove-tag" onclick="removeTag(${i})">✕</span>
    </span>`).join('');
}

function removeTag(i) {
  currentTags.splice(i, 1);
  renderTagChips();
}

// ── Emoji Picker ──────────────────────────────
function selectEmoji(e) {
  selectedEmoji = e;
  document.querySelectorAll('.emoji-opt').forEach(el => {
    el.classList.toggle('selected', el.dataset.e === e);
  });
}

// ── Auto‑save helpers ─────────────────────────
let autoSaveTimer;
function scheduleAutoSave() {
  clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(() => {
    saveDraft();
  }, 3000);
}

// Save when the user leaves the page just in case
window.addEventListener('beforeunload', () => {
  saveDraft();
});

// ── Init ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const user = getCurrentUser && getCurrentUser();
  if (!user) {
    // not authenticated, send to sign-in
    window.location.href = 'signin.html';
    return;
  }

  initWritePage();
  initTagInput();

  // hook up auto‑save on any form change
  ['articleTitle','articleSubtitle','articleBody','articleAuthor','articleCategory'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', scheduleAutoSave);
  });
  document.getElementById('tagInput').addEventListener('input', scheduleAutoSave);

  // disable publish button while saving so user can't spam it
  window.addEventListener('click', e => {
    const btn = e.target.closest('.btn-primary');
    if (btn && btn.textContent.trim().startsWith('Publish')) {
      btn.disabled = true;
      setTimeout(() => { btn.disabled = false; }, 1000);
    }
  });

  // keyboard shortcut for saving drafts
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      saveDraft();
    }
  });
});
