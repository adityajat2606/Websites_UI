/* ═══════════════════════════════════════════════
   search.js — Search page logic
   ═══════════════════════════════════════════════ */

let searchTimer;
function scheduleSearch() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(doSearch, 150);
}


function doSearch() {
  const q         = document.getElementById('searchInput').value.trim().toLowerCase();
  const resultsEl = document.getElementById('searchResults');
  const emptyEl   = document.getElementById('searchEmpty');
  const promptEl  = document.getElementById('searchPrompt');

  const clearBtn = document.getElementById('clearSearchBtn');
  if (!q) {
    resultsEl.innerHTML    = '';
    emptyEl.style.display  = 'none';
    promptEl.style.display = 'block';
    if (clearBtn) clearBtn.style.visibility = 'hidden';
    return;
  }
  promptEl.style.display = 'none';
  if (clearBtn) clearBtn.style.visibility = 'visible';

  const articles = getArticles();
  const results  = articles.filter(a => !a.draft && (
    a.title.toLowerCase().includes(q)               ||
    a.body.toLowerCase().includes(q)                ||
    (a.author   || '').toLowerCase().includes(q)    ||
    (a.subtitle || '').toLowerCase().includes(q)    ||
    a.category.includes(q)                          ||
    (a.tags || []).some(t => t.toLowerCase().includes(q))
  ));

  if (results.length === 0) {
    resultsEl.innerHTML   = '';
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';

  resultsEl.innerHTML = `
    <p style="font-family:'DM Sans',sans-serif;color:#9c8060;font-size:13px;margin-bottom:20px">
      ${results.length} result${results.length > 1 ? 's' : ''} for
      "<strong style="color:#503e2e">${q}</strong>"
    </p>
    <div style="display:flex;flex-direction:column;gap:16px">
      ${results.map(a => `
        <a class="article-card" href="article.html?id=${a.id}"
           style="display:grid;grid-template-columns:80px 1fr;overflow:hidden">
          <div class="cover-img" style="height:auto;min-height:80px;font-size:2rem">
            ${a.emoji || '📝'}
          </div>
          <div style="padding:16px 20px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
              <span class="cat-pill ${catClass(a.category)}" style="font-size:10px">${a.category}</span>
              <span style="font-family:'DM Sans',sans-serif;font-size:12px;color:#9c8060">
                ${readingTime(a.body)}
              </span>
            </div>
            <h3 class="font-display"
                style="font-size:1.05rem;font-weight:700;margin-bottom:4px;color:#1a1510">
              ${highlight(a.title, q)}
            </h3>
            <p style="font-size:12px;color:#7d6349;font-family:'DM Sans',sans-serif">
              ${highlight(excerpt(a.body, 100), q)}
            </p>
          </div>
        </a>`).join('')}
    </div>`;
}

function clearSearch() {
  document.getElementById('searchInput').value = '';
  doSearch();
}

// ── Focus search input on page load ──────────
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('searchInput');
  input.focus();
  // trigger initial search so the clear button is hidden
  doSearch();

  // allow hitting enter to run search (no form used)
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      doSearch();
    }
  });
});
