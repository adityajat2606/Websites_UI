/* ═══════════════════════════════════════════════
   navbar.js — Injects the shared navbar on every page
   ═══════════════════════════════════════════════ */

(function injectNavbar() {
  const html = `
  <div id="readProgress"></div>
  <div id="toast"></div>

  <nav id="navbar">
    <div class="navbar-inner">

      <a href="index.html" class="navbar-logo">
        <span class="navbar-logo-dot">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2 12L5 4l3 5 2-3 2 6" stroke="#fff" stroke-width="1.8"
                  stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </span>
        <span id="logoText">Ferrolith</span>
      </a>

      <div class="nav-links">
        <a class="nav-btn" data-page="home"   href="index.html">Home</a>
        <a class="nav-btn" data-page="search" href="search.html">Search</a>
        <a class="nav-btn" data-page="write"  href="write.html">Write</a>
      </div>

      <div style="display:flex;align-items:center;gap:12px">
        <span id="userInfo" style="font-size:14px;color:inherit"></span>
        <a class="btn-secondary" href="signin.html" style="padding:8px 16px;font-size:13px">Sign In</a>
        <a class="btn-primary" href="signup.html" style="padding:8px 16px;font-size:13px">Sign Up</a>
      </div>

    </div>
  </nav>
  <div class="navbar-spacer"></div>`;

  document.body.insertAdjacentHTML('afterbegin', html);

  // update nav user display after HTML insertion
  function refreshUserInfo() {
    const user = getCurrentUser && getCurrentUser();
    const info = document.getElementById('userInfo');
    if (!info) return;
    const signInLink = document.querySelector('a[href="signin.html"]');
    const signUpLink = document.querySelector('a[href="signup.html"]');
    if (user && user.name) {
      info.innerHTML = `Hello, ${user.name} <button onclick="logout()" class="btn-secondary" style="padding:4px 8px;font-size:12px;vertical-align:middle">Log out</button>`;
      if (signInLink) signInLink.style.display = 'none';
      if (signUpLink) signUpLink.style.display = 'none';
    } else {
      info.innerHTML = '';
      if (signInLink) signInLink.style.display = '';
      if (signUpLink) signUpLink.style.display = '';
    }
  }
  document.addEventListener('DOMContentLoaded', () => {
    refreshUserInfo();
    // hide write link when not signed in
    const writeLink = document.querySelector('.nav-btn[data-page="write"]');
    const user = getCurrentUser && getCurrentUser();
    if (writeLink) writeLink.style.display = user ? '' : 'none';
  });

  // footer injection runs once per page; put at end of body so scripts are still
  // below the footer when written to disk (some pages include inline script tags).
  function renderFooter() {
    const user = getCurrentUser && getCurrentUser();
    let links = '';
    if (user && user.name) {
      links = `Logged in as <strong>${user.name}</strong> &bull; <button onclick="logout()" class="btn-secondary" style="padding:4px 8px;font-size:12px;vertical-align:middle">Log out</button>`;
    } else {
      links = `<a href="signin.html">Sign In</a> | <a href="signup.html">Sign Up</a>`;
    }
    const footerHtml = `
    <footer class="site-footer">
      <div style="max-width:1200px;margin:0 auto;padding:24px;color:#9c8060;font-size:14px;text-align:center">
        © ${new Date().getFullYear()} Ferrolith. All rights reserved. ${links}
      </div>
    </footer>`;
    document.body.insertAdjacentHTML('beforeend', footerHtml);
  }
  document.addEventListener('DOMContentLoaded', renderFooter);
})();
