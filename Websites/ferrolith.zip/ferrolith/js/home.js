/* ═══════════════════════════════════════════════
   home.js — Home page: article feed & category filter
   ═══════════════════════════════════════════════ */

// current category filter; try to load last selection from storage so
// returning visitors get the same view they left.
// remember filter selection between visits using a brand‑specific key
let currentFilter = localStorage.getItem('ferrolith_filter') || 'all';

// ── Render Feed ───────────────────────────────
function renderHome() {
  const all = getArticles();
  const filtered = currentFilter === 'all'
    ? all.filter(a => !a.draft)
    : all.filter(a => !a.draft && a.category === currentFilter);

  filtered.sort((a, b) => b.created - a.created);

  const featuredEl = document.getElementById('featuredArticle');
  const gridEl     = document.getElementById('articleGrid');
  const emptyEl    = document.getElementById('emptyState');

  // fade out existing content before we mutate the DOM so the transition
  // has a chance to run
  if (featuredEl) featuredEl.style.opacity = '0';
  if (gridEl) gridEl.style.opacity = '0';

  if (filtered.length === 0) {
    featuredEl.innerHTML = '';
    gridEl.innerHTML = '';
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';

  // Most liked → featured
  const featured = [...filtered].sort((a, b) => b.likes - a.likes)[0];
  const rest     = filtered.filter(a => a.id !== featured.id);

  featuredEl.innerHTML = `
    <a class="featured-card" href="article.html?id=${featured.id}">
      <div class="cover-img" style="height:auto;min-height:260px;font-size:4rem">${featured.emoji || '📝'}</div>
      <div style="padding:36px 32px;display:flex;flex-direction:column;justify-content:center">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
          <span class="section-label">Featured</span>
          <span class="cat-pill ${catClass(featured.category)}">${featured.category}</span>
        </div>
        <h2 class="font-display"
            style="font-size:1.7rem;font-weight:700;line-height:1.2;margin-bottom:12px;color:#1a1510">
          ${featured.title}
        </h2>
        <p style="font-family:'DM Sans',sans-serif;color:#7d6349;font-size:0.95rem;line-height:1.6;margin-bottom:20px">
          ${featured.subtitle || excerpt(featured.body)}
        </p>
        <div style="display:flex;align-items:center;gap:14px;font-family:'DM Sans',sans-serif;font-size:13px;color:#9c8060">
          <span>By <strong style="color:#503e2e">${featured.author || 'Anonymous'}</strong></span>
          <span>·</span>
          <span>${readingTime(featured.body)}</span>
          <span>·</span>
          <span>❤️ ${featured.likes}</span>
        </div>
      </div>
    </a>`;

  gridEl.innerHTML = rest.map(a => `
    <a class="article-card" href="article.html?id=${a.id}">
      <div class="cover-img">${a.emoji || '📝'}</div>
      <div style="padding:20px 22px 22px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
          <span class="cat-pill ${catClass(a.category)}">${a.category}</span>
          <span style="font-family:'DM Sans',sans-serif;font-size:12px;color:#9c8060">${readingTime(a.body)}</span>
        </div>
        <h3 class="font-display"
            style="font-size:1.2rem;font-weight:700;line-height:1.3;margin-bottom:8px;color:#1a1510">
          ${a.title}
        </h3>
        <p style="font-size:13px;color:#7d6349;line-height:1.55;margin-bottom:16px;font-family:'DM Sans',sans-serif">
          ${excerpt(a.subtitle || a.body, 110)}
        </p>
        <div style="display:flex;align-items:center;justify-content:space-between;
                    font-family:'DM Sans',sans-serif;font-size:12px;color:#9c8060">
          <span>${a.author || 'Anonymous'}</span>
          <span>${a.liked ? '❤️' : '🤍'} ${a.likes}</span>
        </div>
      </div>
    </a>`).join('');

  // fade content back in after a tick
  setTimeout(() => {
    if (featuredEl) featuredEl.style.opacity = '1';
    if (gridEl) gridEl.style.opacity = '1';
  }, 50);
}

// ── Category Filter ───────────────────────────
function filterCategory(cat) {
  currentFilter = cat;
  localStorage.setItem('ferrolith_filter', cat);
  document.querySelectorAll('.cat-btn').forEach(b => {
    const active = b.dataset.cat === cat;
    if (active) {
      b.style.background = '#3a2d21';
      b.style.color = '#faf8f5';
    } else {
      b.style.removeProperty('background');
      b.style.removeProperty('color');
    }
  });

  // if the user clicked while scrolled down, make sure feed is visible
  const feed = document.getElementById('feed-section');
  if (feed) feed.scrollIntoView({ behavior: 'smooth' });

  renderHome();
}

// ── Init ──────────────────────────────────────
// When the page loads we want to ensure the category filter reflects the
// current state (defaults to "all") and render the feed accordingly. We
// call `filterCategory` because it handles both the button styling and the
// rendering, rather than just invoking `renderHome` directly.
document.addEventListener('DOMContentLoaded', () => {
  filterCategory(currentFilter);

  // adjust call-to-action depending on whether a user is signed in
  const startBtn = document.getElementById('startWriteBtn');
  const user = getCurrentUser && getCurrentUser();
  if (startBtn) {
    if (user) {
      startBtn.href = 'write.html';
    } else {
      startBtn.href = 'signin.html';
      startBtn.textContent = 'Sign in to write';
    }
  }
});
