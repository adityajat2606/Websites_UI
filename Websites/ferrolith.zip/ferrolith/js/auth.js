/* auth.js — lightweight client‑side sign in/up wrappers */
// depends on utils.toast, getCurrentUser, setCurrentUser, logout from utils.js

function handleSignIn(e) {
  e.preventDefault();
  const name = document.getElementById('signinName').value.trim();
  const pwd  = document.getElementById('signinPassword').value;
  if (!name || !pwd) {
    toast('⚠️ Please enter both name and password');
    return;
  }
  if (!validateUser(name, pwd)) {
    toast('⚠️ Invalid credentials');
    return;
  }
  setCurrentUser({ name });
  toast('👋 Welcome back, ' + name + '!');
  setTimeout(() => { window.location.href = 'index.html'; }, 800);
}

function handleSignUp(e) {
  e.preventDefault();
  const name = document.getElementById('signupName').value.trim();
  const pwd  = document.getElementById('signupPassword').value;
  if (!name || !pwd) {
    toast('⚠️ Name and password are required');
    return;
  }
  if (!registerUser(name, pwd)) {
    toast('⚠️ Username already taken');
    return;
  }
  setCurrentUser({ name });
  toast('🎉 Account created! Hello ' + name);
  setTimeout(() => { window.location.href = 'index.html'; }, 800);
}

document.addEventListener('DOMContentLoaded', () => {
  const signinForm = document.getElementById('signinForm');
  if (signinForm) signinForm.addEventListener('submit', handleSignIn);
  const signupForm = document.getElementById('signupForm');
  if (signupForm) signupForm.addEventListener('submit', handleSignUp);
});