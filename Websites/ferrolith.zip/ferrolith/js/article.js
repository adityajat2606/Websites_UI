/* ═══════════════════════════════════════════════
   article.js — Single article reader page logic
   ═══════════════════════════════════════════════ */

let deleteTargetId = null;

// ── Load Article from URL param ───────────────
function loadArticle() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  if (!id) { window.location.href = 'index.html'; return; }

  const articles = getArticles();
  const a = articles.find(x => x.id === id);
  if (!a) { window.location.href = 'index.html'; return; }

  // Update page title
  document.title = `${a.title} — Ferrolith`;

  // ── Header ──
  document.getElementById('articleHeader').innerHTML = `
    <div style="margin-bottom:8px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <span class="cat-pill ${catClass(a.category)}">${a.category}</span>
      <span style="font-family:'DM Sans',sans-serif;font-size:13px;color:#9c8060">${readingTime(a.body)}</span>
      <span style="font-family:'DM Sans',sans-serif;font-size:13px;color:#9c8060">·</span>
      <span style="font-family:'DM Sans',sans-serif;font-size:13px;color:#9c8060">${formatDate(a.created)}</span>
    </div>
    <h1 class="font-display"
        style="font-size:clamp(1.8rem,4vw,2.8rem);font-weight:700;line-height:1.15;margin-bottom:16px;color:#1a1510">
      ${a.title}
    </h1>
    ${a.subtitle
      ? `<p class="font-body" style="font-size:1.15rem;font-style:italic;color:#7d6349;line-height:1.6;margin-bottom:20px">${a.subtitle}</p>`
      : ''}
    <div style="display:flex;align-items:center;gap:12px;font-family:'DM Sans',sans-serif">
      <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#c0392b,#e74c3c);
                  display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:14px">
        ${(a.author || 'A').charAt(0).toUpperCase()}
      </div>
      <div>
        <p style="font-size:14px;font-weight:600;color:#503e2e">${a.author || 'Anonymous'}</p>
        <p style="font-size:12px;color:#9c8060">${formatDate(a.created)}</p>
      </div>
    </div>`;

  // ── Body ──
  document.getElementById('articleBodyView').innerHTML = renderMarkdown(a.body);

  // ── Author card ──
  document.getElementById('articleAuthorCard').textContent = a.author || 'Anonymous';

  // ── Tags ──
  document.getElementById('articleTagsView').innerHTML =
    (a.tags || []).map(t => `<span class="tag-chip">🏷 ${t}</span>`).join('');

  // ── Like section ──
  renderLike(a);

  // ── Edit / Delete buttons ──
  const user = getCurrentUser && getCurrentUser();
  const canModify = user && user.name && user.name === a.author;
  const editBtn = document.getElementById('editArticleBtn');
  const delBtn  = document.getElementById('deleteArticleBtn');
  if (!canModify) {
    if (editBtn) editBtn.style.display = 'none';
    if (delBtn)  delBtn.style.display = 'none';
  } else {
    if (editBtn) editBtn.addEventListener('click', () => {
      window.location.href = `write.html?id=${a.id}`;
    });
    if (delBtn) delBtn.addEventListener('click', () => {
      openDeleteModal(a.id);
    });
  }

  // ── Reading progress ──
  setupProgress();
}

// ── Like ──────────────────────────────────────
function renderLike(a) {
  document.getElementById('likeSection').innerHTML = `
    <button class="like-btn ${a.liked ? 'liked' : ''}" onclick="toggleLike('${a.id}')">
      <span class="heart">${a.liked ? '❤️' : '🤍'}</span>
      <span style="font-size:14px;font-weight:500;color:#7d6349;font-family:'DM Sans',sans-serif">
        ${a.likes} likes
      </span>
    </button>`;
}

function toggleLike(id) {
  const articles = getArticles();
  const a = articles.find(x => x.id === id);
  if (!a) return;
  a.liked  = !a.liked;
  a.likes += a.liked ? 1 : -1;
  saveArticles(articles);
  renderLike(a);
  if (a.liked) toast('❤️ You liked this article!');
}

// ── Delete Modal ──────────────────────────────
function openDeleteModal(id) {
  deleteTargetId = id;
  document.getElementById('deleteModal').classList.add('open');
  document.getElementById('confirmDeleteBtn').onclick = confirmDelete;
}

function closeDeleteModal() {
  document.getElementById('deleteModal').classList.remove('open');
  deleteTargetId = null;
}

function confirmDelete() {
  const articles = getArticles().filter(a => a.id !== deleteTargetId);
  saveArticles(articles);
  closeDeleteModal();
  toast('🗑 Article deleted');
  setTimeout(() => { window.location.href = 'index.html'; }, 1000);
}

// ── Reading Progress Bar ──────────────────────
function setupProgress() {
  const bar = document.getElementById('readProgress');
  window.addEventListener('scroll', () => {
    const total = document.body.scrollHeight - window.innerHeight;
    const pct   = total > 0 ? (window.scrollY / total) * 100 : 0;
    bar.style.width = Math.min(100, pct) + '%';
  });
}

// ── Comments helpers ───────────────────────
function commentHtml(c, articleId) {
  const user = getCurrentUser && getCurrentUser();
  let controls = '';
  if (user && user.name === c.author) {
    controls = `<span style="float:right;font-size:12px">
                  <a href="#" onclick="editComment('${articleId}','${c.id}');return false">✏️</a>
                  <a href="#" onclick="deleteComment('${articleId}','${c.id}');return false">🗑</a>
                </span>`;
  }
  let attachHtml = '';
  if (c.attachment) {
    if (/^data:image/.test(c.attachment.data)) {
      attachHtml = `<div style="margin-top:8px"><img src="${c.attachment.data}" alt="${c.attachment.name}" style="max-width:100%;" /></div>`;
    } else {
      attachHtml = `<div style="margin-top:8px"><a href="${c.attachment.data}" download="${c.attachment.name}">${c.attachment.name}</a></div>`;
    }
  }
  return `
    <div class="comment" style="border-top:1px solid #e3d9c8;padding:12px 0;position:relative">
      ${controls}
      <p style="font-size:14px;font-weight:600;color:#503e2e">${c.author}</p>
      <p style="font-size:13px;color:#3a2d21;white-space:pre-wrap">${c.body}</p>
      ${attachHtml}
      <p style="font-size:11px;color:#9c8060">${formatDate(c.created)}</p>
    </div>
  `;
}

function renderComments(a) {
  const user = getCurrentUser && getCurrentUser();
  const section = document.getElementById('commentsSection');
  if (!section) return;
  let html = '';
  if (user && user.name) {
    html += `<div style="margin-bottom:24px">
      <textarea id="newComment" placeholder="Leave a comment..." style="width:100%;min-height:80px"></textarea>
      <input id="commentFile" type="file" style="margin-top:8px" />
      <button class="btn-primary" style="margin-top:8px" onclick="postComment('${a.id}')">Post comment</button>
    </div>`;
  } else {
    html += `<p style="color:#9c8060;font-size:14px">Sign in to leave a comment.</p>`;
  }
  const comments = a.comments || [];
  html += comments.map(c => commentHtml(c, a.id)).join('');
  section.innerHTML = html;
}

function postComment(articleId) {
  // support both inline and modal textarea
  let textarea = document.getElementById('newComment');
  if (!textarea) textarea = document.getElementById('modalNewComment');
  const text = textarea && textarea.value.trim();
  if (!text) { toast('⚠️ Comment cannot be empty'); return; }
  const user = getCurrentUser && getCurrentUser();
  if (!user) { toast('⚠️ Please sign in'); return; }
  const fileInput = document.getElementById('commentFile');
  const file = fileInput && fileInput.files && fileInput.files[0];

  const saveAndRender = (attachment) => {
    const articles = getArticles();
    const a = articles.find(x => x.id === articleId);
    if (!a) return;
    const comment = { id: uid(), author: user.name, body: text, created: Date.now() };
    if (attachment) comment.attachment = attachment;
    a.comments = a.comments || [];
    a.comments.push(comment);
    saveArticles(articles);
    textarea.value = '';
    if (fileInput) fileInput.value = '';
    renderComments(a);
    toast('💬 Comment posted');
  };

  if (file) {
    const reader = new FileReader();
    reader.onload = () => {
      saveAndRender({ name: file.name, data: reader.result });
    };
    reader.readAsDataURL(file);
  } else {
    saveAndRender(null);
  }
}

// ── Sticky comment helper ───────────────────
function setupCommentToggle() {
  const section = document.getElementById('commentsSection');
  if (!section) return;
  // create button
  const btn = document.createElement('button');
  btn.textContent = '💬 Comments';
  btn.className = 'comment-toggle-btn';
  btn.onclick = () => {
    const user = getCurrentUser && getCurrentUser();
    if (!user) {
      toast('🔒 Please sign in to comment');
      setTimeout(() => { window.location.href = 'signin.html'; }, 800);
      return;
    }
    // always try to open a modal in addition to scrolling
    openCommentModal();
    section.scrollIntoView({ behavior: 'smooth' });
    const ta = document.getElementById('newComment');
    if (ta) ta.focus();
  };
  document.body.appendChild(btn);

  const toggleVisibility = () => {
    const rect = section.getBoundingClientRect();
    // show when section is below viewport or above (not visible)
    if (rect.top > window.innerHeight || rect.bottom < 0) {
      btn.style.display = 'block';
    } else {
      btn.style.display = 'none';
    }
  };
  window.addEventListener('scroll', toggleVisibility);
  toggleVisibility();
}

// ── Comment modal helper ───────────────────
function openCommentModal() {
  const articleId = new URLSearchParams(window.location.search).get('id');
  const articles = getArticles();
  const a = articles.find(x => x.id === articleId) || {};
  let modal = document.getElementById('commentModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'commentModal';
    modal.style = `
      position:fixed;inset:0;background:rgba(0,0,0,0.6);
      display:flex;align-items:center;justify-content:center;z-index:10001;`;
    modal.innerHTML = `
      <div style="background:#faf8f5;padding:24px;border-radius:6px;max-width:500px;width:90%;position:relative;max-height:80vh;overflow:auto">
        <button onclick="document.getElementById('commentModal').style.display='none'" 
                style="position:absolute;top:8px;right:8px;border:none;background:none;font-size:18px;cursor:pointer">✕</button>
        <div id="modalCommentContent"></div>
      </div>`;
    document.body.appendChild(modal);
  }
  // build content manually
  const modalContent = document.getElementById('modalCommentContent');
  if (modalContent) {
    let html = '';
    // show form
    html += `<div style="margin-bottom:24px">
      <textarea id="modalNewComment" placeholder="Leave a comment..." style="width:100%;min-height:80px"></textarea>
      <input id="modalCommentFile" type="file" style="margin-top:8px" />
      <button class="btn-primary" style="margin-top:8px" onclick="postComment('${articleId}')">Post comment</button>
    </div>`;
    // existing comments
    const comments = a.comments || [];
    html += comments.map(c => commentHtml(c, a.id)).join('');
    modalContent.innerHTML = html;
  }
  modal.style.display = 'flex';
}

// ── Comment modification helpers ────────────
function deleteComment(articleId, commentId) {
  const articles = getArticles();
  const a = articles.find(x => x.id === articleId);
  if (!a) return;
  a.comments = (a.comments || []).filter(c => c.id !== commentId);
  saveArticles(articles);
  if (document.body.dataset.page === 'article') renderComments(a);
  // if modal is open refresh it too
  if (document.getElementById('commentModal') && document.getElementById('commentModal').style.display === 'flex') {
    openCommentModal();
  }
  toast('🗑 Comment deleted');
}

function editComment(articleId, commentId) {
  const articles = getArticles();
  const a = articles.find(x => x.id === articleId);
  if (!a) return;
  const c = (a.comments || []).find(x => x.id === commentId);
  if (!c) return;
  const newText = prompt('Edit your comment', c.body);
  if (newText !== null) {
    const trimmed = newText.trim();
    if (!trimmed) { toast('⚠️ Comment cannot be empty'); return; }
    c.body = trimmed;
    saveArticles(articles);
    if (document.body.dataset.page === 'article') renderComments(a);
    if (document.getElementById('commentModal') && document.getElementById('commentModal').style.display === 'flex') {
      openCommentModal();
    }
    toast('✏️ Comment updated');
  }
}

// ── Init ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadArticle();

  document.getElementById('deleteModal').addEventListener('click', function (e) {
    if (e.target === this) closeDeleteModal();
  });

  // after loading we want sticky comment button
  setupCommentToggle();
});
