// ─── Bumapo Main JS ───────────────────────────────────────────────────────────

// ── Auth System ───────────────────────────────────────────────────────────────
const Auth = {
  USERS_KEY: 'bumapo_users',
  SESSION_KEY: 'bumapo_session',

  getUsers() {
    return JSON.parse(localStorage.getItem(this.USERS_KEY) || '[]');
  },

  saveUsers(users) {
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
  },

  getCurrentUser() {
    const session = localStorage.getItem(this.SESSION_KEY);
    return session ? JSON.parse(session) : null;
  },

  isLoggedIn() {
    return !!this.getCurrentUser();
  },

  register(name, email, password) {
    const users = this.getUsers();
    if (users.find(u => u.email === email)) {
      return { success: false, error: 'An account with this email already exists.' };
    }
    const user = {
      id: Date.now(),
      name,
      email,
      password: btoa(password), // simple encoding (not real security)
      avatar: name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2),
      bio: '',
      joinDate: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      articlesWritten: 0,
      savedArticles: []
    };
    users.push(user);
    this.saveUsers(users);
    this.setSession(user);
    return { success: true, user };
  },

  login(email, password) {
    const users = this.getUsers();
    const user = users.find(u => u.email === email && u.password === btoa(password));
    if (!user) {
      return { success: false, error: 'Invalid email or password.' };
    }
    this.setSession(user);
    return { success: true, user };
  },

  logout() {
    localStorage.removeItem(this.SESSION_KEY);
    window.location.href = 'index.html';
  },

  setSession(user) {
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(user));
  },

  updateUser(updates) {
    const current = this.getCurrentUser();
    if (!current) return false;
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === current.id);
    if (idx === -1) return false;
    Object.assign(users[idx], updates);
    this.saveUsers(users);
    this.setSession(users[idx]);
    return true;
  }
};

// ── Toast Notifications ────────────────────────────────────────────────────────
const Toast = {
  container: null,

  init() {
    if (!document.getElementById('toast-container')) {
      this.container = document.createElement('div');
      this.container.id = 'toast-container';
      this.container.style.cssText = `
        position: fixed; top: 24px; right: 24px; z-index: 9999;
        display: flex; flex-direction: column; gap: 12px; pointer-events: none;
      `;
      document.body.appendChild(this.container);
    } else {
      this.container = document.getElementById('toast-container');
    }
  },

  show(message, type = 'info', duration = 3500) {
    this.init();
    const colors = {
      success: { bg: '#d1fae5', border: '#10b981', text: '#065f46', icon: '✓' },
      error: { bg: '#fee2e2', border: '#ef4444', text: '#991b1b', icon: '✕' },
      info: { bg: '#e0f2fe', border: '#0ea5e9', text: '#0c4a6e', icon: 'ℹ' },
      warning: { bg: '#fef3c7', border: '#f59e0b', text: '#78350f', icon: '!' }
    };
    const c = colors[type] || colors.info;
    const toast = document.createElement('div');
    toast.style.cssText = `
      background: ${c.bg}; border: 1.5px solid ${c.border}; color: ${c.text};
      padding: 14px 20px; border-radius: 12px; font-family: 'Lora', Georgia, serif;
      font-size: 14px; font-weight: 500; pointer-events: all;
      box-shadow: 0 8px 32px rgba(0,0,0,0.12);
      display: flex; align-items: center; gap: 10px; min-width: 280px; max-width: 380px;
      transform: translateX(120%); transition: transform 0.3s cubic-bezier(0.34,1.56,0.64,1);
    `;
    toast.innerHTML = `<span style="font-size:16px;font-weight:700;">${c.icon}</span><span>${message}</span>`;
    this.container.appendChild(toast);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => { toast.style.transform = 'translateX(0)'; });
    });
    setTimeout(() => {
      toast.style.transform = 'translateX(120%)';
      setTimeout(() => toast.remove(), 350);
    }, duration);
  }
};

// ── Modal System ───────────────────────────────────────────────────────────────
const Modal = {
  overlay: null,

  create(content, options = {}) {
    this.close();
    const overlay = document.createElement('div');
    overlay.id = 'modal-overlay';
    overlay.style.cssText = `
      position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 8888;
      display: flex; align-items: center; justify-content: center;
      padding: 20px; backdrop-filter: blur(6px);
      animation: fadeIn 0.2s ease;
    `;
    const box = document.createElement('div');
    box.style.cssText = `
      background: #fff; border-radius: 20px; padding: 40px;
      max-width: ${options.maxWidth || '480px'}; width: 100%;
      max-height: 90vh; overflow-y: auto;
      animation: slideUp 0.3s cubic-bezier(0.34,1.56,0.64,1);
      position: relative;
    `;
    box.innerHTML = content;
    overlay.appendChild(box);
    overlay.addEventListener('click', e => { if (e.target === overlay) this.close(); });
    document.body.appendChild(overlay);
    this.overlay = overlay;
    document.body.style.overflow = 'hidden';
  },

  close() {
    const existing = document.getElementById('modal-overlay');
    if (existing) existing.remove();
    document.body.style.overflow = '';
    this.overlay = null;
  }
};

// ── Auth Modal ─────────────────────────────────────────────────────────────────
function openAuthModal(initialTab = 'login') {
  const html = `
    <button onclick="Modal.close()" style="position:absolute;top:16px;right:20px;background:none;border:none;font-size:24px;cursor:pointer;color:#999;line-height:1;">×</button>
    <div style="text-align:center;margin-bottom:28px;">
      <div style="font-family:'Playfair Display',Georgia,serif;font-size:28px;font-weight:700;color:#111;letter-spacing:-0.5px;">Bumapo</div>
      <div style="color:#888;font-size:13px;margin-top:4px;font-family:'Lora',Georgia,serif;">Your space to read & write</div>
    </div>
    <div style="display:flex;background:#f5f5f5;border-radius:12px;padding:4px;margin-bottom:28px;">
      <button id="tab-login" onclick="switchAuthTab('login')" style="flex:1;padding:10px;border:none;border-radius:8px;font-family:'Lora',Georgia,serif;font-weight:600;font-size:14px;cursor:pointer;transition:all 0.2s;background:${initialTab==='login'?'#fff':'transparent'};color:${initialTab==='login'?'#111':'#888'};box-shadow:${initialTab==='login'?'0 2px 8px rgba(0,0,0,0.1)':'none'};">Sign In</button>
      <button id="tab-register" onclick="switchAuthTab('register')" style="flex:1;padding:10px;border:none;border-radius:8px;font-family:'Lora',Georgia,serif;font-weight:600;font-size:14px;cursor:pointer;transition:all 0.2s;background:${initialTab==='register'?'#fff':'transparent'};color:${initialTab==='register'?'#111':'#888'};box-shadow:${initialTab==='register'?'0 2px 8px rgba(0,0,0,0.1)':'none'};">Create Account</button>
    </div>
    <div id="auth-form-container">
      ${initialTab === 'login' ? loginFormHTML() : registerFormHTML()}
    </div>
  `;
  Modal.create(html);
}

function loginFormHTML() {
  return `
    <div id="login-form">
      <div style="margin-bottom:18px;">
        <label style="display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px;font-family:'Lora',Georgia,serif;">Email</label>
        <input id="login-email" type="email" placeholder="you@example.com" style="width:100%;padding:12px 16px;border:1.5px solid #e5e5e5;border-radius:10px;font-size:15px;font-family:'Lora',Georgia,serif;outline:none;box-sizing:border-box;transition:border 0.2s;" onfocus="this.style.borderColor='#111'" onblur="this.style.borderColor='#e5e5e5'">
      </div>
      <div style="margin-bottom:24px;">
        <label style="display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px;font-family:'Lora',Georgia,serif;">Password</label>
        <input id="login-password" type="password" placeholder="Your password" style="width:100%;padding:12px 16px;border:1.5px solid #e5e5e5;border-radius:10px;font-size:15px;font-family:'Lora',Georgia,serif;outline:none;box-sizing:border-box;transition:border 0.2s;" onfocus="this.style.borderColor='#111'" onblur="this.style.borderColor='#e5e5e5'" onkeydown="if(event.key==='Enter')doLogin()">
      </div>
      <button onclick="doLogin()" style="width:100%;padding:14px;background:#111;color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;font-family:'Lora',Georgia,serif;letter-spacing:0.3px;transition:all 0.2s;" onmouseover="this.style.background='#333'" onmouseout="this.style.background='#111'">Sign In →</button>
      <div id="login-error" style="margin-top:12px;color:#ef4444;font-size:13px;font-family:'Lora',Georgia,serif;text-align:center;display:none;"></div>
    </div>
  `;
}

function registerFormHTML() {
  return `
    <div id="register-form">
      <div style="margin-bottom:18px;">
        <label style="display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px;font-family:'Lora',Georgia,serif;">Full Name</label>
        <input id="reg-name" type="text" placeholder="Your full name" style="width:100%;padding:12px 16px;border:1.5px solid #e5e5e5;border-radius:10px;font-size:15px;font-family:'Lora',Georgia,serif;outline:none;box-sizing:border-box;transition:border 0.2s;" onfocus="this.style.borderColor='#111'" onblur="this.style.borderColor='#e5e5e5'">
      </div>
      <div style="margin-bottom:18px;">
        <label style="display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px;font-family:'Lora',Georgia,serif;">Email</label>
        <input id="reg-email" type="email" placeholder="you@example.com" style="width:100%;padding:12px 16px;border:1.5px solid #e5e5e5;border-radius:10px;font-size:15px;font-family:'Lora',Georgia,serif;outline:none;box-sizing:border-box;transition:border 0.2s;" onfocus="this.style.borderColor='#111'" onblur="this.style.borderColor='#e5e5e5'">
      </div>
      <div style="margin-bottom:24px;">
        <label style="display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px;font-family:'Lora',Georgia,serif;">Password</label>
        <input id="reg-password" type="password" placeholder="Min. 6 characters" style="width:100%;padding:12px 16px;border:1.5px solid #e5e5e5;border-radius:10px;font-size:15px;font-family:'Lora',Georgia,serif;outline:none;box-sizing:border-box;transition:border 0.2s;" onfocus="this.style.borderColor='#111'" onblur="this.style.borderColor='#e5e5e5'" onkeydown="if(event.key==='Enter')doRegister()">
      </div>
      <button onclick="doRegister()" style="width:100%;padding:14px;background:#111;color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;font-family:'Lora',Georgia,serif;letter-spacing:0.3px;transition:all 0.2s;" onmouseover="this.style.background='#333'" onmouseout="this.style.background='#111'">Create Account →</button>
      <div id="reg-error" style="margin-top:12px;color:#ef4444;font-size:13px;font-family:'Lora',Georgia,serif;text-align:center;display:none;"></div>
    </div>
  `;
}

function switchAuthTab(tab) {
  document.getElementById('tab-login').style.background = tab === 'login' ? '#fff' : 'transparent';
  document.getElementById('tab-login').style.color = tab === 'login' ? '#111' : '#888';
  document.getElementById('tab-login').style.boxShadow = tab === 'login' ? '0 2px 8px rgba(0,0,0,0.1)' : 'none';
  document.getElementById('tab-register').style.background = tab === 'register' ? '#fff' : 'transparent';
  document.getElementById('tab-register').style.color = tab === 'register' ? '#111' : '#888';
  document.getElementById('tab-register').style.boxShadow = tab === 'register' ? '0 2px 8px rgba(0,0,0,0.1)' : 'none';
  document.getElementById('auth-form-container').innerHTML = tab === 'login' ? loginFormHTML() : registerFormHTML();
}

function doLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const errEl = document.getElementById('login-error');
  if (!email || !password) {
    errEl.textContent = 'Please fill in all fields.';
    errEl.style.display = 'block'; return;
  }
  const result = Auth.login(email, password);
  if (result.success) {
    Modal.close();
    Toast.show(`Welcome back, ${result.user.name.split(' ')[0]}!`, 'success');
    setTimeout(() => updateNavForAuth(), 100);
  } else {
    errEl.textContent = result.error;
    errEl.style.display = 'block';
  }
}

function doRegister() {
  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;
  const errEl = document.getElementById('reg-error');
  if (!name || !email || !password) {
    errEl.textContent = 'Please fill in all fields.';
    errEl.style.display = 'block'; return;
  }
  if (password.length < 6) {
    errEl.textContent = 'Password must be at least 6 characters.';
    errEl.style.display = 'block'; return;
  }
  const result = Auth.register(name, email, password);
  if (result.success) {
    Modal.close();
    Toast.show(`Welcome to Bumapo, ${name.split(' ')[0]}! 🎉`, 'success');
    setTimeout(() => updateNavForAuth(), 100);
  } else {
    errEl.textContent = result.error;
    errEl.style.display = 'block';
  }
}

// ── Nav Auth Update ────────────────────────────────────────────────────────────
function updateNavForAuth() {
  const user = Auth.getCurrentUser();
  const navActions = document.getElementById('nav-actions');
  const mobileNavActions = document.getElementById('mobile-nav-actions');

  if (!navActions) return;

  if (user) {
    navActions.innerHTML = `
      <a href="write.html" class="btn-primary-nav">Write</a>
      <div class="user-menu-wrapper" style="position:relative;">
        <button class="user-avatar-btn" onclick="toggleUserMenu()" style="display:flex;align-items:center;gap:10px;background:none;border:none;cursor:pointer;padding:6px 12px 6px 6px;border-radius:40px;border:1.5px solid #e5e5e5;transition:all 0.2s;" onmouseover="this.style.borderColor='#111'" onmouseout="this.style.borderColor='#e5e5e5'">
          <div style="width:34px;height:34px;background:#111;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;font-family:'Lora',Georgia,serif;">${user.avatar}</div>
          <span style="font-size:14px;font-weight:600;color:#111;font-family:'Lora',Georgia,serif;">${user.name.split(' ')[0]}</span>
          <span style="font-size:10px;color:#888;">▾</span>
        </button>
        <div id="user-menu" style="display:none;position:absolute;right:0;top:calc(100% + 8px);background:#fff;border:1.5px solid #e5e5e5;border-radius:14px;padding:8px;min-width:180px;box-shadow:0 8px 32px rgba(0,0,0,0.12);z-index:1000;">
          <div style="padding:10px 12px 8px;border-bottom:1px solid #f0f0f0;margin-bottom:4px;">
            <div style="font-size:13px;font-weight:700;color:#111;font-family:'Lora',Georgia,serif;">${user.name}</div>
            <div style="font-size:11px;color:#999;">${user.email}</div>
          </div>
          <a href="write.html" style="display:block;padding:9px 12px;border-radius:8px;font-size:13px;color:#333;text-decoration:none;font-family:'Lora',Georgia,serif;" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background=''">✍️ Write Article</a>
          <a href="articles.html" style="display:block;padding:9px 12px;border-radius:8px;font-size:13px;color:#333;text-decoration:none;font-family:'Lora',Georgia,serif;" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background=''">📚 All Articles</a>
          <div style="border-top:1px solid #f0f0f0;margin-top:4px;padding-top:4px;">
            <button onclick="Auth.logout()" style="width:100%;text-align:left;padding:9px 12px;border-radius:8px;font-size:13px;color:#ef4444;background:none;border:none;cursor:pointer;font-family:'Lora',Georgia,serif;" onmouseover="this.style.background='#fff5f5'" onmouseout="this.style.background=''">← Sign Out</button>
          </div>
        </div>
      </div>
    `;
    if (mobileNavActions) {
      mobileNavActions.innerHTML = `
        <a href="write.html" style="display:block;padding:14px 0;border-bottom:1px solid #f0f0f0;font-weight:600;color:#111;text-decoration:none;font-family:'Lora',Georgia,serif;">✍️ Write Article</a>
        <button onclick="Auth.logout()" style="display:block;width:100%;text-align:left;padding:14px 0;color:#ef4444;background:none;border:none;cursor:pointer;font-size:16px;font-family:'Lora',Georgia,serif;font-weight:600;">← Sign Out</button>
      `;
    }
  } else {
    navActions.innerHTML = `
      <button onclick="openAuthModal('login')" style="padding:9px 20px;border:1.5px solid #ddd;border-radius:40px;background:transparent;font-size:14px;font-weight:600;cursor:pointer;font-family:'Lora',Georgia,serif;color:#555;transition:all 0.2s;" onmouseover="this.style.borderColor='#111';this.style.color='#111'" onmouseout="this.style.borderColor='#ddd';this.style.color='#555'">Sign In</button>
      <button onclick="openAuthModal('register')" class="btn-primary-nav">Get Started</button>
    `;
    if (mobileNavActions) {
      mobileNavActions.innerHTML = `
        <button onclick="openAuthModal('login')" style="display:block;width:100%;text-align:left;padding:14px 0;border-bottom:1px solid #f0f0f0;font-weight:600;color:#111;background:none;border:none;border-bottom:1px solid #f0f0f0;cursor:pointer;font-size:16px;font-family:'Lora',Georgia,serif;">Sign In</button>
        <button onclick="openAuthModal('register')" style="display:block;width:100%;text-align:left;padding:14px 0;font-weight:600;color:#111;background:none;border:none;cursor:pointer;font-size:16px;font-family:'Lora',Georgia,serif;">Create Account →</button>
      `;
    }
  }
}

function toggleUserMenu() {
  const menu = document.getElementById('user-menu');
  if (!menu) return;
  const isOpen = menu.style.display !== 'none';
  menu.style.display = isOpen ? 'none' : 'block';
  if (!isOpen) {
    const close = (e) => {
      if (!menu.contains(e.target) && !e.target.closest('.user-avatar-btn')) {
        menu.style.display = 'none';
        document.removeEventListener('click', close);
      }
    };
    setTimeout(() => document.addEventListener('click', close), 10);
  }
}

// ── Mobile Menu ────────────────────────────────────────────────────────────────
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const hamburger = document.getElementById('hamburger-btn');
  if (!menu) return;
  const isOpen = menu.style.maxHeight && menu.style.maxHeight !== '0px';
  if (isOpen) {
    menu.style.maxHeight = '0px';
    menu.style.opacity = '0';
    hamburger.innerHTML = '☰';
  } else {
    menu.style.maxHeight = '600px';
    menu.style.opacity = '1';
    hamburger.innerHTML = '✕';
  }
}

// ── Inject Global Styles ───────────────────────────────────────────────────────
function injectGlobalStyles() {
  if (document.getElementById('bumapo-global-styles')) return;
  const style = document.createElement('style');
  style.id = 'bumapo-global-styles';
  style.textContent = `
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
    .btn-primary-nav {
      padding: 9px 22px;
      background: #111;
      color: #fff;
      border: none;
      border-radius: 40px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      font-family: 'Lora', Georgia, serif;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      transition: all 0.2s;
      letter-spacing: 0.2px;
    }
    .btn-primary-nav:hover { background: #333; transform: translateY(-1px); }
    .article-card { transition: all 0.3s ease; }
    .article-card:hover { transform: translateY(-4px); box-shadow: 0 20px 60px rgba(0,0,0,0.12) !important; }
    .like-btn.liked { color: #ef4444 !important; }
    * { box-sizing: border-box; }
  `;
  document.head.appendChild(style);
}

// ── DOM Ready ──────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  injectGlobalStyles();
  updateNavForAuth();

  // Active nav link
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.style.color = '#111';
      link.style.fontWeight = '700';
    }
  });
});
