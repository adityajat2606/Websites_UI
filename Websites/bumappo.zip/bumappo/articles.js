// ─── Bumapo Articles Data Store ───────────────────────────────────────────────
const ARTICLES_DB = [
  {
    id: 1,
    title: "The Art of Slow Thinking in a Fast World",
    slug: "art-of-slow-thinking",
    excerpt: "In an era of instant gratification and endless notifications, the ability to think deeply has become a rare and precious skill worth cultivating.",
    content: `<p>We live in the age of the interrupt. Every few minutes, a buzzing pocket, a flashing screen, a pinging inbox demands our attention. The average person checks their phone 96 times a day — once every ten minutes. And yet, the most profound insights in human history came not from speed, but from stillness.</p>

<p>The philosopher Blaise Pascal once wrote that all of humanity's problems stem from man's inability to sit quietly in a room alone. He wrote this in the 17th century, centuries before the smartphone. Imagine what he'd say today.</p>

<h2>The Two Systems of Thought</h2>

<p>Daniel Kahneman's landmark work on cognitive psychology describes two modes of thinking: System 1, which is fast, automatic, emotional, and instinctive; and System 2, which is slow, deliberate, logical, and effortful. Most of our daily decisions are made by System 1. It's efficient. It's also frequently wrong.</p>

<p>System 2 thinking — the slow kind — is what produced the theory of relativity, the Mona Lisa, and every great novel ever written. It requires something increasingly rare: uninterrupted time.</p>

<h2>Reclaiming the Space to Think</h2>

<p>Cultivating slow thinking isn't about rejecting technology or retreating to a cabin in the woods. It's about intentionally creating pockets of cognitive space in your day. Some practices that help:</p>

<p><strong>Morning pages.</strong> Write three pages of longhand stream-of-consciousness first thing in the morning. No editing. No judgment. Just thinking on paper.</p>

<p><strong>The walk without a destination.</strong> Leave your phone at home. Walk for twenty minutes with no podcast, no music, no agenda. Let your mind wander.</p>

<p><strong>Single-tasking.</strong> Choose one problem. Work on only that problem. See what emerges when you stop fragmenting your attention.</p>

<p>The greatest ideas don't come in meetings or during Slack sessions. They come in the shower, on a long drive, in the quiet before the world wakes up. Protect that quiet fiercely. It's becoming the most valuable resource of the 21st century.</p>`,
    author: "Mara Osei",
    authorAvatar: "MO",
    authorBio: "Mara is a cognitive psychologist and essayist based in Accra. She writes about the intersection of technology, attention, and human flourishing.",
    category: "Philosophy",
    tags: ["thinking", "productivity", "mindfulness", "psychology"],
    coverGradient: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
    coverEmoji: "🧠",
    readTime: "6 min read",
    date: "2025-02-18",
    dateFormatted: "Feb 18, 2025",
    likes: 247,
    comments: [
      { id: 1, user: "James K.", avatar: "JK", text: "This hit me hard. I've been trying to reclaim my morning routine for exactly this reason.", date: "Feb 19, 2025", likes: 14 },
      { id: 2, user: "Priya N.", avatar: "PN", text: "The Kahneman reference is perfect here. Have you read 'Deep Work' by Cal Newport? Complements this beautifully.", date: "Feb 20, 2025", likes: 9 },
      { id: 3, user: "Tomás R.", avatar: "TR", text: "Single-tasking changed my life. Seriously. Three months in and I feel like a different person.", date: "Feb 21, 2025", likes: 22 }
    ],
    featured: true
  },
  {
    id: 2,
    title: "Building Cities for Humans, Not Cars",
    slug: "cities-for-humans",
    excerpt: "The 20th century was an experiment in car-centric urban design. The data is in. It failed. Now cities around the world are reimagining what streets are really for.",
    content: `<p>In 1955, the city of Houston made a decision that would shape its destiny for the next seven decades: it would build roads. Lots of them. Wide ones, fast ones, roads that would connect suburb to downtown in twenty comfortable, air-conditioned minutes. It was a vision of the future, and at the time, it felt utopian.</p>

<p>Today, Houston has some of the worst traffic in the United States, among the highest rates of pedestrian fatalities, and a downtown that empties completely after 5pm. The utopia became a cautionary tale.</p>

<h2>The Great Experiment</h2>

<p>The post-war period saw cities across the developed world undertake a radical transformation: they reshaped their streets, demolished neighborhoods, and reorganized their entire spatial logic around the automobile. Highways bisected communities. Parking minimums inflated land costs. Zoning laws mandated sprawl.</p>

<p>The results, measured across decades, are grim. Car-centric cities consume more energy per capita, produce more emissions, have higher rates of obesity and cardiovascular disease, and paradoxically, often have worse commute times than their more transit-oriented counterparts.</p>

<h2>The Cities Doing It Differently</h2>

<p>But look to Amsterdam, or Copenhagen, or the 15-minute city experiments in Paris, and you see a different possibility. These cities have been systematically reclaiming street space — converting car lanes to protected bike infrastructure, pedestrianizing squares, investing in frequent, reliable transit.</p>

<p>The results are striking. Oslo, which removed almost all city-center parking, saw pedestrian injuries drop to zero in 2019. Bogotá's Ciclovía program closes 76 miles of roads to cars every Sunday, transforming them into a city-wide park used by 1.5 million people.</p>

<p>The city of the future isn't a futuristic highway. It's a neighborhood where you can walk to the bakery, bike to work, and sit in a plaza without breathing exhaust. We already know how to build it. The question is whether we have the political will to try.</p>`,
    author: "Leila Mansouri",
    authorAvatar: "LM",
    authorBio: "Leila is an urban planner and journalist covering cities, infrastructure, and the politics of public space.",
    category: "Urban Design",
    tags: ["cities", "urbanism", "transit", "environment"],
    coverGradient: "linear-gradient(135deg, #134e4a 0%, #0f766e 50%, #14b8a6 100%)",
    coverEmoji: "🏙️",
    readTime: "8 min read",
    date: "2025-02-14",
    dateFormatted: "Feb 14, 2025",
    likes: 389,
    comments: [
      { id: 1, user: "Chris W.", avatar: "CW", text: "As someone who moved from Houston to Amsterdam, this article is my entire life experience distilled.", date: "Feb 15, 2025", likes: 45 },
      { id: 2, user: "Anika B.", avatar: "AB", text: "The Bogotá Ciclovía is genuinely one of the most joyful urban experiences I've ever had.", date: "Feb 16, 2025", likes: 31 }
    ],
    featured: true
  },
  {
    id: 3,
    title: "On the Strange Comfort of Unfinished Things",
    slug: "comfort-of-unfinished",
    excerpt: "Why do we return again and again to books half-read, projects half-built, songs half-written? There might be something profound in the incompleteness itself.",
    content: `<p>My desk has a drawer I don't open often. When I do, I find evidence of a dozen lives I've half-lived: a novel I started in 2019, abandoned at chapter three; a watercolor set still mostly unused; a language-learning app I downloaded with such optimism and opened twice. These aren't failures, exactly. They're something more interesting.</p>

<p>The Zeigarnik effect, named for the Soviet psychologist Bluma Zeigarnik, describes our tendency to remember interrupted or incomplete tasks better than completed ones. Her insight emerged from watching waiters in a Vienna café: they could recall complex unpaid orders in extraordinary detail, but forgot them almost instantly once the bill was settled. Incompleteness, it turns out, keeps a task alive in the mind.</p>

<h2>The Open Loop</h2>

<p>Every unfinished thing is an open loop. It hums in the background of consciousness, occasionally surfacing as a vague guilt or a sudden memory. "I should finish that novel." "I should pick up the guitar again." We're trained to see these loops as problems to close.</p>

<p>But what if some loops are meant to stay open? What if the ongoing relationship with an unfinished thing — the returning to it, the dreaming about what it could become — is itself a form of living?</p>

<h2>Unfinished as Practice</h2>

<p>The Japanese aesthetic concept of <em>ma</em> — often translated as negative space or pause — suggests that the empty, the incomplete, the unresolved can carry as much meaning as the full. A garden with space to wander. A poem that ends on a breath. A sentence that trails—</p>

<p>Perhaps the drawer of abandoned projects is not a record of failure but a collection of openings. Doors ajar. Possibilities still warm. The half-written novel is still a novel in potential. The unused watercolors still hold every painting they might become.</p>

<p>There's a gentleness in leaving things unfinished. It keeps them possible.</p>`,
    author: "Soren Halverson",
    authorAvatar: "SH",
    authorBio: "Soren writes personal essays and cultural criticism from Oslo. His work explores creativity, procrastination, and the examined life.",
    category: "Essay",
    tags: ["creativity", "psychology", "personal essay", "art"],
    coverGradient: "linear-gradient(135deg, #3b1f5e 0%, #6d28d9 50%, #8b5cf6 100%)",
    coverEmoji: "✍️",
    readTime: "5 min read",
    date: "2025-02-10",
    dateFormatted: "Feb 10, 2025",
    likes: 512,
    comments: [
      { id: 1, user: "Mei L.", avatar: "ML", text: "I have a drawer exactly like this. You've made me feel so much better about it.", date: "Feb 11, 2025", likes: 67 },
      { id: 2, user: "Dana F.", avatar: "DF", text: "The ma concept is so beautifully applied here. This is the kind of essay the internet needs more of.", date: "Feb 12, 2025", likes: 41 },
      { id: 3, user: "Kwame A.", avatar: "KA", text: "That last line. Keeping things possible. That's going on my wall.", date: "Feb 13, 2025", likes: 89 }
    ],
    featured: true
  },
  {
    id: 4,
    title: "The Unexpected Mathematics of Music",
    slug: "mathematics-of-music",
    excerpt: "From Pythagorean ratios to Fourier transforms, mathematics and music have been in conversation for millennia. What does one reveal about the other?",
    content: `<p>The ancient Greeks believed music was a branch of mathematics. Pythagoras — yes, the triangle guy — spent considerable effort studying the mathematical relationships between musical notes. He discovered that a string half as long produces a note exactly one octave higher. That two-thirds produces a perfect fifth. These weren't just observations about strings; they seemed to reveal something fundamental about the universe.</p>

<p>Twenty-five centuries later, we still haven't quite shaken that sense of wonder. Music and mathematics remain deeply intertwined — not just metaphorically, but structurally, concretely, measurably.</p>

<h2>Why an Octave Sounds Right</h2>

<p>When you play middle C and the C above it together, they sound harmonious. The reason is physical: the higher C vibrates at exactly twice the frequency of the lower. Their sound waves align perfectly, reinforcing each other in a pattern your auditory system recognizes as consonance. Your brain isn't making an aesthetic judgment — it's doing arithmetic.</p>

<p>The entire Western scale is built on a careful system of frequency ratios, a compromise called equal temperament that allows instruments to play in any key. It's a mathematical hack that sacrifices perfect tuning in every key to achieve acceptable tuning in all keys. Even the compromise is elegant.</p>

<h2>Bach's Hidden Structures</h2>

<p>Johann Sebastian Bach, writing in the early 18th century, constructed his fugues with an architectural precision that modern analysts have found remarkable. The patterns of his counterpoint follow rules of transformation — inversion, retrograde, augmentation — that closely resemble mathematical symmetry operations. Whether he was consciously doing mathematics or simply following his extraordinary musical intuition is still debated.</p>

<p>What's clear is that great music contains order. Not rigid, mechanical order — but the kind of order that also underlies a fractal, or a tide chart, or the branching of a tree. Structure complex enough to be surprising. Simple enough to be grasped. That might be the deepest definition of beauty we have.</p>`,
    author: "Dr. Yuki Tanaka",
    authorAvatar: "YT",
    authorBio: "Dr. Tanaka is a musicologist and mathematician at Kyoto University. She writes about the deep structures of sound and beauty.",
    category: "Science",
    tags: ["music", "mathematics", "science", "history"],
    coverGradient: "linear-gradient(135deg, #7c2d12 0%, #c2410c 50%, #ea580c 100%)",
    coverEmoji: "🎵",
    readTime: "7 min read",
    date: "2025-02-05",
    dateFormatted: "Feb 5, 2025",
    likes: 298,
    comments: [
      { id: 1, user: "Alex P.", avatar: "AP", text: "The Bach section blew my mind. I'll never listen to a fugue the same way again.", date: "Feb 6, 2025", likes: 28 }
    ],
    featured: false
  },
  {
    id: 5,
    title: "Learning a Language After Forty",
    slug: "language-after-forty",
    excerpt: "Neuroscience once told us adult brains couldn't learn new languages as effectively. New research — and countless late-blooming polyglots — suggest otherwise.",
    content: `<p>I started learning Mandarin at 44. This was widely considered, by well-meaning friends and some neurologists, to be a terrible idea. The critical period hypothesis, the dominant theory in language acquisition for decades, held that language learning becomes dramatically harder after puberty, as the brain loses plasticity. The implication was clear: if you didn't grow up bilingual, you'd better stick to hand gestures abroad.</p>

<p>Four years later, I hold a basic conversation in Mandarin. My tones are imperfect. My vocabulary is limited. But I can do it. And the process of getting here taught me something the researchers are only now catching up to: adults learn languages differently, not worse.</p>

<h2>What the Brain Actually Does</h2>

<p>Recent neuroimaging research has complicated the critical period story considerably. Adult brains do show reduced plasticity in some domains, but they compensate with increased analytical ability. While children acquire language largely through immersive pattern recognition, adults can leverage their understanding of grammar, their broader vocabulary in their native language, and their metacognitive skills — the ability to think about thinking — to accelerate learning.</p>

<p>A study from the University of Illinois found that adult learners often surpass child learners in reading and listening comprehension within the first few months, though children eventually outperform adults in native-like accent and intuitive grammar. The trade-off is real, but it's not the disaster the old theory implied.</p>

<h2>What Actually Works</h2>

<p>Consistency beats intensity. Twenty minutes daily outperforms two-hour weekend sessions. Comprehensible input — reading and listening to material just slightly beyond your current level — builds fluency faster than grammar drilling. And the most important factor of all: caring enough to keep going.</p>

<p>The brain you have at 44 is different from the brain at 8. Different isn't lesser. It's just different. And sometimes, the things we learn when we're fully, consciously trying to learn them stick in ways that childhood acquisition never quite does. I understand what Mandarin is doing. That's not nothing.</p>`,
    author: "Claire Beaumont",
    authorAvatar: "CB",
    authorBio: "Claire is a writer, amateur polyglot, and former academic based in Lyon. She writes about learning, memory, and the mind at any age.",
    category: "Learning",
    tags: ["language", "learning", "neuroscience", "personal essay"],
    coverGradient: "linear-gradient(135deg, #1e3a5f 0%, #1d4ed8 50%, #3b82f6 100%)",
    coverEmoji: "🌍",
    readTime: "9 min read",
    date: "2025-01-28",
    dateFormatted: "Jan 28, 2025",
    likes: 445,
    comments: [
      { id: 1, user: "Ryo M.", avatar: "RM", text: "Started Korean at 52. Can confirm: slower but not impossible. And actually more satisfying.", date: "Jan 29, 2025", likes: 56 },
      { id: 2, user: "Fatima Z.", avatar: "FZ", text: "The point about comprehensible input is SO important. Dreaming Mandarin Podcast changed everything for me.", date: "Jan 30, 2025", likes: 33 }
    ],
    featured: false
  },
  {
    id: 6,
    title: "The Ethics of Solitude",
    slug: "ethics-of-solitude",
    excerpt: "We celebrate solitude as self-care, but rarely examine its moral dimensions. What do we owe each other — and what do we owe ourselves?",
    content: `<p>There is a peculiar guilt that attaches itself to time spent alone. Not the solitude of illness or isolation, but the chosen kind — the weekend walk that could have been a social visit, the evening with a book that could have been a dinner party. In a culture that prizes connection, productivity, and visibility, choosing to be alone can feel like a small act of rebellion against social expectation.</p>

<p>And yet philosophers across traditions have consistently argued for the necessity of solitude. Aristotle's contemplative life. Thoreau's Walden. Simone Weil's attention as a moral act. The monastic traditions of every major religion. The consensus from those who have thought most carefully about the good life is striking: some significant portion of it needs to be spent in quiet, alone, attending to the interior.</p>

<h2>The Social Dimension</h2>

<p>But here's the tension: we are social animals. We have obligations to others — family, friends, community. If you spend your weekends in solitary retreat while your aging parents go unvisited and your friends' calls go unreturned, have you simply honored your need for solitude, or have you failed at something important?</p>

<p>I don't think there's a clean answer. What I do think is that solitude and connection aren't really opposites. The person who has cultivated genuine inner life tends to be more present when they do show up — more attentive, less distracted, with more to offer. Depletion helps no one.</p>

<h2>A Different Kind of Presence</h2>

<p>Perhaps the ethics of solitude isn't about how much of it you take, but what you bring back. The point of the interior life isn't escape from the world but preparation for return to it. Solitude as practice, as sharpening. The monk comes down from the mountain. Thoreau left Walden Pond. Even Pascal, eventually, had to open the door.</p>`,
    author: "Amara Diallo",
    authorAvatar: "AD",
    authorBio: "Amara is a philosopher and ethicist whose work examines the moral life in contemporary society. She teaches at the University of Dakar.",
    category: "Philosophy",
    tags: ["ethics", "solitude", "philosophy", "wellbeing"],
    coverGradient: "linear-gradient(135deg, #1c1917 0%, #44403c 50%, #78716c 100%)",
    coverEmoji: "🌿",
    readTime: "6 min read",
    date: "2025-01-20",
    dateFormatted: "Jan 20, 2025",
    likes: 331,
    comments: [
      { id: 1, user: "Ingrid H.", avatar: "IH", text: "The idea that solitude prepares you for return — this reframing is going to stay with me.", date: "Jan 21, 2025", likes: 44 },
      { id: 2, user: "Ben T.", avatar: "BT", text: "I've always struggled with the guilt. This gave me a lot to think about. Thank you.", date: "Jan 22, 2025", likes: 27 }
    ],
    featured: false
  }
];

// ─── Helper Functions ──────────────────────────────────────────────────────────

function getAllArticles() {
  return ARTICLES_DB;
}

function getFeaturedArticles() {
  return ARTICLES_DB.filter(a => a.featured);
}

function getArticleById(id) {
  return ARTICLES_DB.find(a => a.id === parseInt(id));
}

function getArticleBySlug(slug) {
  return ARTICLES_DB.find(a => a.slug === slug);
}

function getArticlesByCategory(category) {
  return ARTICLES_DB.filter(a => a.category === category);
}

function getCategories() {
  const cats = [...new Set(ARTICLES_DB.map(a => a.category))];
  return cats;
}

function searchArticles(query) {
  const q = query.toLowerCase();
  return ARTICLES_DB.filter(a =>
    a.title.toLowerCase().includes(q) ||
    a.excerpt.toLowerCase().includes(q) ||
    a.author.toLowerCase().includes(q) ||
    a.tags.some(t => t.includes(q))
  );
}

function addComment(articleId, comment) {
  const article = getArticleById(articleId);
  if (!article) return false;
  const newComment = {
    id: Date.now(),
    user: comment.user,
    avatar: comment.avatar,
    text: comment.text,
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    likes: 0
  };
  article.comments.push(newComment);
  return newComment;
}

function addArticle(article) {
  const newArticle = {
    id: Date.now(),
    slug: article.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    comments: [],
    likes: 0,
    featured: false,
    date: new Date().toISOString().split('T')[0],
    dateFormatted: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    coverGradient: "linear-gradient(135deg, #1e293b 0%, #334155 50%, #475569 100%)",
    coverEmoji: "📝",
    ...article
  };
  ARTICLES_DB.unshift(newArticle);
  return newArticle;
}
