# 🏪 LocalSpot – Premium Local Business Discovery

A fully-featured, Yelp-inspired local business discovery app built with vanilla React via CDN (no build step needed).

## 🚀 Quick Start

```bash
# Option 1: Just open index.html directly in your browser
open index.html

# Option 2: Serve with npm (if you have serve installed)
npm install
npm run dev
# Opens at http://localhost:3000

# Option 3: Use Python's built-in server
python3 -m http.server 3000
# Opens at http://localhost:3000

# Option 4: Use VS Code Live Server extension
# Right-click index.html → Open with Live Server
```

## 📁 Project Structure

```
localspot/
├── index.html              ← Main app (React via CDN, zero build needed)
├── package.json            ← Simple npm scripts for serving
├── README.md
└── src/
    ├── components/         ← Component reference docs
    │   ├── Navbar.md
    │   ├── BusinessCard.md
    │   ├── ReviewCard.md
    │   ├── FilterSidebar.md
    │   └── Stars.md
    ├── pages/              ← Page reference docs
    │   ├── HomePage.md
    │   ├── SearchPage.md
    │   ├── BusinessPage.md
    │   ├── WriteReviewPage.md
    │   ├── ProfilePage.md
    │   ├── SavedPage.md
    │   └── CategoryPage.md
    └── data/
        └── mockData.js     ← Mock data (businesses, reviews, categories, cities)
```

## 📄 Pages

| Page | Description |
|------|-------------|
| **Home** | Hero search, categories grid, featured businesses, trending cities, how-it-works, CTA |
| **Search Results** | Filter sidebar, list view, map placeholder, sort controls |
| **Business Details** | Photo gallery, info, hours, reviews, rating breakdown, sidebar |
| **Write Review** | Star selector with animations, text area, photo upload UI |
| **User Profile** | Stats header, tabs for reviews/photos/saved businesses |
| **Saved Businesses** | Heart-saved collection with business cards |
| **Category** | Category-filtered business grid with category switcher |

## 🎨 Design System

| Variable | Value | Usage |
|----------|-------|-------|
| `--red` | `#E00707` | Primary actions, accents |
| `--red-light` | `#FF5A5F` | Hero accent, gradients |
| `--bg` | `#F5F5F5` | Page background |
| `--text` | `#111827` | Body text |
| `--shadow` | `0 4px 24px rgba(0,0,0,0.08)` | Card shadows |

**Fonts:** Syne (headings, logo) + Inter (body)

## ✨ Features

- ✅ 7 fully-featured pages
- ✅ Global app state (saved businesses, navigation, search, toasts)
- ✅ Animated hero with floating background shapes
- ✅ Business card hover animations
- ✅ Filter sidebar (rating, price, category, open now)
- ✅ Interactive star rating selector
- ✅ Photo gallery modal
- ✅ Review cards with helpful voting
- ✅ User profile with tabs
- ✅ Toast notifications
- ✅ Responsive mobile-first design
- ✅ Zero build step required

## 🛠 Tech Notes

This project uses React via CDN with Babel standalone for JSX transpilation. This means:
- **No npm install required** to run – just open `index.html`
- All components and pages are in `index.html` for portability
- The `src/` folder contains reference documentation
- To convert to a Vite project, paste each component section into separate files

## 📦 Converting to Vite (Optional)

```bash
npm create vite@latest localspot-vite -- --template react
cd localspot-vite
npm install react-router-dom framer-motion lucide-react
npm install -D tailwindcss postcss autoprefixer
```

Then copy each component/page from `index.html` into separate files.
