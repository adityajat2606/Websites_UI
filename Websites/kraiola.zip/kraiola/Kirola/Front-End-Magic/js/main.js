/**
 * Main JavaScript File for kraiola
 * Handles routing, data loading, DOM manipulation, and interactive features.
 */

document.addEventListener('DOMContentLoaded', () => {
    // State management
    const state = {
        articles: [],
        categories: ['Technology', 'Design', 'Development', 'Business'],
        theme: localStorage.getItem('theme') || 'light'
    };

    // DOM Elements
    const elements = {
        themeToggle: document.getElementById('theme-toggle'),
        moonIcon: document.getElementById('moon-icon'),
        sunIcon: document.getElementById('sun-icon'),
        mobileMenuBtn: document.getElementById('mobile-menu-btn'),
        mobileMenu: document.getElementById('mobile-menu'),
        searchBtn: document.getElementById('search-btn'),
        closeSearchBtn: document.getElementById('close-search'),
        searchOverlay: document.getElementById('search-overlay'),
        searchInput: document.getElementById('search-input'),
        header: document.querySelector('.header')
    };

    // ==========================================================================
    // Initialization
    // ==========================================================================
    
    async function init() {
        applyTheme(state.theme);
        setupEventListeners();
        
        try {
            await loadData();
            routePage();
        } catch (error) {
            console.error('Error initializing app:', error);
            handleError('Failed to load articles. Please try again later.');
        }
    }

    async function loadData() {
        const response = await fetch('data/articles.json');
        if (!response.ok) throw new Error('Failed to fetch data');
        state.articles = await response.json();
    }

    // ==========================================================================
    // Routing (Vanilla JS implementation based on pathname)
    // ==========================================================================
    
    function routePage() {
        const path = window.location.pathname;
        const searchParams = new URLSearchParams(window.location.search);
        
        if (path.includes('article.html')) {
            const id = parseInt(searchParams.get('id'));
            renderArticlePage(id);
        } else if (path.includes('category.html')) {
            const category = searchParams.get('cat');
            renderCategoryPage(category);
        } else if (path.includes('index.html') || path.endsWith('/')) {
            renderHomePage();
        }
        // other pages are static HTML
    }

    // ==========================================================================
    // Rendering Functions
    // ==========================================================================

    function renderHomePage() {
        const featuredGrid = document.getElementById('featured-grid');
        const latestGrid = document.getElementById('latest-articles-grid');
        
        if (!featuredGrid || !latestGrid) return;

        const featuredArticles = state.articles.filter(a => a.featured).slice(0, 3);
        const latestArticles = state.articles.filter(a => !a.featured).slice(0, 6);

        featuredGrid.innerHTML = '';
        if (featuredArticles.length > 0) {
            // Main featured
            featuredGrid.appendChild(createArticleCard(featuredArticles[0], true));
            // Secondary featured
            const secondaryContainer = document.createElement('div');
            secondaryContainer.style.display = 'flex';
            secondaryContainer.style.flexDirection = 'column';
            secondaryContainer.style.gap = 'var(--space-6)';
            
            if (featuredArticles[1]) secondaryContainer.appendChild(createArticleCard(featuredArticles[1]));
            if (featuredArticles[2]) secondaryContainer.appendChild(createArticleCard(featuredArticles[2]));
            
            featuredGrid.appendChild(secondaryContainer);
        }

        latestGrid.innerHTML = latestArticles.map(a => createArticleCardHTML(a)).join('');
    }

    function renderCategoryPage(category) {
        const grid = document.getElementById('category-articles-grid');
        const titleEl = document.getElementById('category-title');
        
        if (!grid || !titleEl) return;

        let filteredArticles = state.articles;
        
        if (category) {
            titleEl.textContent = category;
            document.title = `${category} Articles - kraiola`;
            filteredArticles = state.articles.filter(a => a.category === category);
        } else {
            titleEl.textContent = 'All Articles';
        }

        if (filteredArticles.length === 0) {
            grid.innerHTML = '<p>No articles found in this category.</p>';
            return;
        }

        grid.innerHTML = filteredArticles.map(a => createArticleCardHTML(a)).join('');
    }

    function renderArticlePage(id) {
        const article = state.articles.find(a => a.id === id);
        if (!article) {
            handleError('Article not found', document.querySelector('main'));
            return;
        }

        // Update DOM elements
        document.title = `${article.title} - kraiola`;
        document.getElementById('article-title').textContent = article.title;
        document.getElementById('article-category').textContent = article.category;
        document.getElementById('author-name').textContent = article.author.name;
        document.getElementById('author-avatar').src = article.author.avatar;
        
        // Format Date
        const dateObj = new Date(article.date);
        document.getElementById('publish-date').textContent = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        
        // Reading time
        const wordsPerMinute = 200;
        const words = article.content.split(/\s+/).length;
        const readTime = Math.ceil(words / wordsPerMinute);
        document.getElementById('reading-time').textContent = `${readTime} min read`;

        // Image
        const imgEl = document.getElementById('article-image');
        imgEl.src = article.image;
        imgEl.alt = article.title;

        // Breadcrumb
        document.getElementById('breadcrumb').innerHTML = `
            <a href="index.html">Home</a> / 
            <a href="category.html?cat=${article.category}">${article.category}</a> / 
            <span class="text-accent">${article.title}</span>
        `;

        // Content Parsing (Basic Markdown to HTML for demo purposes)
        const contentEl = document.getElementById('article-body');
        contentEl.innerHTML = parseSimpleMarkdown(article.content);

        // Generate TOC
        generateTableOfContents();

        // SEO Tags dynamically
        updateSEOTags(article);

        // Render Related
        const relatedGrid = document.getElementById('related-articles-grid');
        if (relatedGrid) {
            const related = state.articles
                .filter(a => a.category === article.category && a.id !== article.id)
                .slice(0, 3);
            
            if (related.length > 0) {
                relatedGrid.innerHTML = related.map(a => createArticleCardHTML(a)).join('');
            } else {
                document.querySelector('.related-articles').style.display = 'none';
            }
        }
    }

    // ==========================================================================
    // UI Helpers & Utilities
    // ==========================================================================

    function createArticleCard(article, isLarge = false) {
        const div = document.createElement('div');
        div.className = `card article-card ${isLarge ? 'featured-large' : ''}`;
        div.innerHTML = createArticleCardHTML(article);
        return div;
    }

    function createArticleCardHTML(article) {
        const readTime = Math.ceil(article.content.split(/\s+/).length / 200);
        const dateStr = new Date(article.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        
        return `
            <article class="card article-card">
                <a href="article.html?id=${article.id}" class="card-img-wrapper">
                    <span class="badge card-badge">${article.category}</span>
                    <img src="${article.image}" alt="${article.title}" loading="lazy">
                </a>
                <div class="card-content">
                    <h3 class="card-title">
                        <a href="article.html?id=${article.id}">${article.title}</a>
                    </h3>
                    <p class="card-excerpt">${article.excerpt}</p>
                    <div class="card-meta">
                        <div class="card-author">
                            <img src="${article.author.avatar}" alt="${article.author.name}" class="avatar-sm">
                            <span>${article.author.name}</span>
                        </div>
                        <div>
                            <span>${dateStr}</span> &bull; <span>${readTime} min</span>
                        </div>
                    </div>
                </div>
            </article>
        `;
    }

    function parseSimpleMarkdown(text) {
        let html = text
            .replace(/^### (.*$)/gim, '<h3>$1</h3>')
            .replace(/^## (.*$)/gim, '<h2>$1</h2>')
            .replace(/^# (.*$)/gim, '<h1>$1</h1>')
            .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
            .replace(/\*(.*)\*/gim, '<em>$1</em>')
            .replace(/```javascript\n([\s\S]*?)```/gim, '<pre><code>$1</code></pre>')
            .replace(/`(.*?)`/gim, '<code>$1</code>')
            .replace(/^\> (.*$)/gim, '<blockquote>$1</blockquote>')
            .replace(/\n\n/gim, '</p><p>');
            
        return `<p>${html}</p>`;
    }

    function generateTableOfContents() {
        const articleBody = document.getElementById('article-body');
        const headings = articleBody.querySelectorAll('h2, h3');
        const tocContainer = document.getElementById('toc-container');
        const tocNav = document.getElementById('table-of-contents');
        
        if (headings.length < 2) return; // Don't show TOC for very short articles

        tocContainer.style.display = 'block';
        const ul = document.createElement('ul');

        headings.forEach((heading, index) => {
            const id = `heading-${index}`;
            heading.id = id; // Add ID to heading for anchoring
            
            const li = document.createElement('li');
            li.style.marginLeft = heading.tagName === 'H3' ? '1rem' : '0';
            
            const a = document.createElement('a');
            a.href = `#${id}`;
            a.textContent = heading.textContent;
            
            // Smooth scroll
            a.addEventListener('click', (e) => {
                e.preventDefault();
                const offsetTop = heading.getBoundingClientRect().top + window.scrollY - 100;
                window.scrollTo({ top: offsetTop, behavior: 'smooth' });
            });

            li.appendChild(a);
            ul.appendChild(li);
        });

        tocNav.appendChild(ul);
    }

    function updateSEOTags(article) {
        document.querySelector('meta[name="description"]')?.setAttribute('content', article.excerpt);
        
        // Find or create OG tags
        let ogTitle = document.querySelector('meta[property="og:title"]');
        if (!ogTitle) {
            ogTitle = document.createElement('meta');
            ogTitle.setAttribute('property', 'og:title');
            document.head.appendChild(ogTitle);
        }
        ogTitle.setAttribute('content', article.title);

        let ogImage = document.querySelector('meta[property="og:image"]');
        if (!ogImage) {
            ogImage = document.createElement('meta');
            ogImage.setAttribute('property', 'og:image');
            document.head.appendChild(ogImage);
        }
        ogImage.setAttribute('content', article.image);
    }

    function handleError(message, container = document.body) {
        container.innerHTML = `
            <div class="container text-center section">
                <h2>Something went wrong</h2>
                <p>${message}</p>
                <a href="index.html" class="btn btn-primary" style="margin-top: 1rem;">Go Home</a>
            </div>
        `;
    }

    // ==========================================================================
    // Event Listeners & Interactions
    // ==========================================================================

    function setupEventListeners() {
        // Theme Toggle
        elements.themeToggle?.addEventListener('click', () => {
            const newTheme = state.theme === 'light' ? 'dark' : 'light';
            applyTheme(newTheme);
            localStorage.setItem('theme', newTheme);
        });

        // Mobile Menu
        elements.mobileMenuBtn?.addEventListener('click', () => {
            elements.mobileMenu.classList.toggle('active');
            document.body.style.overflow = elements.mobileMenu.classList.contains('active') ? 'hidden' : '';
        });

        // Search Overlay
        elements.searchBtn?.addEventListener('click', () => {
            elements.searchOverlay.classList.add('active');
            setTimeout(() => elements.searchInput.focus(), 100);
            document.body.style.overflow = 'hidden';
        });

        elements.closeSearchBtn?.addEventListener('click', closeSearch);
        
        // Close search on escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && elements.searchOverlay.classList.contains('active')) {
                closeSearch();
            }
        });

        // Simple search execution (redirects to category page with generic filtering for demo)
        elements.searchInput?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const term = e.target.value.trim();
                if (term) {
                    alert(`Search functionality for "${term}" would execute here.`);
                    closeSearch();
                }
            }
        });

        // Sticky Header scroll effect
        window.addEventListener('scroll', () => {
            if (window.scrollY > 10) {
                elements.header.style.boxShadow = 'var(--shadow-sm)';
            } else {
                elements.header.style.boxShadow = 'none';
            }
        });
        
        // Forms (prevent default submission for demo)
        const submitForm = document.getElementById('submit-form');
        if(submitForm) {
            submitForm.addEventListener('submit', (e) => {
                e.preventDefault();
                alert('Article submitted successfully for review!');
                submitForm.reset();
            });
        }
        
        const contactForm = document.querySelector('.contact-form');
        if(contactForm && !submitForm) {
             contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                alert('Message sent successfully!');
                contactForm.reset();
            });
        }
    }

    function closeSearch() {
        elements.searchOverlay.classList.remove('active');
        elements.searchInput.value = '';
        document.body.style.overflow = '';
    }

    function applyTheme(themeName) {
        state.theme = themeName;
        document.documentElement.setAttribute('data-theme', themeName);
        
        if (themeName === 'dark') {
            elements.moonIcon.style.display = 'none';
            elements.sunIcon.style.display = 'block';
        } else {
            elements.moonIcon.style.display = 'block';
            elements.sunIcon.style.display = 'none';
        }
    }

    // Start App
    init();
});
