# ModernStatic

A clean, responsive, and high-performance static website project built with:
- **HTML5**
- **Tailwind CSS** (via CDN)
- **Vanilla JavaScript**

## Project Structure
- `index.html`: Home page with Hero and Features section.
- `about.html`: Information about the project.
- `contact.html`: Contact form with frontend validation.
- `public/css/style.css`: Custom styles and transitions.
- `public/js/main.js`: Interactive elements (mobile menu, smooth scroll, form validation).

## Features
- Fully responsive design.
- Mobile-friendly navigation.
- Smooth scrolling for anchor links.
- Interactive UI components.

## How to use
Simply open `index.html` in any web browser. No installation or build steps required.