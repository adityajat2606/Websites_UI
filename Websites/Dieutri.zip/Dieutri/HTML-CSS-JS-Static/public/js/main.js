document.addEventListener('DOMContentLoaded', () => {
    // Mobile Menu Toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // --- Article Logic ---
    
    // Mock Data (since we have no backend, we'll use localStorage to simulate persistence)
    const initialArticles = [
        {
            id: 1,
            title: "The Art of Slow Living in a Fast World",
            author: "Elena Vance",
            date: "Mar 1, 2026",
            readTime: "6 min read",
            excerpt: "How disconnecting from the digital noise can lead to a more fulfilling and creative life.",
            content: "In our hyper-connected era, the concept of 'slow living' has evolved from a niche lifestyle choice to a necessary survival strategy. We are bombarded with notifications, deadlines, and the constant pressure to be productive. But what if the key to true productivity lies in doing less? <br><br> Slow living isn't about being lazy; it's about being intentional. It's about choosing quality over quantity, and presence over performance. When we slow down, we give our brains the space to breathe and innovate.",
            image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=400"
        },
        {
            id: 2,
            title: "Why Minimalist Design Still Rules in 2026",
            author: "Marcus Thorne",
            date: "Feb 28, 2026",
            readTime: "4 min read",
            excerpt: "Exploring the enduring appeal of simplicity in user interfaces and physical products.",
            content: "Minimalism isn't just an aesthetic; it's a philosophy of clarity. As interfaces become more complex, the user's cognitive load increases. Minimalist design serves as a filter, removing the non-essential to highlight what truly matters. In 2026, we see a shift towards 'Organic Minimalism'—where clean lines meet natural textures.",
            image: "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&q=80&w=400"
        },
        {
            id: 3,
            title: "The Future of Remote Work: A Global Perspective",
            author: "Sarah Jenkins",
            date: "Feb 25, 2026",
            readTime: "8 min read",
            excerpt: "How distributed teams are reshaping urban landscapes and the global economy.",
            content: "The office is no longer a place; it's a state of mind. Remote work has unlocked a global talent pool, allowing people to live where they want while working for whoever they want. This shift is revitalizing rural communities and challenging the dominance of mega-cities.",
            image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=400"
        }
    ];

    // Initialize articles in localStorage if not present
    if (!localStorage.getItem('articles')) {
        localStorage.setItem('articles', JSON.stringify(initialArticles));
    }

    // --- Page Specific Logic ---

    // 1. Home Feed (index.html)
    const articlesContainer = document.getElementById('articles-container');
    if (articlesContainer) {
        const articles = JSON.parse(localStorage.getItem('articles'));
        articlesContainer.innerHTML = articles.reverse().map(article => `
            <article class="group cursor-pointer" onclick="location.href='read.html?id=${article.id}'">
                <div class="mb-4 overflow-hidden rounded-xl">
                    <img src="${article.image || 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&q=80&w=400'}" 
                         alt="${article.title}" 
                         class="w-full h-48 object-cover group-hover:scale-105 transition duration-500">
                </div>
                <div class="flex items-center gap-2 text-xs text-gray-500 mb-2">
                    <span class="font-bold text-gray-900">${article.author}</span>
                    <span>·</span>
                    <span>${article.date}</span>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition">${article.title}</h3>
                <p class="text-gray-600 line-clamp-2 mb-4">${article.excerpt}</p>
                <div class="flex items-center justify-between">
                    <span class="text-xs text-gray-400">${article.readTime}</span>
                    <span class="text-indigo-600 opacity-0 group-hover:opacity-100 transition">Read more →</span>
                </div>
            </article>
        `).join('');
    }

    // 2. Writing Page (write.html)
    const titleInput = document.getElementById('title-input');
    const contentInput = document.getElementById('content-input');
    const publishBtn = document.getElementById('publish-btn');

    if (titleInput && contentInput) {
        // Auto-resize textareas
        [titleInput, contentInput].forEach(el => {
            el.addEventListener('input', () => {
                el.style.height = 'auto';
                el.style.height = el.scrollHeight + 'px';
            });
        });

        publishBtn.addEventListener('click', () => {
            const title = titleInput.value.trim();
            const content = contentInput.value.trim();

            if (!title || !content) {
                alert('Please provide both a title and content.');
                return;
            }

            const articles = JSON.parse(localStorage.getItem('articles'));
            const newArticle = {
                id: Date.now(),
                title: title,
                author: "Guest Writer",
                date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                readTime: Math.ceil(content.split(' ').length / 200) + " min read",
                excerpt: content.substring(0, 150) + "...",
                content: content.replace(/\n/g, '<br>'),
                image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&q=80&w=400"
            };

            articles.push(newArticle);
            localStorage.setItem('articles', JSON.stringify(articles));
            
            alert('Article published locally!');
            window.location.href = 'index.html';
        });
    }

    // 3. Reading Page (read.html)
    const articleTitle = document.getElementById('article-title');
    const articleContent = document.getElementById('article-content');
    const articleAuthor = document.getElementById('article-author');
    const articleDate = document.getElementById('article-date');

    if (articleTitle) {
        const urlParams = new URLSearchParams(window.location.search);
        const articleId = urlParams.get('id');
        const articles = JSON.parse(localStorage.getItem('articles'));
        const article = articles.find(a => a.id == articleId) || articles[0];

        if (article) {
            document.title = `${article.title} - Dieutri9`;
            articleTitle.innerText = article.title;
            articleContent.innerHTML = article.content;
            articleAuthor.innerText = article.author;
            articleDate.innerText = `${article.date} · ${article.readTime}`;
        }

        // --- Comments & Attachments (read.html) ---
        const commentInput = document.getElementById('comment-input');
        const commentSubmit = document.getElementById('comment-submit');
        const commentsList = document.getElementById('comments-list');
        const commentsCount = document.getElementById('comments-count');
        const commentFileInput = document.getElementById('comment-file');
        const fileNameLabel = document.getElementById('file-name');

        const commentsKey = articleId ? `comments_${articleId}` : 'comments_default';

        function loadComments() {
            const stored = localStorage.getItem(commentsKey);
            let comments = [];
            if (stored) {
                try {
                    comments = JSON.parse(stored);
                } catch (e) {
                    comments = [];
                }
            }
            renderComments(comments);
        }

        function saveComments(comments) {
            localStorage.setItem(commentsKey, JSON.stringify(comments));
            renderComments(comments);
        }

        function renderComments(comments) {
            if (!commentsList || !commentsCount) return;

            if (!comments.length) {
                commentsList.innerHTML = '';
                commentsCount.textContent = 'No comments yet';
                return;
            }

            commentsCount.textContent =
                comments.length === 1 ? '1 comment' : `${comments.length} comments`;

            commentsList.innerHTML = comments
                .map(comment => {
                    const hasFile = comment.file && comment.file.name;
                    return `
                    <div class="rounded-2xl border border-gray-100 bg-white px-4 py-3 shadow-sm">
                        <div class="flex items-start gap-3">
                            <div class="mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-indigo-100 text-xs font-semibold text-indigo-600">
                                ${comment.initials || 'U'}
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center justify-between gap-2 mb-1">
                                    <p class="text-sm font-medium text-gray-900">
                                        ${comment.author || 'Reader'}
                                    </p>
                                    <p class="text-xs text-gray-400">
                                        ${new Date(comment.createdAt).toLocaleString()}
                                    </p>
                                </div>
                                <p class="text-sm text-gray-800 whitespace-pre-line">
                                    ${comment.text}
                                </p>
                                ${
                                    hasFile
                                        ? `<div class="mt-2 inline-flex items-center gap-2 rounded-full bg-gray-50 px-3 py-1 text-xs text-gray-600 border border-dashed border-gray-200">
                                                <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                                          d="M9 13.5l6-6a2.121 2.121 0 013 3l-7.5 7.5a3 3 0 11-4.243-4.243L14.25 7.5" />
                                                </svg>
                                                <span class="font-medium truncate max-w-[180px]">${comment.file.name}</span>
                                                <span class="text-gray-400">(${comment.file.size})</span>
                                           </div>`
                                        : ''
                                }
                            </div>
                        </div>
                    </div>
                `;
                })
                .join('');
        }

        if (commentFileInput && fileNameLabel) {
            commentFileInput.addEventListener('change', () => {
                const file = commentFileInput.files[0];
                fileNameLabel.textContent = file ? file.name : '';
            });
        }

        if (commentSubmit && commentInput) {
            commentSubmit.addEventListener('click', () => {
                const text = commentInput.value.trim();
                const file = commentFileInput && commentFileInput.files[0];

                if (!text) {
                    alert('Please write a comment before posting.');
                    return;
                }

                const stored = localStorage.getItem(commentsKey);
                let comments = [];
                if (stored) {
                    try {
                        comments = JSON.parse(stored);
                    } catch (e) {
                        comments = [];
                    }
                }

                const initials =
                    (articleAuthor && articleAuthor.innerText
                        .split(' ')
                        .map(p => p[0])
                        .join('')
                        .slice(0, 2)) || 'R';

                const newComment = {
                    id: Date.now(),
                    text,
                    createdAt: new Date().toISOString(),
                    author: 'You',
                    initials,
                    file: file
                        ? {
                              name: file.name,
                              size: `${(file.size / 1024).toFixed(1)} KB`,
                              type: file.type
                          }
                        : null
                };

                comments.push(newComment);
                saveComments(comments);

                commentInput.value = '';
                if (commentFileInput) {
                    commentFileInput.value = '';
                }
                if (fileNameLabel) {
                    fileNameLabel.textContent = '';
                }
            });
        }

        // Initial load of comments
        loadComments();
    }
});